import test from 'node:test';
import assert from 'node:assert/strict';
import { quote, sizeError, quantities, breaks } from '../src/data/pricing.ts';

const base = { product: 'product', material: 'matte', w: 3, h: 3, qty: 500 };

test('minimum-order price and displayed unit price agree', () => {
  const input = { ...base, w: .5, h: .5, qty: 50 };
  const result = quote(input);
  assert.equal(result.total, 25);
  assert.equal(result.unit * input.qty, result.total);
  assert.equal(result.next.add, 50);
  const next = quote({ ...input, qty: 100 });
  assert.equal(result.next.savePct, Math.round((1 - next.unit / result.unit) * 100));
});

test('totals are currency-rounded and quantity breaks reduce unit cost', () => {
  for (const qty of quantities) {
    const result = quote({ ...base, qty });
    assert.ok(Math.abs(result.total * 100 - Math.round(result.total * 100)) < 1e-7);
    assert.ok(Math.abs(result.unit * qty - result.total) < 1e-7);
  }
  for (let i = 1; i < breaks.length; i++) {
    assert.ok(quote({ ...base, qty: breaks[i].qty }).unit < quote({ ...base, qty: breaks[i-1].qty }).unit);
  }
  assert.equal(quote({ ...base, qty: 10000 }).next, null);
});

test('size and material affect prices; unsupported inputs cannot quote', () => {
  assert.ok(quote({ ...base, w: 6 }).total > quote(base).total);
  assert.ok(quote({ ...base, material: 'holo' }).total > quote(base).total);
  for (const value of [NaN, Infinity, 0, -1, .49, 12.01]) {
    assert.ok(sizeError(value, 3));
    assert.throws(() => quote({ ...base, w: value }), RangeError);
  }
  assert.equal(sizeError(.5, 12), null);
  assert.throws(() => quote({ ...base, qty: 0 }), RangeError);
});
