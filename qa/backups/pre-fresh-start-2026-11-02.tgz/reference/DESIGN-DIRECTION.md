# Label Bros: design direction "Production spec" (current, from 2026-11-01)

Replaces the Pinterest sticker-app reference (`pinterest-reference.jpg`, `DESIGN-REFERENCE.md`), which is kept only as history.

## Brief from the client
- Modern, premium and production-ready, not playful.
- Audience: B2B buyers in **food & beverage, defense & government, automotive & parts, industrial & chemical** (plus cosmetics, supplements, craft drinks and retail).
- Two equal ways in: **the customer sends print-ready artwork**, or **Label Bros designs it**. Both end at a proof the customer approves.
- Conversion goals are unchanged: "Get instant pricing" (primary) and "Order a sample kit" (secondary).

## Idea
A precision print house. The page reads like a press sheet and a spec document: proof paper, column guides, numbered section rules, crop marks, registration targets, a CMYK colour bar, die lines and dimension callouts. These ornaments come from the trade itself, so they're never decoration for its own sake. The customers' labels (food labels, ID plates, warning labels, GHS labels) carry the colour; the site itself stays ink, paper and one signal orange.

## Tokens (only these; defined in `src/app/globals.css` `@theme`)
| Token | Value | Use |
|---|---|---|
| paper | #F1F0EC | page canvas |
| sheet | #FAFAF7 | raised surfaces on paper |
| line | #D9D7D1 | hairlines on paper |
| guide | ink at 5.5% | column guides |
| ink | #0E0F10 | type (17:1 on paper) |
| ink-soft | #5B5D61 | secondary text (5.8:1 on paper) |
| graphite / graphite-2 | #141516 / #1F2123 | dark bands / raised on dark |
| steel | #9A9DA2 | secondary text on graphite (6.7:1) |
| signal | #FF4F00 | International Orange: fills, rules, large type, focus ring. Ink on it 5.8:1 |
| signal-text | #B83700 | orange for small text on paper (5.1:1) |
| cyan / magenta / yellow | #00A3E0 / #E4007C / #FFE500 | print marks only, never UI |

- **Type:** Mona Sans only (variable, wdth 75–125, wght 200–900) via `next/font`. Headlines mixed case, weight 600, tracking −0.045 to −0.055em, leading 0.9–0.96. Meta labels 12px uppercase, tracking 0.09em, tabular numerals (`type-meta`). Wordmark: Mona Sans 800 at 125% width. Label *artwork* uses an embedded Anton face (it's also inside the WebGL textures).
- **Radii:** 2px controls (`rounded-xs`), 4/6/10px where needed. No pills.
- **Buttons:** ink body plus a signal-orange arrow tab (`ButtonLink`, `arrow`); outline secondary; `light` / `outline-light` on graphite.
- **Section rule:** `IndexRule`, which reads as index number · name · hairline, then an H2. Sections are numbered 01–10.
- **Rhythm:** light paper sections, with graphite bands at the hero bench, Artwork, Sample kit and footer.

## Page order and signature moments
| # | Section | Signature |
|---|---|---|
| S0 | Header | hide on scroll down, show on scroll up |
| S1 | Hero: headline + both artwork paths; graphite **specimen bench** | Specimen switch: industry labels cycle (clip wipe, die line redraws, spec values roll); tabs + pause; no autoplay under reduced motion |
| — | Client logos strip | none |
| 01 | Industries (4 columns) | Registration: cyan/magenta plates pull into register on scroll |
| 02 | Artwork: "Your artwork, or ours" (graphite) | Junction: both paths draw down and meet at "Proof approved" |
| 03 | Process: Spec · Proof · Print · Ship | Production line: the rule fills and stations light |
| 04 | Application: 3D jar wrap | label bends around the jar (kept) |
| 05 | Products (8 industrial label types) | pinned roll track (kept) |
| 06 | Instant quote (right after products, so the three 3D pins don't run back to back) | controls seat in, price counts up (kept) |
| 07 | Materials (8 films) | 3D material-test plate morphs finish (kept) |
| 08 | Customers: three reviews and case studies (logos live once, under the hero) | none, so it reads calm |
| 09 | Sample kit (graphite) | peel the tamper-evident seal to reveal the code (kept) |
| 10 | Final CTA "Send the spec. Get the proof." | Trim: crop marks close on the headline |
| S10 | Footer (graphite curtain, full-width wordmark) | none |

## Rules learned in review
- Tabular figures are off: Mona Sans's tabular set has slashed zeros and reads as code. Use proportional figures.
- Focus ring: ink on paper (signal orange is only 2.9:1 there), signal orange on graphite.
- Both artwork paths get equal weight everywhere: the hero, the Artwork section (both `light` + arrow) and the final CTA. Links go to the real actions (`/upload`, `[[DESIGN_BRIEF_URL]]`).
- Numbering is for sections, process steps, materials and the products counter only.
- One CTA label: "Get instant pricing" (shortened to "Pricing" in the mobile header).

## Motion language
- `press` CustomEase for anything that seats or registers (fast in, firm stop, **no overshoot**), `expo.out` for reveals, `power2.inOut` for travels, `none` on scrubs.
- Mechanical and precise, never bouncy. No sticker slaps, wobbles or physics bursts.
- The other rules from the motion skill still hold: matchMedia, reduced motion means the static final state, one shared canvas, transform/opacity plus listed exceptions (clip-path wipes in the hero bench and on the low-tier finish plate, DrawSVG strokes, shader uniforms).

## Avoid
Playful stickers and candy palettes; pills; Anton or condensed all-caps headlines in the UI; Inter/Roboto/Space Grotesk/system fonts; monospace labels; gradients on UI; glassmorphism; drop shadows; bento grids; generic fade-up on every element; invented certifications or specs (use `[[PLACEHOLDERS]]`).
