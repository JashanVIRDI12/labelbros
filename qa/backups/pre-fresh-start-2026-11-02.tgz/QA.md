# Verification — 1 November 2026

The homepage implementation is complete. Client content, final pricing and external/commerce destinations remain launch inputs listed in README.md. No commit, push or deployment was performed.

## Automated checks

- `pnpm tsc --noEmit`: pass.
- `pnpm lint`: pass, no warnings.
- `pnpm build`: pass; `/`, `/_not-found` and `/icon.svg` are static.
- `pnpm test`: 3/3 pass, covering minimum-order arithmetic, quantity discounts, dimensions/materials and invalid inputs.
- Application console/page errors: none in desktop, touch, reduced-motion and forced-low-tier captures. An upstream R3F `THREE.Clock` deprecation warning may appear in development.

## Production Lighthouse

Measured against `pnpm build` + `pnpm start --port 3001`, using Lighthouse 13.6 and headless Chromium, with Lighthouse's default simulated mobile throttling and the desktop preset respectively. Local lab results describe this build and machine; they are not field INP or a guarantee for all devices.

| Profile | Performance | Accessibility | Best Practices | SEO | LCP | TBT | CLS |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Mobile | 100 | 100 | 100 | 100 | 0.9 s | 30 ms | 0 |
| Desktop | 100 | 100 | 100 | 100 | 0.3 s | 0 ms | 0.014 |

Raw JSON and HTML: `qa/final/lighthouse-{mobile,desktop}.report.{json,html}`.

## Accessibility and responsive checks

- Axe 4.14: **0 violations** for WCAG 2 A/AA, WCAG 2.1 AA and best-practice rules in the reduced-motion page at **390, 768, 1280, 1440 and 1920px**, and in a normal-motion desktop interactive walkthrough.
- At every tested width: one H1, zero document horizontal overflow. Reduced motion has zero pinned spacers and zero canvases.
- Quote controls use native radios/range/number inputs; custom sizes show empty/error/updating states. Invalid continuation is inert.
- Arrow navigation changes Wrap finishes. Tab focus reveals and retains the header. Product focus scrolls its horizontal track to the active card.
- Mobile menu makes main/footer inert; Escape closes it and restores the Menu button.
- Sample drag and PEEL both reveal the code; permitted clipboard copying was verified with `[[CODE]]`. Denied copying announces reveal without claiming a copy. Revealed state survives toggling motion off/on.
- Reduced motion exposes the sample code without a covering decal; material controls still work. Material use/durability information remains present on touch.
- Marquees stop offscreen/hidden, return upright after scrolling, and have a nearby pause button. Footer drag stickers have a touch area.
- Actual hero pricing links on fresh mobile/desktop/reduced visits land at Quote about 104px below the viewport top; sample links do likewise after deferred upstream pins are initialized.
- Large custom-size totals fit mobile without horizontal overflow or collapsing the sheet illustration.

Reports: `qa/final/axe-layout.json`, `interactions-fps.json`, `anchor-quote-edges.json`, `browser-results.json`.

## Scroll frame sampling

Each pin was sampled for 3 seconds with browser requestAnimationFrame while scrolling its complete range, in Chromium with the Metal GPU backend on this Mac. Every sample produced 180 frames:

| Pin | Average frame | 95th percentile | Frames >33ms | Long tasks >50ms |
| --- | --- | --- | --- | --- |
| Hero | 16.67ms | 16.7ms | 0 | 0 |
| How it works | 16.67ms | 16.7ms | 0 | 0 |
| Wrap | 16.67ms | 16.7ms | 0 | 0 |
| Products | 16.67ms | 16.8ms | 0 | 0 |
| Materials | 16.67ms | 16.8ms | 0 | 0 |

Material feature defines are kept compiled; an observed first-use iridescence compile hitch was fixed and the sampling repeated. These are warm-scene local frame samples, not measurements from every device or a cold GPU startup.

## Review and screenshots

Independent read-only design-reviewer passes compared the reference, source and fresh captures. All critical findings were fixed and the final review passed. Important fixes included quote controls escaping their form, shader compile stalls, stale anchor targets after lazy pins, fallback visibility at pin boundaries, a sample decal sticking over later sections, persisted peel state, mobile word wrapping and low-contrast captions.

Reviewed against the project's motion specification, the [Vercel Web Interface Guidelines](https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md) and the local Vercel React best-practice skill (conditional heavy imports, transient refs, listener cleanup and deferred work).

Screenshots are in ignored `qa/final/`: desktop/touch/low-tier/reduced layouts, 0/50/100% pin captures, code reveal, custom quote edges, and an overview. Earlier checkpoint captures remain in `qa/phase4/` and `qa/phase5/` for comparison; final evidence supersedes stale checkpoint overviews.

Subjective section scores are in PROGRESS.md. They are design self-assessments, separate from the measured audit results above.
