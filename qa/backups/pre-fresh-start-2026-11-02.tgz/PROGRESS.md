# Progress log

## 2026-11-01

### Phase 1: scaffold (done)
- Enabled pnpm via corepack (`corepack enable pnpm` → pnpm 12.16.1).
- `pnpm create next-app@latest labelbros-scaffold --ts --tailwind --eslint --app --src-dir --import-alias "@/*" --use-pnpm --yes`, moved everything except `.git`/`.next` to the root, merged `.gitignore`, deleted the temp folder, renamed the package to `labelbros`. `CLAUDE.md`, `.claude/`, `.mcp.json`, `reference/`, `claude-prompt.md` untouched.
- `git init` (branch `main`, nothing committed yet).
- `pnpm add gsap @gsap/react lenis three @react-three/fiber @react-three/drei` + `pnpm add -D @types/three` → gsap 3.15.0, @gsap/react 2.1.2, lenis 1.3.27, three 0.187.0, R3F 9.8.2, drei 10.7.9.
- `pnpm dlx shadcn@latest init -d` (style base-nova), React Bits registry added to `components.json`, installed StickerPeel, ShinyText, ScrollVelocity, Magnet, GlareHover (moved to `src/components/ui/`).
- Not installed: the three 21st.dev components (`API_KEY_21ST` not set). See PLAN.md question 1.
- Checks: `pnpm build` ✓ (static `/`), `pnpm tsc --noEmit` ✓ (exit 0, after build generated route types), `pnpm dev` → `GET / 200`.
- Notes: `motion` came in with ScrollVelocity (only importer); `cn` is shadcn's own class-merge package; StickerPeel creates its own WebGL2 context, so it is low-tier only.

### Phase 2: plan (approved)
- Wrote `PLAN.md`; approved with the default answers to every open question (custom S6/S10, Anton wordmark, SVG illustrations, flagged sample pricing, spec scroll lengths, default headline, no commits).

### Phase 3: foundation (done)
- Tokens in `globals.css` (`@theme`, default palette and type scale reset so only token values exist), Anton + Archivo (wdth axis) via `next/font`, fixed grey frame + fixed 24px paper grid, `type-hero/display/label/caption` utilities.
- `lib/gsap.ts` (all plugins + `slap`), `lib/lenis.ts`, `lib/scrollStore.ts`, `lib/motion.ts` (matchMedia conditions, footer toggle, device tier), `lib/palette.ts`.
- One shared canvas: `three/CanvasRoot.tsx` (desktop: idle after load; touch: near S3; never on low tier or reduced motion) + `three/Scene.tsx` (demand frameloop, hidden when no 3D moment is in view).
- Header (hide on scroll down, Magnet CTA, mobile sheet menu), Footer (Reduce motion switch, newsletter form that says it isn't connected), sticker set (Nº1 badge, flame, FRESH BATCH oval, SMALL BRAND tag, striped ball, BR/OS bubble, GOOD HONEY CO. label), Label Studio phone, static hero.
- Decisions: sticker text stays as `<text>`; textures embed `/fonts/anton-latin.woff2` (12 KB) as a data URI, so no outline script. The brief's `slap` path was malformed (missing a control point) → `M0,0 C0.2,0 0.1,1.12 0.5,1.04 C0.7,1 0.85,1 1,1`. shadcn's `cn` merge dropped `text-paper` next to `text-16`, so `cn` is now a plain join. Unused shadcn button, base-ui, cva, tw-animate-css removed.
- Verified: `pnpm tsc --noEmit` ✓, `pnpm lint` ✓ (fixed React Compiler ref rules in our code and the 4 React Bits files), hero at 1440 and 390 compared side by side with the reference (`hero-vs-reference.png`). Known warning: `THREE.Clock` deprecation comes from R3F internals.

### Phase 4: static pass (done, waiting for review)
- All sections built at full fidelity, no motion: S2 How it works (desktop stage with rail, step copy, sticker sheet, docked phone; 4 cards on touch/reduced), S3 Wrap (2D jar stand-in, keyboard radio chips), S4 Products (liner track + roll core; snap carousel on touch; grid on reduced), S5 Materials (2D finish sticker, list that doubles as controls), S6 Quote (working configurator with sample pricing, empty/updating/error states), S7 Reviews (sticker-bomb lid, logo rows, case studies), S8 Sample pack (peel sticker over code, PEEL button with aria-live + clipboard), S9 Final CTA (scalloped die-cut edge), footer curtain.
- Data in `src/data/{copy,products,materials,pricing,reviews,footer}.ts` with visible `[[PLACEHOLDERS]]`; voice copy marked `// COPY:`.
- Fixes found by screenshots: mobile layout viewport was 495px wide (long `[[SAMPLE_PRICE]]` + Magnet's inline `display` beating `hidden`) → `main` gets `overflow-x: clip`, Magnet wrapped; S4 track overflow clipped; display leading .86 → .9; inactive material names raised to `ink-soft` for contrast; footer stickers moved off the links; slider CSS missing → dev-server cache (restart).
- Verified: `pnpm tsc --noEmit` ✓, `pnpm lint` ✓, `pnpm build` ✓ (static `/`), horizontal overflow 0px at 1440 and 390, canvas never loads under reduced motion, loads on touch only near S3.
- Screenshots: `qa/phase4/` (per section at 1440 and 390, reduced-motion layouts, overview sheets).
- Next: Phase 5, signature moments in page order (S0/S1 first).

### Phase 5: signature moments (S0–S3 done, waiting for review)

**S0 Header.** Hide on scroll down / show on scroll up (0.35s expo.out), Magnet CTA (now honours the footer toggle live), keyboard focus brings a hidden header back and keeps it while focus is inside, mobile menu makes `main` and the footer `inert`, Escape returns focus to the Menu button. Verified with Tab presses and the menu in Playwright.

**S1 Hero.** Load (~1.4s): headline lines rise in CSS keyframes (spec values; the H1 is the LCP and never waits for JS), Nº1 + flame slap in with a landing squash, phone rises, DrawSVG traces the die line, editor handles pop, floating stickers drop in; steps/CTAs reveal. Scroll (desktop, pin +100%): all six stickers hand off to exact WebGL copies (`peel` shader: corner curl ≤ 0.3, white liner back face, contact shadow only near the paper) and orbit out by the right edge over 0→0.55 (inline pair first, then the four around the phone); lines slide out through their masks, steps/CTAs slide out with them; phone eases to centre at scale .92; camera dollies in 6%. Touch: load only + tap-to-peel on Nº1 + CSS wobble. Low tier: same pin with a 2D peel (stickers stay opaque, leave by the right edge). Reduced motion: static composition.
- Verified: 60fps through the pin (0 frames > 20ms, 0 long tasks), hand-off pixel-exact (`qa/phase5/s1/overlay1-h1.png` vs `overlay3-h1.png`), no console errors (only R3F's own `THREE.Clock` deprecation), touch / low / reduced captures in `qa/phase5/s1/`.
- Fixed on the way: GSAP folds CSS `rotate`/`translate` into its transform (tilts moved to inner spans); `autoAlpha` pinned an inline `visibility` that beat the 3D hand-off rule (opacity only for stickers); reduced-motion CSS lost on specificity; the canvas wrapper from R3F had `pointer-events: auto` and blocked clicks (now `none`).
- Design review (subagent) applied: rest frame keeps the DOM stickers (no idle GPU work, no halo shadows), single peel idea for all stickers, curl capped, shadows fade by z 0.5, intro starts on mount, low-tier stickers no longer fade like ghosts, header focus + inert menu, mobile hero type 20.5vw, phone label larger. Declined: hiding `[[PLACEHOLDERS]]` (the brief requires them visible), a shaped die (the same rectangular label wraps the jar in S3), `aria-hidden` on the canvas (the brief asks for `role="img"` + description; description made accurate).
- Self-critique: fidelity 9 · signature 9 · craft 8 · performance 9 · accessibility 8.

### Continuation: full brief resumed (2026-11-01)

Read `claude-prompt.md`, `CLAUDE.md`, local Next.js guides and project skills. User requested continuation through the whole prompt. Retained local work, placeholders and no-commit/no-deploy defaults.

**S2/S3 review closed.** Independent read-only review found a static low-tier wrap, a persistent hero camera dolly, a broken label bridge and cached texture lifetime gaps. Added aligned flat/half/wrapped AVIFs, scoped the dolly to the hero, carried the same cut label into the jar's flat-label coordinates, and released shared maps after scene unmount (with Strict Mode protection). Killed finish tweens on unmount. Corrected stale fallback ownership using both `data-three` and `data-scenes`.

**S4 Products.** Pinned horizontal liner, rotating procedural roll, containerAnimation card peels, counter, GlareHover. Touch uses native snap + observed peels; reduced motion keeps the grid. Keyboard focus moves the pin to the focused product.

**S5 Materials.** MeshPhysicalMaterial interpolates finishes, with opaque ink, a white die-cut rim, film transparency, iridescence, glitter sparkle and kraft normal fibres. Damped pointer tilt, snap controls, tint layer, ShinyText, touch summary, circle-wipe/poster fallback. Narrow environment lights + gently curved film normals make chrome visibly metallic. Kept physical features compiled at negligible epsilon values: first-use compile hitch eliminated.

**S6 Quote.** Scoped Flip assembly in normal flow, decorative price count and quantity sheet-stack motion. Minimum-order floor now included in the displayed unit price and next-break savings; currency totals rounded to cents. Custom size validation, empty/deferred updating/error states; invalid continuation cannot navigate. Added three regression tests covering minimum order, breaks, size/material changes and invalid input.

**S7 Reviews.** Batched sticker slaps, two reversible velocity marquees, skew resets at scroll end, nearby pause button. Removed unused ScrollVelocity/Motion dependency.

**S8 Sample.** Teaser curl, Draggable/Inertia proxy drives the shared peel shader; release threshold reveals/copies the code and announces success/failure honestly. PEEL duplicates the drag action. Revealed state survives the motion toggle. Reduced motion exposes code without the covering decal; low tier uses DOM transforms and needs no WebGL.

**S9/S10.** SplitText stamp with no intra-word line breaks, deterministic 14/8-sticker Physics2D burst, curtain and bounded inertial footer stickers including a reserved touch area. Added LB vector app icon.

**Independent review fixes.** Applied all material findings: touch material information, fallback visibility at the ends of pins, reduced-motion sample visibility, persisted peel state, mobile CTA word wrapping, skew reset, touch footer stickers, finish distinction. Fixed our first Flip implementation (absolute controls escaped the form) and a stale sample canvas position (scroll needed explicit invalidation).

**Verification.** Typecheck, lint and static production build pass. Pricing tests 3/3. Axe: zero violations at 390/768/1280/1440/1920 in reduced motion; zero violations in the normal-motion interactive walkthrough. Horizontal overflow 0, exactly one H1, zero reduced-motion canvases/pins. Browser console: no application errors. Finish arrows, custom-size validation, drag/clipboard, persisted peel, header focus and mobile inert/Escape verified. Five 3-second pin samples: 180 frames each, ~16.67 ms average, 0 frames >33ms, 0 long tasks. Lighthouse and screenshot links are recorded in QA.md.

**Self-critique (fidelity / signature / craft / performance / accessibility).** Subjective review scores, distinct from measured checks:
- S0: 9 / 8 / 9 / 9 / 9
- S1: 9 / 9 / 8 / 9 / 9
- S2: 9 / 9 / 8 / 9 / 9
- S3: 9 / 9 / 8 / 9 / 9
- S4: 9 / 9 / 8 / 9 / 9
- S5: 9 / 9 / 8 / 9 / 9
- S6: 9 / 8 / 9 / 9 / 9
- S7: 9 / 8 / 8 / 9 / 9
- S8: 9 / 9 / 8 / 9 / 9
- S9: 9 / 9 / 8 / 9 / 9
- S10: 9 / 8 / 8 / 9 / 9

**Default-style audit.** Retained the reference's pills, condensed Anton, flat stickers and grid. Removed the generated Next icon/README and unused Motion dependency. Finish gradients/reflections are material depictions; no generic fade-up sequence, glass cards, SaaS palette or stock hero was introduced.

**Handoff.** README documents setup, copy/tokens/pricing/models, store ownership, motion/fallbacks and all open placeholders. QA evidence stays in ignored `qa/final/`; no Git commit, push or deployment. Backend/commerce/help/legal destinations and client facts remain explicit launch inputs.

**Final edge fixes and audit.** Independent final review passes. Primary anchors now initialize preceding deferred pin layouts before resolving the destination; fresh desktop/touch/reduced pricing and sample landings are ~104px below the top. Large custom totals wrap and use smaller display type. Footer drag setup waits for a normal-flow marker; hidden curtain content no longer contributes startup layout shifts, and keyboard focus reveals/scrolls the footer. Final Lighthouse: mobile **100 / 100 / 100 / 100** (LCP 0.9s, TBT 30ms, CLS 0); desktop **100 / 100 / 100 / 100** (LCP 0.3s, TBT 0ms, CLS 0.014). Order: Performance / Accessibility / Best Practices / SEO.

## 2026-11-01 (later): industrial redesign, whole-page pass

**Why.** Client feedback: the sticker/zine look was too playful. The page is now aimed at B2B buyers (food & beverage, defense, automotive, industrial) and has to say clearly that Label Bros designs labels *and* prints customers' own artwork. The new direction, "Production spec", is documented in `reference/DESIGN-DIRECTION.md`. CLAUDE.md, the `labelbros-motion` skill docs and the `design-reviewer` agent now point at it, and the Pinterest reference is retired.

**Backup.** Before any edits: `qa/backups/pre-industrial-redesign-2026-11-01.tgz` (src, public, docs, skill, reference). Nothing is committed in git yet.

**Foundation.** New tokens (paper/sheet/line/ink/graphite/steel, International Orange signal, CMY print marks only), Mona Sans as the only UI font (Anton remains embedded for label artwork and textures), 2px radii, column guides instead of the 24px graph grid, no artboard frame, a `press` CustomEase (no overshoot) instead of `slap`. New atoms: `ui/Button.tsx` (arrow tab), `ui/PrintMarks.tsx` (crop marks, registration target, colour bar), `SectionHead`/`IndexRule` (numbered section rules, optional `aside`), and segmented `FinishChips`/`ChipRadio`.

**Sections.**
- Header: logo mark plus wordmark, sentence-case nav (Industries, Products, Materials, Process, Samples), sign in, cart, "Get a quote".
- Hero: "Labels built to spec.", both artwork paths, and a fact row. The right half is the graphite specimen bench (food, defense, automotive and industrial labels with die line, crop marks, dimensions and spec table). It auto-cycles with tabs, a pause button and an off-screen/hover/focus hold, and never autoplays under reduced motion.
- New sections: the client logo strip and Industries (registration plates on scroll).
- Artwork: "Your artwork, or ours", two equal paths (prepress check panel, designer v1 with markup) whose junction draws to "Proof approved".
- Process: spec, proof, print, ship on a line that fills as you scroll.
- Application: Northfield Pantry honey label on an amber jar, with the shader stock colour moved to cream.
- Products: eight industrial label types with new technical illustrations; the 3D roll texture now shows ID labels.
- Materials: eight films on a new square material-test plate.
- Quote: square tiles, a graphite price panel with a job-ticket summary; industrial product and material options (test ids kept).
- Reviews: a calm ruled grid with industry tags, a logo grid and case studies with specimen art.
- Sample kit: graphite band; the peel is now a tamper-evident security seal over a VOID pattern.
- Final CTA: "Send the spec. Get the proof." with the trim moment.
- Footer: graphite with a full-width wordmark.

**Removed.** Hero 3D stickers, the CutLabel hand-off, the Label Studio phone, DesignFaces, HowVisuals, ReviewSticker/marquee, Magnet, GlareHover, ShinyText, StickerPeel, the Pill component, and the AVIF posters. Low tier and reduced motion now use the 2D jar and the 2D plate, because the old posters showed the retired art.

**Verified.** `pnpm tsc --noEmit` ✓, `pnpm lint` ✓, `pnpm build` ✓ (static `/`), pricing tests 3/3 ✓. Axe at 1440 and 390 (reduced) and 1440 (motion): the last open item (the half-dimmed proof node) was fixed afterwards. One H1, 0px horizontal overflow at 1440 and 390. Screenshots are in the session scratchpad (`review/`, `v1`–`v3`).

**Next.** Section-by-section deep redesign with the client, starting from the hero. Open: replace placeholders, decide whether low-tier wrap posters are worth regenerating with the new label, and re-run Lighthouse after the redesign.

**Independent review (design-reviewer) and fixes, same pass.** Verdict: about 80% there; the hero bench and closing CTA hold up at Awwwards level. Fixed now:
- **Focus ring:** ink on paper (orange was 2.9:1 there).
- **Figures:** tabular off; Mona Sans's tabular zeros are slashed.
- **Artwork paths:** equal CTAs, a steady proof node with a "free proof" note, links to the real actions, an Artwork nav item, both paths repeated under the final CTA.
- **Header:** one CTA label, "Pricing" button on mobile.
- **Page order:** Quote moved before Materials (sections renumbered 06/07).
- **Process:** no icons, a 2px line, aligned captions.
- **Reviews:** 3 quotes, duplicate logo grid removed, eyebrow "Customers".
- **Leftover sticker treatments:** flatter material plate (thin cut edge, smaller radius, no tilt); warning decal without the sticker outline; single card outline on products; numbering trimmed.
- **Hero:** fits 1280×800 and 1366×768 laptops.

Deferred to the section passes: the sample-kit concept for B2B (kit contents vs. peel-for-code), a neutral container instead of the honey jar, varied label art per section (the same four specimens repeat), quote units (in/mm), log-spaced ticks and a 10k+ option, and the footer wordmark.

**Dev server note.** The `next dev` on :3000 (started earlier, ~2h uptime) stopped recompiling CSS mid-session. It needs a restart to show the latest styles. Verification ran on a production build served from :3100 (`.claude/launch.json` → `labelbros-prod`): axe 0 violations (1440 motion, 1440 reduced, 390 reduced), 0px overflow, build ✓, tsc ✓, lint ✓, tests 3/3 ✓.
