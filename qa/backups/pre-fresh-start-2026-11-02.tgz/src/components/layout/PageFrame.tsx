/**
 * Column guides behind every light section: one fixed layer, clipped to <main> by main's
 * clip-path, so pinned sections never show a seam. Dark sections paint over it.
 */
export function PaperGuides() {
  return <div aria-hidden="true" className="paper-guides pointer-events-none fixed inset-0 -z-10" />;
}
