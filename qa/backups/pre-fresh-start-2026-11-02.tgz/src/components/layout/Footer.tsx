"use client";

import { useId, useState, useSyncExternalStore } from "react";
import { FooterMotion } from "@/components/sections/motion/FooterMotion";
import { RegMark } from "@/components/ui/PrintMarks";
import { brand } from "@/data/copy";
import { company, footerColumns, socials } from "@/data/footer";
import { gsap } from "@/lib/gsap";
import { REDUCE_EVENT, setUserReducedMotion, userReducedMotion } from "@/lib/motion";
import { cn } from "@/lib/utils";

const subscribeReduce = (cb: () => void) => {
  window.addEventListener(REDUCE_EVENT, cb);
  return () => window.removeEventListener(REDUCE_EVENT, cb);
};

export function Footer() {
  const reduce = useSyncExternalStore(subscribeReduce, userReducedMotion, () => false);
  const [note, setNote] = useState("");
  const emailId = useId();

  const toggleReduce = () => {
    setUserReducedMotion(!reduce);
    gsap.matchMediaRefresh();
  };

  return (
    <footer className="relative z-0 overflow-hidden bg-graphite text-paper page-x pt-20 pb-8 lg:pt-24 curtain:sticky curtain:bottom-0" data-footer>
      <div className="grid grid-cols-12 gap-x-6 gap-y-14">
        <div className="col-span-12 lg:col-span-4">
          <p className="flex items-center gap-2.5 text-18">
            <RegMark className="size-5 text-signal" />
            <span className="wordmark">{brand.wordmark}</span>
          </p>
          <p className="mt-6 max-w-[30ch] text-16 leading-relaxed text-steel">
            Custom labels for food, defense, automotive and industry. Printed to spec, proofed before press. {/* COPY: */}
          </p>
          <form
            className="mt-10 max-w-sm"
            onSubmit={(e) => {
              e.preventDefault();
              // [[NEWSLETTER_ENDPOINT]]: not connected yet, so say so instead of faking a signup.
              setNote("Signup isn't connected yet. Email us instead.");
            }}
          >
            <label htmlFor={emailId} className="type-meta block text-paper">
              Production notes: material guides, monthly {/* COPY: */}
            </label>
            <div className="mt-3 flex border-b border-white/25 focus-within:border-paper">
              <input
                id={emailId}
                type="email"
                name="email"
                spellCheck={false}
                required
                autoComplete="email"
                placeholder="you@company.com"
                className="h-12 min-w-0 flex-1 bg-transparent text-16 text-paper placeholder:text-steel focus:outline-none"
              />
              <button type="submit" className="type-label h-12 px-1 text-15 text-paper hover:text-signal">
                Subscribe →
              </button>
            </div>
            <p aria-live="polite" className="mt-3 min-h-5 text-14 text-steel">
              {note}
            </p>
          </form>
        </div>

        <nav aria-label="Footer" className="col-span-12 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-4 lg:col-span-8">
          {footerColumns.map((col) => (
            <div key={col.title}>
              <h2 className="type-meta text-steel">{col.title}</h2>
              <ul className="mt-4 flex flex-col">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <a href={link.href} className="inline-flex min-h-10 items-center text-15 text-paper/85 transition-colors hover:text-paper">
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
      </div>

      <p aria-hidden="true" className="wordmark mt-20 text-[clamp(3.5rem,13.6vw,15rem)] leading-[0.8] tracking-[-0.045em] whitespace-nowrap text-paper lg:mt-28">
        {brand.wordmark}
      </p>

      <div className="mt-10 flex flex-col gap-6 border-t border-white/15 pt-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="type-meta flex flex-wrap items-center gap-x-6 gap-y-2 text-steel">
          <span>{company.email}</span>
          <span>{company.hours}</span>
          <span>{company.address}</span>
          <span>{company.certifications}</span>
        </div>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
          <ul className="flex items-center gap-x-6">
            {socials.map((s) => (
              <li key={s.label}>
                <a href={s.href} className="type-meta inline-flex min-h-11 items-center text-paper hover:text-signal">
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
          <button type="button" role="switch" aria-checked={reduce} onClick={toggleReduce} className="type-meta inline-flex min-h-11 items-center gap-3 text-paper">
            Reduce motion
            <span aria-hidden="true" className={cn("relative h-5 w-9 rounded-xs border transition-colors", reduce ? "border-signal bg-signal" : "border-white/30")}>
              <span className={cn("absolute top-[3px] left-0 size-3 rounded-[1px] transition-transform", reduce ? "translate-x-[18px] bg-ink" : "translate-x-[3px] bg-paper")} />
            </span>
          </button>
        </div>
      </div>

      <p className="type-meta mt-6 text-steel">
        © 2026 {brand.name} ·{" "}
        <a href="/privacy" className="underline underline-offset-2 hover:text-paper">
          Privacy
        </a>{" "}
        ·{" "}
        <a href="/terms" className="underline underline-offset-2 hover:text-paper">
          Terms
        </a>
      </p>
      <FooterMotion />
    </footer>
  );
}
