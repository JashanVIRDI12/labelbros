"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ButtonLink } from "@/components/ui/Button";
import { RegMark } from "@/components/ui/PrintMarks";
import { brand, cta, nav } from "@/data/copy";
import { gsap, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { getLenis, scrollToTarget } from "@/lib/lenis";
import { MQ, motionFlags } from "@/lib/motion";
import { cn } from "@/lib/utils";

const CART_COUNT = 0;

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <RegMark className="size-[1.15em] text-signal" />
      <span className="wordmark whitespace-nowrap">{brand.wordmark}</span>
    </span>
  );
}

const navLink =
  "type-label relative inline-flex h-11 items-center text-15 text-ink/75 transition-colors hover:text-ink " +
  "after:absolute after:inset-x-0 after:bottom-2.5 after:h-px after:origin-right after:scale-x-0 after:bg-ink after:transition-transform after:duration-300 " +
  "hover:after:origin-left hover:after:scale-x-100";

export function Header() {
  const headerRef = useRef<HTMLElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);
  const openRef = useRef(open);
  useEffect(() => {
    openRef.current = open;
  }, [open]);

  // Hide on scroll down, show on scroll up.
  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ, (ctx) => {
        if (motionFlags(ctx.conditions).reduceMotion) return;
        let hidden = false;
        const set = (hide: boolean) => {
          if (hide === hidden) return;
          hidden = hide;
          gsap.to(headerRef.current, { yPercent: hide ? -100 : 0, duration: 0.4, ease: "expo.out", overwrite: true });
        };
        ScrollTrigger.create({
          start: 0,
          end: "max",
          onUpdate: (self) => {
            if (openRef.current || self.scroll() < 160 || headerRef.current?.contains(document.activeElement)) return set(false);
            set(self.direction === 1);
          },
        });
        const reveal = () => set(false);
        headerRef.current?.addEventListener("focusin", reveal);
        return () => {
          headerRef.current?.removeEventListener("focusin", reveal);
          gsap.killTweensOf(headerRef.current);
          gsap.set(headerRef.current, { yPercent: 0 });
        };
      });
    },
    { scope: headerRef },
  );

  const close = useCallback(() => {
    setOpen(false);
    menuButtonRef.current?.focus();
  }, []);

  // Menu links: close first (restores scrolling), then scroll on the next frame.
  const go = (href: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    close();
    requestAnimationFrame(() => scrollToTarget(href));
  };

  useEffect(() => {
    if (!open) return;
    const lenis = getLenis();
    lenis?.stop();
    document.documentElement.style.overflow = "hidden";
    const behind = [document.getElementById("main"), document.querySelector("footer")].filter(Boolean) as HTMLElement[];
    behind.forEach((el) => (el.inert = true));
    menuRef.current?.querySelector<HTMLElement>("a")?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    return () => {
      lenis?.start();
      document.documentElement.style.overflow = "";
      behind.forEach((el) => (el.inert = false));
      window.removeEventListener("keydown", onKey);
    };
  }, [open, close]);

  return (
    <>
      <header
        ref={headerRef}
        className="fixed inset-x-0 top-0 z-40 flex items-center border-b border-line bg-paper page-x"
        style={{ height: "var(--header-h)" }}
      >
        <a href="#top" className="mr-12 inline-flex h-11 items-center text-[17px]" aria-label={`${brand.name} home`}>
          <Logo />
        </a>

        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-8">
            {nav.map((item) => (
              <li key={item.label}>
                <a href={item.href} className={navLink}>
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="ml-auto flex items-center gap-6 lg:gap-7">
          {/* display lives on the wrapper: the links carry their own inline-flex */}
          <div className="hidden lg:block">
            <a href="#signin" className={navLink}>
              Sign in
            </a>
          </div>
          <a href="#quote" className={cn(navLink, "max-lg:hidden")}>
            Cart
            <span className="ml-1.5 inline-flex h-5 min-w-5 items-center justify-center rounded-xs bg-ink/[0.07] px-1 text-12 text-ink">
              {CART_COUNT}
              <span className="sr-only"> items</span>
            </span>
          </a>
          <ButtonLink href={cta.primary.href} size="md" arrow>
            <span className="lg:hidden">Pricing</span>
            <span className="max-lg:hidden">{cta.primary.label}</span>
          </ButtonLink>
          <button
            ref={menuButtonRef}
            type="button"
            className="type-label inline-flex h-11 items-center gap-3 text-15 lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? "Close" : "Menu"}
            <span aria-hidden="true" className="relative block h-2.5 w-5">
              <span className={cn("absolute left-0 h-px w-5 bg-ink transition-transform duration-300", open ? "top-[5px] rotate-45" : "top-0")} />
              <span className={cn("absolute left-0 h-px w-5 bg-ink transition-transform duration-300", open ? "top-[5px] -rotate-45" : "top-2.5")} />
            </span>
          </button>
        </div>
      </header>

      <div
        id="mobile-menu"
        ref={menuRef}
        hidden={!open}
        className="fixed inset-x-0 bottom-0 z-40 overflow-y-auto bg-paper page-x pb-10 lg:hidden"
        style={{ top: "var(--header-h)" }}
      >
        <nav aria-label="Mobile">
          <ul className="flex flex-col">
            {nav.map((item, i) => (
              <li key={item.label} className="border-b border-line">
                <a href={item.href} onClick={go(item.href)} className="flex items-baseline gap-4 py-5">
                  <span className="type-meta text-signal-text">{String(i + 1).padStart(2, "0")}</span>
                  <span className="type-display text-40">{item.label}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <div className="mt-10 flex flex-col gap-3">
          <ButtonLink href={cta.primary.href} onClick={go(cta.primary.href)} arrow>
            {cta.primary.label}
          </ButtonLink>
          <ButtonLink href="#signin" onClick={go("#signin")} variant="outline">
            Sign in
          </ButtonLink>
        </div>
      </div>
    </>
  );
}
