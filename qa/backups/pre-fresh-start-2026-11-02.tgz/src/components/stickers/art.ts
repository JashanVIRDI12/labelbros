import { C } from "@/lib/palette";

/**
 * Label artwork used both inline in the DOM (via <Sticker>) and rasterised as a WebGL texture
 * (three/stickerTexture.ts), so the 2D and 3D versions always match. Text uses
 * font-family="Anton": in the DOM a CSS rule maps it to the embedded label face, in textures the
 * same font is embedded as a data URI.
 */
export type StickerArt = {
  id: string;
  /** accessible name when the art carries meaning */
  label: string;
  w: number;
  h: number;
  svg: string;
};

const W = C.white;
const FONT = `font-family="Anton"`;

const hex = (cx: number, cy: number, r: number) => {
  const pts = Array.from({ length: 6 }, (_, i) => {
    const a = (Math.PI / 3) * i + Math.PI / 6;
    return `${(cx + r * Math.cos(a)).toFixed(1)},${(cy + r * Math.sin(a)).toFixed(1)}`;
  });
  return `<polygon points="${pts.join(" ")}"/>`;
};

const AMBER = "#A4521A";

/**
 * S4: the food label that wraps the jar (same customer as the hero's chili oil). A customer's
 * artwork, so it keeps its own brand colours. 480 × 200, white die-cut edge, cream stock: the
 * wrap shader treats the cream as printable stock (finishes apply there, ink stays ink).
 */
export const honeyLabel: StickerArt = {
  id: "honey",
  label: "Northfield Pantry raw wildflower honey label",
  w: 480,
  h: 200,
  svg: `
  <rect x="4" y="4" width="472" height="192" rx="18" fill="${W}"/>
  <rect x="11" y="11" width="458" height="178" rx="12" fill="${C.cream}"/>
  <rect x="22" y="22" width="436" height="156" rx="6" fill="none" stroke="${C.ink}" stroke-width="1.5"/>
  <g fill="none" stroke="${C.ink}" stroke-width="2.5">${hex(70, 88, 17)}${hex(100, 88, 17)}</g>
  <g fill="${AMBER}">${hex(85, 114, 17)}</g>
  <line x1="138" y1="44" x2="138" y2="156" stroke="${C.ink}" stroke-width="1"/>
  <text ${FONT} x="160" y="60" font-size="13" letter-spacing="4" fill="${C.ink}">NORTHFIELD PANTRY</text>
  <text ${FONT} x="158" y="114" font-size="54" letter-spacing=".5" fill="${C.ink}">RAW HONEY</text>
  <text ${FONT} x="160" y="142" font-size="17" letter-spacing="2.6" fill="${AMBER}">WILDFLOWER · UNFILTERED</text>
  <text ${FONT} x="160" y="163" font-size="11" letter-spacing="2" fill="${C.ink}">NET WT 12 OZ (340 g)</text>`,
};

/** S9: the tamper-evident security seal that hides the sample-kit code. */
export const peelMe: StickerArt = {
  id: "peel",
  label: "Tamper-evident security seal: peel to reveal",
  w: 300,
  h: 300,
  svg: `
  <defs>
    <path id="seal-top" d="M44 150A106 106 0 0 1 256 150"/>
    <path id="seal-bot" d="M30 150A120 120 0 0 0 270 150"/>
  </defs>
  <circle cx="150" cy="150" r="148" fill="${W}"/>
  <circle cx="150" cy="150" r="141" fill="${C.silver}"/>
  ${[132, 122, 112, 92, 72].map((r) => `<circle cx="150" cy="150" r="${r}" fill="none" stroke="${W}" stroke-opacity=".35" stroke-width="1"/>`).join("")}
  <circle cx="150" cy="150" r="141" fill="none" stroke="${C.ink}" stroke-width="2.5"/>
  <circle cx="150" cy="150" r="98" fill="none" stroke="${C.ink}" stroke-width="1.5"/>
  <text ${FONT} font-size="17" letter-spacing="4" fill="${C.ink}"><textPath href="#seal-top" startOffset="50%" text-anchor="middle">TAMPER-EVIDENT SEAL</textPath></text>
  <text ${FONT} font-size="13" letter-spacing="3" fill="${C.ink}"><textPath href="#seal-bot" startOffset="50%" text-anchor="middle">LABEL BROS  ·  NO. 000427</textPath></text>
  <rect x="96" y="104" width="108" height="10" fill="${C.signal}"/>
  <g ${FONT} fill="${C.ink}" text-anchor="middle">
    <text x="150" y="176" font-size="62" letter-spacing="2">PEEL</text>
    <text x="150" y="204" font-size="15" letter-spacing="5">TO REVEAL</text>
  </g>
  <path d="M226 214l18 18m0 0v-15m0 15h-15" fill="none" stroke="${C.ink}" stroke-width="4" stroke-linecap="square"/>`,
};
