import { barcode, dataMatrix, defenseLabel } from "@/components/labels/labelArt";
import { C } from "@/lib/palette";
import type { StickerArt } from "./art";

/**
 * S5 product illustrations: technical, flat, ink-led, one signal accent. 300 × 225 each.
 * Labels shown inside them are customers' artwork, so they may use real safety colours.
 */

const FONT = `font-family="Anton"`;
const ink = C.ink;
const W = 300;
const H = 225;
const art = (id: string, label: string, svg: string): StickerArt => ({ id: `product-${id}`, label, w: W, h: H, svg });

const roll = art(
  "roll",
  "Roll of labels unspooling on its liner",
  `
  <rect x="96" y="158" width="196" height="26" fill="${C.frame}" stroke="${ink}" stroke-width="1.5"/>
  ${[150, 198, 246]
    .map((x) => `<rect x="${x}" y="162" width="40" height="18" rx="2" fill="${C.white}" stroke="${ink}" stroke-width="1"/><rect x="${x}" y="162" width="40" height="5" fill="${ink}"/>`)
    .join("")}
  <circle cx="98" cy="96" r="72" fill="${C.white}" stroke="${ink}" stroke-width="2"/>
  ${[62, 52, 42].map((r) => `<circle cx="98" cy="96" r="${r}" fill="none" stroke="${ink}" stroke-opacity=".14" stroke-width="1"/>`).join("")}
  <circle cx="98" cy="96" r="27" fill="${C.paper}" stroke="${ink}" stroke-width="2"/>
  <circle cx="98" cy="96" r="13" fill="none" stroke="${ink}" stroke-width="1.5"/>
  <rect x="94" y="22" width="8" height="14" fill="${C.signal}"/>`,
);

const product = art(
  "product",
  "Bottle with a printed product label",
  `
  <rect x="134" y="14" width="32" height="22" rx="2" fill="${C.signal}"/>
  <path d="M138 36h24v18c0 9 34 15 34 37v114a8 8 0 0 1-8 8h-76a8 8 0 0 1-8-8V91c0-22 34-28 34-37z" fill="${ink}"/>
  <rect x="104" y="104" width="92" height="74" fill="${C.cream}"/>
  <rect x="104" y="104" width="92" height="74" fill="none" stroke="${ink}" stroke-opacity=".25"/>
  <text ${FONT} x="112" y="128" font-size="17" letter-spacing=".5" fill="${ink}">SMOKED</text>
  <text ${FONT} x="112" y="146" font-size="17" letter-spacing=".5" fill="#B3261E">CHILI OIL</text>
  <rect x="112" y="154" width="44" height="3" fill="${ink}" opacity=".5"/>
  ${barcode(160, 155, 28, 16, 3)}
  <rect x="112" y="64" width="6" height="34" rx="3" fill="${C.white}" opacity=".18"/>`,
);

const asset = art("asset", "Metallised asset ID tag with serial number and 2D code", `<g transform="translate(40 57) scale(.55)">${defenseLabel.svg}</g>`);

const warning = art(
  "warning",
  "Triangular general-warning safety decal",
  `
  <path d="M150 34 258 196H42Z" fill="#FFD200" stroke="${ink}" stroke-width="11" stroke-linejoin="round"/>
  <rect x="142" y="88" width="16" height="62" rx="3" fill="${ink}"/>
  <rect x="142" y="160" width="16" height="16" rx="3" fill="${ink}"/>`,
);

const serial = (x: number, y: number, n: string, seed: number) => `
  <g transform="translate(${x} ${y})">
    <rect width="170" height="70" rx="4" fill="${C.white}" stroke="${ink}" stroke-width="1.5"/>
    <text ${FONT} x="12" y="26" font-size="11" letter-spacing="2" fill="${ink}">SERIAL</text>
    <text ${FONT} x="12" y="54" font-size="19" letter-spacing=".5" fill="${ink}">SN 000127<tspan fill="${C.signal}">${n}</tspan></text>
    ${barcode(116, 14, 42, 42, seed)}
  </g>`;
const variable = art("variable", "Three sequentially numbered serial labels", `${serial(30, 26, "5", 31)}${serial(60, 76, "6", 32)}${serial(90, 126, "7", 33)}`);

const voidRows = Array.from({ length: 5 }, (_, r) =>
  Array.from({ length: 6 }, (_, c) => `<text ${FONT} x="${46 + c * 38 + (r % 2) * 19}" y="${70 + r * 26}" font-size="15" letter-spacing="1" fill="${C.hazard}" opacity=".85">VOID</text>`).join(""),
).join("");
const tamper = art(
  "tamper",
  "Tamper-evident seal partly lifted to show a VOID pattern",
  `
  <rect x="34" y="44" width="232" height="138" rx="4" fill="${C.white}" stroke="${ink}" stroke-opacity=".2"/>
  <clipPath id="void-clip"><rect x="34" y="44" width="232" height="138" rx="4"/></clipPath>
  <g clip-path="url(#void-clip)">${voidRows}</g>
  <path d="M34 48a4 4 0 0 1 4-4h150l-44 138H38a4 4 0 0 1-4-4z" fill="${C.silver}"/>
  <path d="M188 44 144 182l66-30z" fill="${C.white}" stroke="${ink}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M34 48a4 4 0 0 1 4-4h150l-44 138H38a4 4 0 0 1-4-4z" fill="none" stroke="${ink}" stroke-width="1.5"/>
  <text ${FONT} x="48" y="96" font-size="22" letter-spacing="1.5" fill="${ink}">SECURITY</text>
  <text ${FONT} x="48" y="122" font-size="22" letter-spacing="1.5" fill="${ink}">SEAL</text>
  <text ${FONT} x="48" y="146" font-size="10" letter-spacing="2" fill="${ink}">DO NOT REMOVE</text>`,
);

const clear = art(
  "clear",
  "Glass bottle with a clear label: only the printed ink shows",
  `
  <rect x="134" y="14" width="32" height="18" rx="2" fill="${ink}"/>
  <path d="M138 32h24v22c0 9 34 15 34 37v114a8 8 0 0 1-8 8h-76a8 8 0 0 1-8-8V91c0-22 34-28 34-37z" fill="#E6ECEE" stroke="${ink}" stroke-width="2"/>
  <rect x="106" y="106" width="88" height="70" fill="none" stroke="${ink}" stroke-opacity=".35" stroke-dasharray="3 3"/>
  <text ${FONT} x="150" y="134" font-size="15" letter-spacing="2" fill="${ink}" text-anchor="middle">NORDIC</text>
  <text ${FONT} x="150" y="154" font-size="15" letter-spacing="2" fill="${ink}" text-anchor="middle">SPRING</text>
  <rect x="140" y="164" width="20" height="2" fill="${C.signal}"/>
  <rect x="112" y="66" width="6" height="128" rx="3" fill="${C.white}" opacity=".8"/>`,
);

const hex = (r: number) =>
  Array.from({ length: 6 }, (_, i) => {
    const a = (Math.PI / 3) * i - Math.PI / 2;
    return `${(150 + r * Math.cos(a)).toFixed(1)} ${(112 + r * Math.sin(a)).toFixed(1)}`;
  }).join("L");
const decal = art(
  "decal",
  "Hexagonal die-cut decal with a white cut border",
  `
  <path d="M${hex(92)}Z" fill="${C.white}" stroke="${C.white}" stroke-width="10" stroke-linejoin="round"/>
  <path d="M${hex(92)}Z" fill="none" stroke="${ink}" stroke-opacity=".18" stroke-width="1" stroke-dasharray="3 3"/>
  <path d="M${hex(80)}Z" fill="${ink}"/>
  <path d="M110 92l40-22 40 22v14l-40-22-40 22zM110 120l40-22 40 22v14l-40-22-40 22z" fill="${C.signal}"/>
  <text ${FONT} x="150" y="168" font-size="20" letter-spacing="3" fill="${C.white}" text-anchor="middle">UNIT 07</text>`,
);

export const productArt: Record<string, StickerArt> = { roll, product, asset, warning, variable, tamper, clear, decal };

// ---------------------------------------------------------------- S6 finish morph: material test plate
const plate = "M22 10H298A12 12 0 0 1 310 22V298A12 12 0 0 1 298 310H22A12 12 0 0 1 10 298V22A12 12 0 0 1 22 10Z";

export const finishSticker = {
  w: 320,
  h: 320,
  shape: plate,
  ink: `
  <path d="M22 10H298A12 12 0 0 1 310 22V70H10V22A12 12 0 0 1 22 10Z" fill="${ink}"/>
  <text ${FONT} x="30" y="52" font-size="26" letter-spacing="2" fill="${C.white}">LABEL BROS</text>
  <rect x="268" y="32" width="22" height="16" fill="${C.signal}"/>
  <text ${FONT} x="30" y="104" font-size="11" letter-spacing="2.4" fill="${ink}">MATERIAL TEST · PART NO.</text>
  <text ${FONT} x="29" y="146" font-size="40" letter-spacing=".5" fill="${ink}">LB-0726-M</text>
  <text ${FONT} x="30" y="174" font-size="11" letter-spacing="2.4" fill="${ink}">LOT 26-11  ·  REV A</text>
  ${dataMatrix(218, 90, 72, 12, 5)}
  ${barcode(30, 198, 260, 62, 21)}
  <text ${FONT} x="160" y="286" font-size="12" letter-spacing="4" fill="${ink}" text-anchor="middle">0 72615 00418 3</text>`,
};
