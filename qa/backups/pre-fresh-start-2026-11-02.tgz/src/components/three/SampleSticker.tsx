"use client";

import { useEffect, useRef, useState } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { peelMe } from "@/components/stickers/art";
import { scrollStore } from "@/lib/scrollStore";
import { setThreeFlag } from "@/lib/threeFlags";
import { worldPerPx } from "./anchors";
import { peelFragment, peelUniforms, peelVertex } from "./shaders/peel";
import { stickerTexture } from "./stickerTexture";

export function SampleSticker() {
  const [map, setMap] = useState<THREE.Texture | null>(null);
  useEffect(() => {
    let alive = true;
    stickerTexture(peelMe).then((t) => { if (alive) setMap(t); });
    return () => { alive = false; };
  }, []);
  useEffect(() => {
    if (!map) return;
    setThreeFlag("sample", true);
    return () => setThreeFlag("sample", false);
  }, [map]);
  return map ? <SampleMesh map={map} /> : null;
}
function SampleMesh({ map }: { map: THREE.Texture }) {
  const mesh = useRef<THREE.Mesh>(null);
  const size = useThree((s) => s.size);
  const element = useRef<HTMLElement | null>(null);
  useEffect(() => { element.current = document.querySelector("[data-peel-box]"); }, []);
  useFrame(() => {
    const m = mesh.current, el = element.current;
    if (!m || !el) return;
    const p = scrollStore.peel;
    m.visible = scrollStore.scenes.has("sample") && p < 0.995;
    if (!m.visible) return;
    const r = el.getBoundingClientRect(), k = worldPerPx(size.height);
    m.position.set((r.left + r.width / 2 - size.width / 2) * k + p * 0.8, -(r.top + r.height / 2 - size.height / 2) * k + p * 1.5, p * 0.6);
    m.rotation.z = -6 * Math.PI / 180 + p * 0.2; // matches the DOM seal's rotate
    m.scale.set(r.width * k, r.height * k, r.width * k);
    const u = (m.material as THREE.ShaderMaterial).uniforms;
    u.uPeel.value = p;
  });
  return <mesh ref={mesh} visible={false}>
    <planeGeometry args={[1, 1, 72, 72]} />
    <shaderMaterial uniforms={peelUniforms(map, [1, 1], [-1, 1])} vertexShader={peelVertex} fragmentShader={peelFragment} transparent side={THREE.DoubleSide} toneMapped={false} />
  </mesh>;
}
