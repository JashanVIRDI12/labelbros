"use client";

import { useEffect, useRef, useState } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { finishSticker } from "@/components/stickers/productArt";
import { materials } from "@/data/materials";
import { ScrollTrigger } from "@/lib/gsap";
import { scrollStore } from "@/lib/scrollStore";
import { setThreeFlag } from "@/lib/threeFlags";
import { anchorInPinnedSection, type Anchor } from "./anchors";
import { stickerTexture } from "./stickerTexture";

const filmArt = { id: "finish-film", label: "Material film", w: 320, h: 320, svg: `<path d="${finishSticker.shape}" fill="white" stroke="white" stroke-width="6" stroke-linejoin="round"/>` };
const rimArt = { id: "finish-rim", label: "White die-cut rim", w: 320, h: 320, svg: `<path d="${finishSticker.shape}" fill="none" stroke="white" stroke-width="5" stroke-linejoin="round"/>` };
const inkArt = { id: "finish-ink", label: "Label Bros ink", w: 320, h: 320, svg: finishSticker.ink };

/** One film surface, opaque printed ink, and physical finish interpolation without transmission. */
export function FinishSticker({ touch }: { touch: boolean }) {
  const size = useThree((s) => s.size);
  const [a, setA] = useState<Anchor | null>(null);
  const [maps, setMaps] = useState<THREE.Texture[] | null>(null);
  const group = useRef<THREE.Group>(null);
  const mat = useRef<THREE.MeshPhysicalMaterial>(null);
  const n = useRef(0);
  const tilt = useRef({ x: 0, y: 0 });
  const extra = useRef({ uGlitter: { value: 0 }, uKraft: { value: 0 }, uClear: { value: 0 } });
  useEffect(() => {
    let alive = true;
    Promise.all([stickerTexture(filmArt), stickerTexture(inkArt), stickerTexture(rimArt)]).then((m) => { if (alive) setMaps(m); });
    return () => { alive = false; };
  }, []);
  useEffect(() => {
    const section = document.getElementById("materials");
    const el = section?.querySelector<HTMLElement>('[data-anchor="finish"]');
    if (!section || !el) return;
    const measure = () => setA(anchorInPinnedSection(el, section, size));
    measure(); ScrollTrigger.addEventListener("refresh", measure);
    return () => ScrollTrigger.removeEventListener("refresh", measure);
  }, [size]);
  const ready = Boolean(a && maps);
  useEffect(() => {
    if (!ready) return;
    setThreeFlag("finish", true);
    return () => setThreeFlag("finish", false);
  }, [ready]);
  useFrame((state, dt) => {
    const g = group.current, m = mat.current;
    if (!g || !m) return;
    const on = scrollStore.scenes.has("materials");
    g.visible = on;
    if (!on) return;
    const target = scrollStore.finish;
    n.current = THREE.MathUtils.damp(n.current, target, 6, dt);
    const p = Math.min(materials.length - 1, Math.max(0, n.current));
    const i = Math.floor(p), t = p - i;
    const from = materials[i].pbr, to = materials[Math.min(i + 1, materials.length - 1)].pbr;
    const mix = (key: Exclude<keyof typeof from, "color">) => THREE.MathUtils.lerp(from[key], to[key], t);
    m.color.set(from.color).lerp(new THREE.Color(to.color), t);
    m.roughness = mix("roughness"); m.metalness = mix("metalness"); m.clearcoat = Math.max(0.0001, mix("clearcoat")); m.iridescence = Math.max(0.0001, mix("iridescence"));
    extra.current.uGlitter.value = mix("glitter"); extra.current.uKraft.value = mix("kraft"); extra.current.uClear.value = mix("clear");
    const tx = touch ? 0 : -scrollStore.pointer.y * 0.13;
    const ty = touch ? 0 : scrollStore.pointer.x * 0.18;
    tilt.current.x = THREE.MathUtils.damp(tilt.current.x, tx, 6, dt);
    tilt.current.y = THREE.MathUtils.damp(tilt.current.y, ty, 6, dt);
    // A quarter-turn excursion between finishes; readable face-on at each snap stop.
    g.rotation.set(tilt.current.x, Math.sin(t * Math.PI * 2) * Math.PI / 4 + tilt.current.y, 0);
    if (Math.abs(target - p) > 0.0001 || Math.abs(tx - tilt.current.x) + Math.abs(ty - tilt.current.y) > 0.0001) state.invalidate();
  });
  if (!a || !maps) return null;
  return <group ref={group} position={[a.x, a.y, 0]} visible={false}>
    <ambientLight intensity={0.8} />
    <directionalLight intensity={2} position={[2, 4, 6]} />
    <mesh>
      <planeGeometry args={[a.w, a.h]} />
      <meshPhysicalMaterial ref={mat} map={maps[0]} transparent alphaTest={0.02} side={THREE.DoubleSide} roughness={0.85} clearcoat={0.0001} iridescence={0.0001} clearcoatRoughness={0.1} iridescenceIOR={1.4}
        onBeforeCompile={(shader) => {
          Object.assign(shader.uniforms, extra.current);
          shader.fragmentShader = `uniform float uGlitter; uniform float uKraft; uniform float uClear;\n${shader.fragmentShader}`
            .replace('#include <map_fragment>', `#include <map_fragment>\n diffuseColor.a *= 1.0 - uClear * 0.88;`)
            .replace('#include <normal_fragment_begin>', `#include <normal_fragment_begin>\n normal = normalize(normal + vec3((vMapUv.x - 0.5) * 0.65, sin(vMapUv.y * 6.283) * 0.08, 0.0) * metalness);\n float fibre = sin(vMapUv.y * 1900.0 + sin(vMapUv.x * 430.0) * 3.0);\n normal = normalize(normal + vec3(fibre * 0.08, sin(vMapUv.x * 1400.0) * 0.03, 0.0) * uKraft);`)
            .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>\n vec2 grain = floor(vMapUv * 450.0);\n float seed = fract(sin(dot(grain, vec2(12.9898,78.233))) * 43758.5453);\n float sparkle = pow(max(0.0, sin(seed * 90.0 + normal.x * 45.0 + normal.y * 30.0)), 28.0);\n totalEmissiveRadiance += vec3(sparkle * step(0.87, seed) * uGlitter * 1.8);`);
        }} />
    </mesh>
    <mesh position-z={0.01}><planeGeometry args={[a.w, a.h]} /><meshBasicMaterial map={maps[2]} transparent alphaTest={0.02} side={THREE.DoubleSide} toneMapped={false} /></mesh>
    <mesh position-z={0.005}><planeGeometry args={[a.w, a.h]} /><meshBasicMaterial map={maps[1]} transparent alphaTest={0.02} side={THREE.DoubleSide} toneMapped={false} /></mesh>
  </group>;
}
