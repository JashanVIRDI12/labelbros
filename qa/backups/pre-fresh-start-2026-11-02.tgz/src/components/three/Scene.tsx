"use client";

import { Environment, Lightformer } from "@react-three/drei";
import { retainStickerTextures } from "./stickerTexture";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { ScrollTrigger } from "@/lib/gsap";
import { onScenesChange, scrollStore, setInvalidate } from "@/lib/scrollStore";
import { CAM_Z, FOV } from "./anchors";
import { SampleSticker } from "./SampleSticker";
import { Roll3D } from "./Roll3D";
import { FinishSticker } from "./FinishSticker";
import { Wrap3D } from "./Wrap3D";

/** Hands R3F's invalidate() to the store so ScrollTriggers can request frames. */
function InvalidateBridge() {
  const invalidate = useThree((s) => s.invalidate);
  useEffect(() => {
    setInvalidate(invalidate);
    const onMove = (e: PointerEvent) => {
      scrollStore.pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
      scrollStore.pointer.y = (e.clientY / window.innerHeight) * 2 - 1;
      if (scrollStore.scenes.has("materials")) invalidate(); // only S5 tilts toward the cursor
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      setInvalidate(null);
      window.removeEventListener("pointermove", onMove);
    };
  }, [invalidate]);
  return null;
}

/**
 * Camera moves driven by scroll: S1 dollies in 6%; S3 pulls back and tilts down onto the shelf
 * (not on touch, where the jar sits above the copy and the pull-back would drop it onto the text).
 */
function CameraRig({ touch }: { touch: boolean }) {
  const hero = useRef(0);
  const wrap = useRef(0);
  useFrame((state, dt) => {
    hero.current = THREE.MathUtils.damp(hero.current, scrollStore.hero, 6, dt);
    wrap.current = THREE.MathUtils.damp(wrap.current, scrollStore.wrap, 6, dt);
    const t = Math.min(1, Math.max(0, (wrap.current - 0.6) / 0.4));
    const pull = touch || !scrollStore.scenes.has("wrap") ? 0 : t * t * (3 - 2 * t) * (1 - scrollStore.wrapOut);
    const cam = state.camera;
    cam.position.set(0, 1.1 * pull, CAM_Z * (1 - (scrollStore.scenes.has("hero") ? 0.06 * hero.current : 0)) + 2.6 * pull);
    cam.lookAt(0, 0.35 * pull, 0);
    if (Math.abs(hero.current - scrollStore.hero) > 1e-4 || Math.abs(wrap.current - scrollStore.wrap) > 1e-4) state.invalidate();
  });
  return null;
}

/**
 * The page's only WebGL context: fixed, full viewport, above the content but click-through.
 * frameloop={tabVisible ? "demand" : "never"}: nothing renders unless a ScrollTrigger or a damping loop asks for it.
 * Hidden (and idle) whenever no 3D moment is on screen.
 */
export default function Scene({ touch }: { touch: boolean }) {
  useEffect(() => retainStickerTextures(), []);
  const [tabVisible, setTabVisible] = useState(true);
  useEffect(() => { const sync = () => setTabVisible(!document.hidden); document.addEventListener("visibilitychange", sync); return () => document.removeEventListener("visibilitychange", sync); }, []);
  const [visible, setVisible] = useState(scrollStore.scenes.size > 0);

  useEffect(() => onScenesChange(() => setVisible(scrollStore.scenes.size > 0)), []);
  useEffect(() => {
    ScrollTrigger.refresh();
  }, []);

  return (
    <div
      role="img"
      aria-label="3D labels: a label wrapping a jar, a label roll, a material test plate and a security seal"
      className="pointer-events-none fixed inset-0 z-30"
      style={{ visibility: visible ? "visible" : "hidden" }}
    >
      <Canvas
        // R3F gives its wrapper pointer-events: auto; the canvas must never block the page
        style={{ pointerEvents: "none" }}
        frameloop={tabVisible ? "demand" : "never"}
        dpr={[1, touch ? 1.5 : 2]}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance", preserveDrawingBuffer: process.env.NODE_ENV !== "production" && new URLSearchParams(window.location.search).has("posters") }}
        camera={{ fov: FOV, position: [0, 0, CAM_Z], near: 0.1, far: 100 }}
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.NeutralToneMapping;
          gl.outputColorSpace = THREE.SRGBColorSpace;
        }}
      >
        <Environment resolution={128} frames={1}>
          <Lightformer form="rect" intensity={2} position={[0.5, 1, 5]} scale={[1.2, 8, 1]} />
          <Lightformer form="rect" intensity={3} position={[-3, 2, 4]} scale={[4, 6, 1]} />
          <Lightformer form="rect" intensity={1.5} position={[4, 1, 3]} scale={[3, 5, 1]} />
        </Environment>
        <InvalidateBridge />
        <CameraRig touch={touch} />
        <Wrap3D touch={touch} />
        {!touch && <Roll3D />}
        <FinishSticker touch={touch} />
        <SampleSticker />
      </Canvas>
    </div>
  );
}
