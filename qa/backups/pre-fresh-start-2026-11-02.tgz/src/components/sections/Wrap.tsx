"use client";

import { useState } from "react";
import { FinishChips } from "@/components/sections/wrap/FinishChips";
import { Jar2D, type WrapFinish } from "@/components/sections/wrap/Jar2D";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { WrapMotion } from "@/components/sections/wrap/WrapMotion";
import { IndexRule } from "@/components/ui/SectionHead";
import { wrap } from "@/data/copy";
import { setProgress } from "@/lib/scrollStore";

function Check() {
  return (
    <svg viewBox="0 0 16 16" className="size-4 shrink-0 text-signal-text" aria-hidden="true" focusable="false">
      <path d="M3 8.5 6.5 12 13 4.5" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
    </svg>
  );
}

/**
 * S4 application. Desktop: pinned; a flat label bends around a 3D jar (uWrap), the jar turns,
 * the light sweeps. The 2D jar is the stand-in until the canvas takes over, and the final state
 * for reduced motion and the low tier.
 */
export function Wrap() {
  const [finish, setFinish] = useState<WrapFinish>("Matte");

  return (
    <section
      id="wrap"
      aria-labelledby="wrap-title"
      data-wrap-finish={finish}
      className="relative h-svh page-x calm:h-auto"
      style={{ paddingBlock: "calc(var(--header-h) * 0.6)" }}
    >
      <div className="grid h-full grid-cols-12 content-center items-center gap-x-6 gap-y-6 calm:gap-y-12 calm:py-16 lg:gap-y-12">
        <div className="col-span-12 lg:col-span-5">
          <IndexRule index={wrap.index} label={wrap.eyebrow} />
          <h2
            id="wrap-title"
            data-wrap-title
            className="type-display mt-8 text-[clamp(2.5rem,4.8vw,5.25rem)] lg:mt-10"
            aria-label={wrap.lines.join(" ")}
          >
            {wrap.lines.map((line) => (
              <span key={line} data-wrap-line className="block whitespace-nowrap">
                {line}
              </span>
            ))}
          </h2>
          <p data-wrap-after className="type-lede mt-6 max-w-[38ch] max-lg:hidden calm:block">
            {wrap.lede}
          </p>
          <ul data-wrap-after className="mt-8 flex flex-wrap gap-x-6 gap-y-2.5">
            {wrap.proof.map((p) => (
              <li key={p} className="flex items-center gap-2 text-15 font-medium">
                <Check />
                {p}
              </li>
            ))}
          </ul>
          <div data-wrap-after className="mt-8">
            <p className="type-meta mb-3">Label finish</p>
            <FinishChips
              label="Label finish"
              options={wrap.finishes}
              value={finish}
              onChange={(f) => {
                setFinish(f);
                setProgress("finishWrap", wrap.finishes.indexOf(f));
              }}
            />
          </div>
        </div>

        <div className="order-first col-span-12 flex items-center justify-center lg:order-none lg:col-span-7 lg:h-full">
          <div data-anchor="jar" className="relative w-[min(46vw,26svh,300px)] calm:w-[min(70vw,380px)] lg:w-[min(28vw,420px)] lg:calm:w-[min(28vw,420px)]">
            <Jar2D finish={finish} className="[:root[data-three~=wrap][data-scenes~=wrap]_&]:invisible" />
          </div>
        </div>
      </div>
      <NearViewport>
        <WrapMotion />
      </NearViewport>
    </section>
  );
}
