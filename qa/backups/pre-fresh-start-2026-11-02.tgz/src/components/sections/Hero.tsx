import { HeroMotion } from "@/components/sections/hero/HeroMotion";
import { HeroSpecimen } from "@/components/sections/hero/HeroSpecimen";
import { Arrow, ButtonLink } from "@/components/ui/Button";
import { cta, hero } from "@/data/copy";

/**
 * One headline line: mask (clips) › text (CSS rise on load, so the H1, our LCP element,
 * paints without waiting for JavaScript).
 */
function Line({ text, i }: { text: string; i: number }) {
  return (
    <span className="block overflow-clip pb-[0.06em]">
      <span className="hero-text block whitespace-nowrap" style={{ "--i": i } as React.CSSProperties}>
        {text}
      </span>
    </span>
  );
}

/**
 * S1. Left: the promise and both ways in (your artwork or ours). Right: the specimen panel,
 * a proofing station that cycles one real-world label per industry with its die line,
 * dimensions and spec. Signature: the specimen switch.
 */
export function Hero() {
  return (
    <section id="top" data-hero aria-labelledby="hero-title" className="relative" style={{ paddingTop: "var(--header-h)" }}>
      <div className="grid lg:min-h-[calc(100svh-var(--header-h))] lg:grid-cols-12">
        <div className="flex flex-col justify-between page-x pt-10 pb-12 lg:col-span-6 lg:pt-[clamp(1.25rem,4svh,4rem)] lg:pr-[clamp(1.5rem,3vw,3.5rem)] lg:pb-[clamp(0.75rem,2svh,2.5rem)]">
          <div>
            <p data-intro className="type-meta flex items-center gap-3 text-ink">
              <span aria-hidden="true" className="size-1.5 bg-signal" />
              {hero.eyebrow}
            </p>

            <h1 id="hero-title" className="type-hero mt-8 lg:mt-[clamp(1rem,3.5svh,3.5rem)]" aria-label={hero.lines.join(" ")}>
              {hero.lines.map((line, i) => (
                <span key={line} aria-hidden="true" className="block">
                  <Line text={line} i={i} />
                </span>
              ))}
            </h1>

            <p data-intro className="type-lede mt-7 max-w-[46ch] lg:mt-[clamp(1rem,2.6svh,2.25rem)]">
              {hero.lede}
            </p>

            <div data-intro className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center lg:mt-[clamp(1.25rem,3svh,2.5rem)]">
              <ButtonLink href={cta.primary.href} arrow className="sm:min-w-[15.5rem]">
                {cta.primary.label}
              </ButtonLink>
              <ButtonLink href={cta.secondary.href} variant="outline">
                {cta.secondary.label}
              </ButtonLink>
            </div>

            <ul data-intro className="mt-8 max-w-[30rem] border-t border-line lg:mt-[clamp(1rem,3svh,2.5rem)]" aria-label="Two ways to get your artwork">
              {hero.paths.map((p) => (
                <li key={p.k} className="border-b border-line">
                  <a href={p.href} className="group flex h-12 items-center gap-4 text-15 lg:h-[clamp(2.75rem,5.6svh,3rem)]">
                    <span className="w-28 shrink-0 text-ink-soft">{p.k}</span>
                    <span className="font-medium">{p.v}</span>
                    <Arrow className="ml-auto text-ink-soft transition-transform duration-300 group-hover:translate-x-1 group-hover:text-ink" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <dl data-intro className="mt-12 grid border-t border-ink pt-1 sm:grid-cols-3 sm:gap-4 sm:pt-4 lg:mt-[clamp(1.25rem,4svh,3rem)] lg:pt-3">
            {hero.facts.map((f) => (
              <div key={f.k} className="flex items-baseline justify-between gap-4 border-b border-line py-2.5 sm:block sm:border-0 sm:py-0">
                <dt className="type-meta">{f.k}</dt>
                <dd className="text-right text-14 leading-snug font-medium [overflow-wrap:anywhere] sm:mt-1.5 sm:text-left">{f.v}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative bg-graphite text-paper lg:col-span-6">
          <HeroSpecimen />
        </div>
      </div>
      <HeroMotion />
    </section>
  );
}
