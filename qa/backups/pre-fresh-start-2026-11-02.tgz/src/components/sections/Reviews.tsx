import { industryLabels } from "@/components/labels/labelArt";
import { Sticker } from "@/components/stickers/Sticker";
import { Arrow } from "@/components/ui/Button";
import { CropMarks } from "@/components/ui/PrintMarks";
import { SectionHead } from "@/components/ui/SectionHead";
import { industries, reviewsCopy } from "@/data/copy";
import { caseStudies, rating, reviews } from "@/data/reviews";

const industryName = Object.fromEntries(industries.map((i) => [i.id, i.short]));

/**
 * S8 proof. A ruled grid of reviews (each tagged with the buyer's industry), the rating, client
 * logos and two short case studies. Calm on purpose: the reviews carry it, not the motion.
 */
export function Reviews() {
  return (
    <section id="reviews" aria-labelledby="reviews-title" className="relative page-x py-24 lg:py-36">
      <SectionHead
        id="reviews-title"
        index={reviewsCopy.index}
        eyebrow={reviewsCopy.eyebrow}
        title={reviewsCopy.title}
        aside={
          <div className="flex flex-wrap items-end gap-x-6 gap-y-3 lg:justify-end">
            <p className="type-display text-[clamp(2.5rem,4vw,4rem)] leading-none">{rating.value}</p>
            <p className="pb-1 text-14 text-ink-soft">
              Average rating from
              <br />
              {rating.count} reviews
            </p>
          </div>
        }
      />

      <ul className="mt-14 grid border-t border-l border-line md:grid-cols-3 lg:mt-16">
        {reviews.slice(0, 3).map((r, i) => (
          <li key={i} data-review className="flex flex-col border-r border-b border-line bg-paper p-6 lg:p-8">
            <p className="type-meta flex items-center gap-2">
              <span aria-hidden="true" className="size-1.5 bg-signal" />
              {industryName[r.industry]}
            </p>
            <blockquote className="mt-6 flex-1 text-18 leading-[1.45] tracking-[-0.01em]">“{r.quote}”</blockquote>
            <p className="mt-8 border-t border-line pt-4 text-14">
              <span className="font-semibold">{r.name}</span>
              <span className="text-ink-soft">
                {" "}
                · {r.role}, {r.company}
              </span>
            </p>
          </li>
        ))}
      </ul>

      <div className="mt-16 grid gap-6 lg:mt-20 lg:grid-cols-2">
        {caseStudies.map((c) => (
          <article key={c.company} className="group grid overflow-hidden rounded-xs border border-ink/15 bg-sheet sm:grid-cols-2">
            <div className="relative grid min-h-60 place-items-center bg-graphite p-8" aria-hidden="true">
              <div className="relative w-[78%]">
                <Sticker art={industryLabels[c.industry]} className="block h-auto w-full transition-transform duration-500 group-hover:scale-[1.03]" />
                <CropMarks className="text-steel/60" gap={8} length={10} />
              </div>
              <span className="type-meta absolute top-4 left-4 text-steel">{industryName[c.industry]}</span>
            </div>
            <div className="flex flex-col p-6 lg:p-8">
              <p className="type-meta">{c.company}</p>
              <h3 className="type-h3 mt-3 text-24">{c.title}</h3>
              <p className="mt-3 flex-1 text-15 leading-relaxed text-ink-soft">{c.body}</p>
              <a href="[[CASE_STUDY_URL]]" className="mt-6 inline-flex h-11 items-center gap-2 text-14 font-medium hover:underline">
                Read the case study <Arrow />
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
