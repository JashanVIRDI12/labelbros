"use client";

import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";

/**
 * S3 process. Desktop: the production rule fills left to right with scroll (scrubbed) and each
 * station lights when the fill reaches it. Touch: each step's node lights as it enters.
 * Reduced motion: the rule is full and every station is lit (CSS `calm:`).
 */
export function HowMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(
    () => {
      const root = scope.current;
      if (!root) return;
      const q = gsap.utils.selector(root);
      const mm = gsap.matchMedia();
      mm.add(MQ, (ctx) => {
        const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
        const steps = q("[data-step]");
        const light = (n: number) => steps.forEach((s, i) => (s.dataset.on = String(i < n)));
        if (reduceMotion) {
          light(steps.length);
          return;
        }
        light(0);
        if (!isDesktop) {
          steps.forEach((s) => gsap.from(s.querySelector("h3"), { autoAlpha: 0, y: 12, duration: 0.6, ease: "expo.out", scrollTrigger: { trigger: s, start: "top 80%", once: true } }));
          return;
        }
        gsap.fromTo(
          q("[data-line-fill]"),
          { scaleX: 0 },
          {
            scaleX: 1,
            ease: "none",
            scrollTrigger: {
              trigger: q("ol")[0],
              start: "top 78%",
              end: "bottom 62%",
              scrub: 0.6,
              // station i lights once the fill passes its left edge (plus a hair)
              onUpdate: (self) => light(Math.min(steps.length, Math.floor(self.progress * steps.length + 0.98))),
            },
          },
        );
        return () => light(steps.length);
      });
    },
    { scope },
  );
  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("section") ?? null;
      }}
    />
  );
}
