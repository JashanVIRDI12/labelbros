import { Droplet, FlaskConical, Shield, Sun, Thermometer, Undo2 } from "lucide-react";
import { durabilityLabel, type Durability } from "@/data/materials";

const icons = { waterproof: Droplet, uv: Sun, scratch: Shield, removable: Undo2, chemical: FlaskConical, heat: Thermometer } as const;

/** 1.5px line icons in square cells. Phrasing content only, because it sits inside a button. */
export function DurabilityIcons({ list }: { list: Durability[] }) {
  if (!list.length) return null;
  return (
    <span className="flex items-center gap-1.5">
      <span className="sr-only">{list.map((d) => durabilityLabel[d]).join(", ")}</span>
      {list.map((d) => {
        const Icon = icons[d];
        return (
          <span key={d} title={durabilityLabel[d]} className="flex size-8 items-center justify-center rounded-xs border border-ink/15" aria-hidden="true">
            <Icon className="size-4" strokeWidth={1.5} />
          </span>
        );
      })}
    </span>
  );
}
