"use client";

import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { getTier, prefersReducedMotion } from "@/lib/motion";
import { finishSticker } from "@/components/stickers/productArt";
import type { Material } from "@/data/materials";
import { cn } from "@/lib/utils";

const maskUrl = `url("data:image/svg+xml;utf8,${encodeURIComponent(
  `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 320'><path d='${finishSticker.shape}'/></svg>`,
)}")`;

/**
 * 2D stand-in for the S6 3D plate: the film (CSS swatch) masked to the plate's die cut, a white
 * cut edge behind, and the ink layer on top (ink is the same on every film). It's what shows
 * before the canvas loads, on the low tier, and under reduced motion.
 */
export function FinishSticker2D({ material, className }: { material: Material; className?: string }) {
  const scope = useRef<HTMLDivElement>(null);
  useGSAP(
    () => {
      if (getTier() !== "low" || prefersReducedMotion()) return;
      gsap.fromTo(scope.current, { clipPath: "inset(0% 0% 100% 0%)" }, { clipPath: "inset(0% 0% 0% 0%)", duration: 0.6, ease: "press" });
    },
    { scope, dependencies: [material.id], revertOnUpdate: true },
  );
  return (
    <div ref={scope} className={cn("relative aspect-square", className)} aria-hidden="true">
      <svg viewBox="0 0 320 320" className="absolute inset-0 h-full w-full overflow-visible">
        <path d={finishSticker.shape} fill="#FFFFFF" stroke="#FFFFFF" strokeWidth="5" strokeLinejoin="round" />
      </svg>
      <div
        data-finish-base
        className="absolute inset-0"
        style={{
          background: material.swatch,
          WebkitMask: `${maskUrl} center / contain no-repeat`,
          mask: `${maskUrl} center / contain no-repeat`,
          opacity: material.id === "clear" ? 0.55 : 1,
        }}
      />
      <svg data-sticker viewBox="0 0 320 320" className="absolute inset-0 h-full w-full" dangerouslySetInnerHTML={{ __html: finishSticker.ink }} />
    </div>
  );
}
