import { industryLabels } from "@/components/labels/labelArt";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { IndustriesMotion } from "@/components/sections/motion/IndustriesMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { Arrow } from "@/components/ui/Button";
import { CropMarks } from "@/components/ui/PrintMarks";
import { SectionHead } from "@/components/ui/SectionHead";
import { industries, industriesCopy } from "@/data/copy";

/** Display width of each specimen inside its card, as a share of the card. */
const WIDTH = { food: 0.8, defense: 0.7, auto: 0.62, industrial: 0.48 } as const;

/**
 * Single-colour plates for the registration moment: an SVG filter turns a label's ink into a
 * cyan or magenta plate (darker ink → more opaque). Defined once, used by every card.
 */
function PlateFilters() {
  return (
    <svg aria-hidden="true" width="0" height="0" className="absolute">
      <filter id="plate-cyan" colorInterpolationFilters="sRGB">
        <feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0.64  0 0 0 0 0.88  -0.45 -0.45 -0.45 1.25 0" />
      </filter>
      <filter id="plate-magenta" colorInterpolationFilters="sRGB">
        <feColorMatrix type="matrix" values="0 0 0 0 0.89  0 0 0 0 0  0 0 0 0 0.49  -0.45 -0.45 -0.45 1.25 0" />
      </filter>
    </svg>
  );
}

/**
 * Industries. Four columns, one specimen label each, with the label types we make for it.
 * Signature: registration. Each label arrives as misaligned cyan and magenta plates that pull
 * into register as the row scrolls into place (scrubbed). Reduced motion: printed in register.
 */
export function Industries() {
  return (
    <section id="industries" aria-labelledby="industries-title" className="relative page-x py-24 lg:py-36">
      <PlateFilters />
      <SectionHead
        id="industries-title"
        index={industriesCopy.index}
        eyebrow={industriesCopy.eyebrow}
        title={industriesCopy.title}
        aside={<p className="type-lede max-w-[44ch]">{industriesCopy.lede}</p>}
      />

      <ol className="mt-16 grid border-t border-ink sm:grid-cols-2 lg:mt-20 lg:grid-cols-4">
        {industries.map((ind) => (
          <li key={ind.id} data-industry className="flex flex-col border-b border-line py-8 sm:px-6 sm:max-lg:odd:pl-0 sm:max-lg:even:pr-0 lg:border-b-0 lg:first:pl-0 lg:last:pr-0 lg:not-last:border-r">
            <div className="relative grid h-[clamp(13rem,19vw,17rem)] place-items-center bg-sheet">
              <div className="relative" style={{ width: `${WIDTH[ind.id] * 100}%` }}>
                <Sticker art={industryLabels[ind.id]} className="relative z-[1] block h-auto w-full" decorative={false} />
                <span data-plate="c" aria-hidden="true" className="pointer-events-none absolute inset-0 z-[2] opacity-0 mix-blend-multiply [filter:url(#plate-cyan)]">
                  <Sticker art={industryLabels[ind.id]} className="block h-auto w-full" />
                </span>
                <span data-plate="m" aria-hidden="true" className="pointer-events-none absolute inset-0 z-[2] opacity-0 mix-blend-multiply [filter:url(#plate-magenta)]">
                  <Sticker art={industryLabels[ind.id]} className="block h-auto w-full" />
                </span>
                <CropMarks className="text-ink/30" gap={10} length={10} />
              </div>
              <span className="type-meta absolute bottom-3 left-3 text-ink-soft">{ind.size.w} × {ind.size.h}</span>
            </div>

            <h3 className="type-h3 mt-7 text-[1.625rem]">{ind.name}</h3>
            <p className="mt-3 text-15 leading-relaxed text-ink-soft">{ind.line}</p>

            <ul className="mt-6 border-t border-line">
              {ind.types.map((t) => (
                <li key={t} className="flex items-center gap-3 border-b border-line py-2.5 text-14">
                  <span aria-hidden="true" className="size-1 shrink-0 bg-ink" />
                  {t}
                </li>
              ))}
            </ul>

            <a href="#quote" className="group mt-auto inline-flex h-12 items-center gap-2 pt-6 text-14 font-medium">
              Price {ind.short.toLowerCase()} labels
              <Arrow className="transition-transform duration-300 group-hover:translate-x-1" />
            </a>
          </li>
        ))}
      </ol>

      <p className="type-meta mt-8">{industriesCopy.also}</p>
      <NearViewport>
        <IndustriesMotion />
      </NearViewport>
    </section>
  );
}
