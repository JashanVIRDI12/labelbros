import { cn } from "@/lib/utils";

type Option = { id: string; label: string };

/** Native radios styled as square option tiles: arrow keys and forms work for free. */
export function ChipRadio({
  name,
  legend,
  options,
  value,
  onChange,
}: {
  name: string;
  legend: string;
  options: readonly Option[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <fieldset data-quote-control>
      <legend className="type-meta mb-3">{legend}</legend>
      <div className="flex flex-wrap gap-1.5">
        {options.map((o) => (
          <label key={o.id} className="relative">
            <input
              type="radio"
              name={name}
              value={o.id}
              checked={value === o.id}
              onChange={() => onChange(o.id)}
              className="peer absolute inset-0 cursor-pointer opacity-0"
            />
            <span
              className={cn(
                "type-label pointer-events-none inline-flex h-11 items-center rounded-xs border px-4 text-14 transition-colors duration-200",
                "border-ink/15 bg-sheet peer-hover:border-ink/60 peer-checked:border-ink peer-checked:bg-ink peer-checked:text-paper",
                "peer-focus-visible:outline-2 peer-focus-visible:outline-offset-3 peer-focus-visible:outline-ink",
              )}
            >
              {o.label}
            </span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}
