import { foodLabel } from "@/components/labels/labelArt";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { DesignMotion } from "@/components/sections/motion/DesignMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { ButtonLink } from "@/components/ui/Button";
import { CropMarks } from "@/components/ui/PrintMarks";
import { SectionHead } from "@/components/ui/SectionHead";
import { designChoice } from "@/data/copy";

function Check() {
  return (
    <svg viewBox="0 0 16 16" className="size-4 shrink-0" aria-hidden="true" focusable="false">
      <path d="M3 8.5 6.5 12 13 4.5" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
    </svg>
  );
}

/** Path A visual: the prepress report on an uploaded file. */
function Preflight() {
  const checks = ["Bleed 3 mm on all sides", "Die line on its own layer", "Barcode graded, quiet zone clear", "Fonts outlined, 6 pt minimum"]; // COPY:
  return (
    <div className="flex h-full flex-col p-5 sm:p-7">
      <div className="flex items-center gap-3 border-b border-white/10 pb-4">
        <span aria-hidden="true" className="flex h-10 w-8 items-end justify-center rounded-[2px] border border-white/25 pb-1 text-[9px] font-semibold tracking-wider text-steel">PDF</span>
        <span>
          <span className="block text-14 font-medium text-paper">chili-oil_front_v3.pdf</span>
          <span className="type-meta text-steel">120 × 50 mm · CMYK · 4.2 MB</span>
        </span>
        <span className="type-meta ml-auto rounded-xs bg-signal px-2 py-1 text-ink">Prepress</span>
      </div>
      <ul className="mt-2">
        {checks.map((c) => (
          <li key={c} data-check className="flex items-center gap-3 border-b border-white/10 py-3 text-14 text-paper last:border-b-0">
            <span className="flex size-5 items-center justify-center rounded-[2px] bg-white/10 text-signal">
              <Check />
            </span>
            {c}
          </li>
        ))}
      </ul>
      <p className="type-meta mt-auto flex items-center justify-between border-t border-white/10 pt-4 text-steel">
        <span>
          <span className="text-paper">{checks.length} / {checks.length}</span> checks passed
        </span>
        <span className="text-signal">Ready for proof</span>
      </p>
    </div>
  );
}

/** Path B visual: a designer's v1 with review markup. */
function DraftMarkup() {
  return (
    <div className="relative grid h-full place-items-center p-6 sm:p-8">
      <div className="relative w-[78%]">
        <Sticker art={foodLabel} className="block h-auto w-full" />
        <CropMarks className="text-steel/60" gap={8} length={10} />
        <span data-markup className="absolute top-[-22%] left-[6%] flex items-end gap-2 text-signal">
          <span className="type-meta rounded-xs bg-signal px-1.5 py-0.5 text-ink">Logo +10%</span>
          <span className="mb-[-14px] h-6 w-px bg-signal" />
        </span>
        <span data-markup className="absolute right-[-4%] bottom-[-26%] flex items-start gap-2 text-signal">
          <span className="mt-[-14px] h-6 w-px bg-signal" />
          <span className="type-meta rounded-xs bg-signal px-1.5 py-0.5 text-ink">Allergens to back</span>
        </span>
      </div>
      <span className="type-meta absolute top-4 left-5 text-steel">v1 · For review</span>
      <span className="type-meta absolute top-4 right-5 text-steel">Label Bros design</span>
    </div>
  );
}

const visuals = { upload: Preflight, design: DraftMarkup } as const;

/**
 * Two ways in: send your artwork, or have Label Bros design it. Both paths are equal, side by
 * side, and join at the proof (the junction draws on scroll).
 */
export function DesignChoice() {
  return (
    <section id="design" aria-labelledby="design-title" className="relative bg-graphite text-paper page-x py-24 lg:py-36">
      <SectionHead tone="dark" id="design-title" index={designChoice.index} eyebrow={designChoice.eyebrow} title={designChoice.title} lede={designChoice.lede} />

      <div className="mt-16 grid border-t border-white/15 lg:mt-20 lg:grid-cols-2">
        {designChoice.paths.map((p) => {
          const Visual = visuals[p.id as keyof typeof visuals];
          return (
            <article key={p.id} data-path={p.id} className="flex flex-col border-white/15 py-10 lg:py-12 lg:first:pr-12 lg:last:border-l lg:last:pl-12 max-lg:not-last:border-b">
              <p className="type-meta text-signal">{p.kicker}</p>
              <h3 className="type-h3 mt-3 text-[clamp(2rem,3.2vw,3rem)] tracking-[-0.04em]">{p.name}</h3>
              <p className="mt-4 max-w-[42ch] text-16 leading-relaxed text-steel">{p.line}</p>

              <div className="relative mt-10 min-h-72 overflow-hidden rounded-xs border border-white/10 bg-graphite-2 sm:aspect-[16/10] sm:min-h-0">
                <Visual />
              </div>

              <dl className="mt-8 grid sm:grid-cols-3 sm:gap-4">
                {p.points.map((pt) => (
                  <div key={pt.k} className="flex items-baseline justify-between gap-4 border-t border-white/15 py-2.5 sm:block sm:pt-3 sm:pb-0">
                    <dt className="type-meta text-steel">{pt.k}</dt>
                    <dd className="text-right text-14 font-medium [overflow-wrap:anywhere] sm:mt-1.5 sm:text-left">{pt.v}</dd>
                  </div>
                ))}
              </dl>

              <ButtonLink href={p.cta.href} variant="light" arrow className="mt-10 self-start">
                {p.cta.label}
              </ButtonLink>
            </article>
          );
        })}
      </div>

      {/* the two roads meet at the proof */}
      <div data-junction className="relative mt-4 hidden h-28 lg:block" aria-hidden="true">
        <svg viewBox="0 0 1000 112" preserveAspectRatio="none" className="absolute inset-0 h-full w-full overflow-visible">
          <path data-road d="M250 0V40Q250 56 266 56H484Q500 56 500 72V112" fill="none" stroke="var(--color-signal)" strokeWidth="1.25" vectorEffect="non-scaling-stroke" />
          <path data-road d="M750 0V40Q750 56 734 56H516Q500 56 500 72V112" fill="none" stroke="var(--color-signal)" strokeWidth="1.25" vectorEffect="non-scaling-stroke" />
        </svg>
      </div>
      <div data-join className="mx-auto mt-10 flex w-fit flex-col items-center gap-2 text-center lg:mt-0">
        <p className="flex items-center gap-3 rounded-xs border border-signal px-6 py-4 text-18 font-medium">
          <span data-join-check className="flex size-6 items-center justify-center rounded-[2px] bg-signal text-ink">
            <Check />
          </span>
          {designChoice.join}
        </p>
        <p className="type-meta text-steel">{designChoice.joinNote}</p>
      </div>
      <NearViewport>
        <DesignMotion />
      </NearViewport>
    </section>
  );
}
