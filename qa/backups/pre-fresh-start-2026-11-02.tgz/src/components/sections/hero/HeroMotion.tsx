"use client";

import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";

/**
 * S1 load, left column: the headline rises in CSS (first paint); the supporting copy, both
 * actions and the fact row follow in one short expo.out sequence. Reduced motion: nothing moves.
 */
export function HeroMotion() {
  const scope = useRef<HTMLElement | null>(null);

  useGSAP(
    () => {
      const root = scope.current;
      if (!root) return;
      const mm = gsap.matchMedia();
      mm.add(MQ, (ctx) => {
        if (motionFlags(ctx.conditions).reduceMotion) return;
        const items = gsap.utils.toArray<HTMLElement>("[data-intro]", root);
        gsap.set(items, { autoAlpha: 0, y: 18 });
        document.documentElement.classList.add("motion-ready");
        gsap.to(items, { autoAlpha: 1, y: 0, duration: 0.9, ease: "expo.out", stagger: 0.07, delay: 0.3, clearProps: "transform" });
      });
    },
    { scope },
  );

  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("section") ?? null;
      }}
    />
  );
}
