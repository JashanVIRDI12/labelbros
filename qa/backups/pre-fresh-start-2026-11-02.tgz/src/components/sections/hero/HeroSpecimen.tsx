"use client";

import { useCallback, useEffect, useId, useRef, useState, useSyncExternalStore } from "react";
import { industryLabels } from "@/components/labels/labelArt";
import { Sticker } from "@/components/stickers/Sticker";
import { ColorBar, CropMarks, RegMark } from "@/components/ui/PrintMarks";
import { industries } from "@/data/copy";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, prefersReducedMotion, REDUCE_EVENT } from "@/lib/motion";
import { cn } from "@/lib/utils";

/** Share of the stage width each specimen takes, so every label reads at a believable scale. */
const WIDTH = { food: 0.8, defense: 0.68, auto: 0.62, industrial: 0.44 } as const;
/**
 * Clip states for the wipe. The box is generous on the sides and below/above so the die line,
 * crop marks and dimensions (which sit outside the label) wipe with it instead of being cut off.
 */
const SHOW = "inset(-45% -22% -45% -22%)";
const BELOW = "inset(145% -22% -45% -22%)";
const ABOVE = "inset(-45% -22% 145% -22%)";
/** Seconds each specimen stays on the bench before the next one feeds in. */
const DWELL = 6;
const N = industries.length;
const pad = (n: number) => String(n).padStart(2, "0");

const subscribeReduce = (cb: () => void) => {
  const mq = window.matchMedia(MQ.reduceMotion);
  mq.addEventListener("change", cb);
  window.addEventListener(REDUCE_EVENT, cb);
  return () => {
    mq.removeEventListener("change", cb);
    window.removeEventListener(REDUCE_EVENT, cb);
  };
};

function Dimension({ value, axis }: { value: string; axis: "x" | "y" }) {
  if (axis === "x")
    return (
      <span data-dim className="absolute inset-x-0 -top-10 flex items-center gap-2 text-steel">
        <span className="h-2.5 w-px bg-current" />
        <span className="h-px flex-1 bg-current opacity-50" />
        <span className="type-meta text-steel">{value}</span>
        <span className="h-px flex-1 bg-current opacity-50" />
        <span className="h-2.5 w-px bg-current" />
      </span>
    );
  return (
    <span data-dim className="absolute inset-y-0 -right-11 flex w-2.5 flex-col items-center gap-2 text-steel">
      <span className="h-px w-2.5 bg-current" />
      <span className="w-px flex-1 bg-current opacity-50" />
      <span className="type-meta whitespace-nowrap text-steel [writing-mode:vertical-rl]">{value}</span>
      <span className="w-px flex-1 bg-current opacity-50" />
      <span className="h-px w-2.5 bg-current" />
    </span>
  );
}

/**
 * S1 signature: the specimen switch. One label per industry sits on a dark proofing bench with
 * its die line, crop marks and dimensions. Every few seconds the next one feeds in (clip wipe,
 * the die line redraws, the spec values roll). Tabs pick one directly; the cycle pauses on hover,
 * focus, off-screen, with the pause button, and never runs under reduced motion.
 */
export function HeroSpecimen() {
  const root = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const shown = useRef(0);
  const timer = useRef<gsap.core.Tween | null>(null);
  const hold = useRef({ hover: false, focus: false, offscreen: false });
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);
  const uid = useId();
  // render-time copy (server: assume reduced, so no pause button flashes); effects ask directly
  const reduced = useSyncExternalStore(subscribeReduce, prefersReducedMotion, () => true);

  const sync = useCallback(() => {
    const h = hold.current;
    const t = timer.current;
    if (t) t.paused(paused || h.hover || h.focus || h.offscreen);
  }, [paused]);
  const setHold = useCallback(
    (key: keyof typeof hold.current, on: boolean) => {
      hold.current[key] = on;
      sync();
    },
    [sync],
  );

  // first frame: only the first specimen shows; the intro feeds it in
  useGSAP(
    () => {
      const q = gsap.utils.selector(root);
      const items = q("[data-spec-item]");
      gsap.set(items.slice(1), { clipPath: BELOW });
      gsap.set(items[0], { clipPath: SHOW });
      q("[data-spec-cell]").forEach((cell) => gsap.set([...cell.querySelectorAll("[data-v]")].slice(1), { autoAlpha: 0 }));
      if (prefersReducedMotion()) return;
      gsap
        .timeline({ delay: 0.35, defaults: { ease: "press" } })
        .fromTo(items[0], { clipPath: BELOW, y: 18 }, { clipPath: SHOW, y: 0, duration: 0.9 })
        .fromTo(items[0].querySelector("[data-die]"), { drawSVG: "0% 0%" }, { drawSVG: "0% 100%", duration: 1.1, ease: "power2.inOut" }, 0.3)
        .fromTo(items[0].querySelectorAll("[data-dim]"), { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.5, stagger: 0.1 }, 0.7)
        .fromTo(q("[data-spec-cell] [data-v]:first-child"), { yPercent: 100, autoAlpha: 0 }, { yPercent: 0, autoAlpha: 1, duration: 0.7, ease: "expo.out", stagger: 0.06 }, 0.45);
    },
    { scope: root },
  );

  // switch: feed the next specimen in, then start its dwell timer
  useGSAP(
    () => {
      const q = gsap.utils.selector(root);
      const still = prefersReducedMotion();
      const from = shown.current;
      const to = active;
      shown.current = active;
      const items = q("[data-spec-item]");
      const cells = q("[data-spec-cell]");
      const bars = q("[data-bar]");

      timer.current?.kill();
      gsap.set(bars, { scaleX: 0 });

      if (from !== to) {
        if (still) {
          gsap.set(items, { clipPath: (i: number) => (i === to ? SHOW : BELOW) });
          cells.forEach((cell) => gsap.set(cell.querySelectorAll("[data-v]"), { autoAlpha: (i: number) => (i === to ? 1 : 0), yPercent: 0 }));
        } else {
          const tl = gsap.timeline({ defaults: { ease: "press" } });
          tl.to(items[from], { clipPath: ABOVE, y: -14, duration: 0.55 }, 0)
            .fromTo(items[to], { clipPath: BELOW, y: 16 }, { clipPath: SHOW, y: 0, duration: 0.8 }, 0.12)
            .fromTo(items[to].querySelector("[data-die]"), { drawSVG: "0% 0%" }, { drawSVG: "0% 100%", duration: 1, ease: "power2.inOut" }, 0.3)
            .fromTo(items[to].querySelectorAll("[data-dim]"), { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.4, stagger: 0.08 }, 0.55);
          cells.forEach((cell, c) => {
            const v = cell.querySelectorAll("[data-v]");
            tl.to(v[from], { yPercent: -100, autoAlpha: 0, duration: 0.4 }, 0.04 * c)
              .fromTo(v[to], { yPercent: 100, autoAlpha: 0 }, { yPercent: 0, autoAlpha: 1, duration: 0.6, ease: "expo.out" }, 0.25 + 0.05 * c);
          });
        }
      }

      if (still) {
        gsap.set(bars[to], { scaleX: 1 });
        return;
      }
      timer.current = gsap.fromTo(bars[to], { scaleX: 0 }, { scaleX: 1, duration: DWELL, ease: "none", onComplete: () => setActive((a) => (a + 1) % N) });
      sync();
    },
    { scope: root, dependencies: [active, reduced], revertOnUpdate: false },
  );

  useEffect(() => {
    sync();
  }, [sync]);

  // off-screen: hold the cycle
  useEffect(() => {
    const el = root.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setHold("offscreen", !e.isIntersecting));
    io.observe(el);
    return () => io.disconnect();
  }, [setHold]);

  const onKey = (e: React.KeyboardEvent, i: number) => {
    const d = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0;
    const to = e.key === "Home" ? 0 : e.key === "End" ? N - 1 : d ? (i + d + N) % N : -1;
    if (to < 0) return;
    e.preventDefault();
    setActive(to);
    tabs.current[to]?.focus();
  };

  const current = industries[active];
  return (
    <div
      ref={root}
      className="relative flex h-full min-h-[38rem] flex-col lg:min-h-0"
      onPointerEnter={() => setHold("hover", true)}
      onPointerLeave={() => setHold("hover", false)}
      onFocus={() => setHold("focus", true)}
      onBlur={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node)) setHold("focus", false);
      }}
    >
      {/* bench header */}
      <div className="flex h-14 items-center gap-4 border-b border-white/10 px-[clamp(1.25rem,2.5vw,2.5rem)] lg:h-[clamp(3rem,6.4svh,3.5rem)]">
        <span className="type-meta whitespace-nowrap text-steel">
          <span className="max-sm:hidden">Specimen </span>
          <span className="text-paper">{pad(active + 1)}</span> / {pad(N)}
        </span>
        <span aria-hidden="true" className="h-px flex-1 bg-white/10" />
        <span className="type-meta whitespace-nowrap text-paper">
          <span className="sm:hidden">{current.short}</span>
          <span className="max-sm:hidden">{current.name}</span>
        </span>
        {!reduced && (
          <button
            type="button"
            onClick={() => setPaused((p) => !p)}
            aria-pressed={paused}
            className="type-meta -mr-2 inline-flex h-11 items-center gap-2 px-2 text-steel hover:text-paper"
          >
            <span aria-hidden="true" className="flex h-2.5 w-2.5 items-center justify-between">
              {paused ? <span className="size-0 border-y-[5px] border-l-[8px] border-y-transparent border-l-current" /> : <><span className="h-full w-[3px] bg-current" /><span className="h-full w-[3px] bg-current" /></>}
            </span>
            {paused ? "Play" : "Pause"}
          </button>
        )}
      </div>

      {/* bench */}
      <div
        role="tabpanel"
        id={`${uid}-panel`}
        aria-labelledby={`${uid}-tab-${active}`}
        className="relative flex flex-1 flex-col"
      >
        <div className="relative grid flex-1 place-items-center px-[clamp(1.5rem,3vw,3rem)] py-16 lg:py-10">
          {/* cutting-mat grid under the specimen, fading out to the bench edges */}
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,#000_30%,transparent_75%)]"
            style={{
              backgroundImage: "linear-gradient(to right, rgb(255 255 255 / 0.05) 1px, transparent 1px), linear-gradient(to bottom, rgb(255 255 255 / 0.05) 1px, transparent 1px)",
              backgroundSize: "32px 32px",
              backgroundPosition: "center",
            }}
          />
          <RegMark className="absolute top-5 left-5 text-steel/50" />
          <RegMark className="absolute top-5 right-5 text-steel/50" />
          {industries.map((ind, i) => (
            <div
              key={ind.id}
              data-spec-item
              aria-hidden={i !== active}
              className="relative col-start-1 row-start-1"
              style={{ width: `min(${WIDTH[ind.id] * 100}%, ${WIDTH[ind.id] * 44}rem)` }}
            >
              <Sticker art={industryLabels[ind.id]} className="block h-auto w-full" decorative={i !== active} />
              <svg aria-hidden="true" className="pointer-events-none absolute -inset-2 h-[calc(100%+1rem)] w-[calc(100%+1rem)] overflow-visible">
                <rect data-die x="0" y="0" width="100%" height="100%" rx="12" fill="none" stroke="var(--color-signal)" strokeWidth="1" />
              </svg>
              <CropMarks className="text-steel/70" gap={20} length={14} />
              <Dimension axis="x" value={ind.size.w} />
              <Dimension axis="y" value={ind.size.h} />
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between gap-4 px-[clamp(1.25rem,2.5vw,2.5rem)] pb-4">
          <ColorBar tone="dark" />
          <span className="type-meta text-steel">Die line · 1 pt · Signal</span>
        </div>

        <dl className="grid grid-cols-2 border-t border-white/10 sm:grid-cols-4">
          {current.spec.map((_, c) => (
            <div key={c} data-spec-cell className="border-white/10 px-[clamp(1.25rem,2.5vw,2.5rem)] py-4 lg:py-[clamp(0.75rem,2svh,1rem)] max-sm:odd:border-r max-sm:[&:nth-child(-n+2)]:border-b sm:not-last:border-r sm:px-5 sm:first:pl-[clamp(1.25rem,2.5vw,2.5rem)]">
              <dt className="type-meta text-steel">{current.spec[c].k}</dt>
              <dd className="relative mt-1.5 grid overflow-hidden text-14 font-medium text-paper">
                {industries.map((ind, i) => (
                  <span key={ind.id} data-v aria-hidden={i !== active} className="col-start-1 row-start-1 leading-snug [overflow-wrap:anywhere]">
                    {ind.spec[c].v}
                  </span>
                ))}
              </dd>
            </div>
          ))}
        </dl>
      </div>

      <div role="tablist" aria-label="Industry specimens" className="grid grid-cols-4 border-t border-white/10">
        {industries.map((ind, i) => {
          const on = i === active;
          return (
            <button
              key={ind.id}
              ref={(el) => {
                tabs.current[i] = el;
              }}
              id={`${uid}-tab-${i}`}
              type="button"
              role="tab"
              aria-selected={on}
              aria-controls={`${uid}-panel`}
              tabIndex={on ? 0 : -1}
              onClick={() => setActive(i)}
              onKeyDown={(e) => onKey(e, i)}
              className="group relative flex h-[4.5rem] flex-col justify-center lg:h-[clamp(3.75rem,8svh,4.5rem)] border-white/10 px-[clamp(0.75rem,1.6vw,1.5rem)] text-left not-last:border-r"
            >
              <span aria-hidden="true" className="absolute inset-x-0 top-0 h-0.5 bg-white/10">
                <span data-bar className="block h-full origin-left scale-x-0 bg-signal" />
              </span>
              <span className={cn("type-meta", on ? "text-signal" : "text-steel")}>{pad(i + 1)}</span>
              <span className={cn("mt-1 text-13 font-medium transition-colors sm:text-14", on ? "text-paper" : "text-steel group-hover:text-paper")}>{ind.short}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
