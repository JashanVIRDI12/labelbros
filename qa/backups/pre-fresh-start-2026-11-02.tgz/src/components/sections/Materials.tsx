"use client";

import { useState } from "react";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { MaterialsMotion } from "@/components/sections/materials/MaterialsMotion";
import { DurabilityIcons } from "@/components/sections/materials/DurabilityIcons";
import { FinishSticker2D } from "@/components/sections/materials/FinishSticker2D";
import { CropMarks } from "@/components/ui/PrintMarks";
import { IndexRule } from "@/components/ui/SectionHead";
import { materialsCopy } from "@/data/copy";
import { materials } from "@/data/materials";
import { cn } from "@/lib/utils";

/**
 * S6. Desktop: pinned; scrolling morphs one 3D material-test plate through every film
 * (store.finish). The list doubles as controls: pick a film directly, which matters for reduced
 * motion, where it's the only way to swap. The 2D plate is the low-tier / pre-canvas stand-in.
 */
export function Materials() {
  const [active, setActive] = useState(0);
  const current = materials[active];

  return (
    <section id="materials" aria-labelledby="materials-title" className="materials-stage relative page-x" style={{ paddingBlock: "calc(var(--header-h) * 0.5)" }}>
      <div data-tint aria-hidden="true" className="absolute inset-0 -z-10 opacity-0" style={{ background: current.tint }} />
      <div className="grid h-full grid-cols-12 items-center gap-x-6 gap-y-10 py-8 stage:py-0">
        <div className="col-span-12 flex flex-col items-center justify-center lg:col-span-6">
          <div className="relative">
            <div data-anchor="finish" className="relative w-[min(48vw,24svh,460px)] calm:w-[min(70vw,460px)] lg:w-[min(32vw,480px)]">
              <FinishSticker2D material={current} className="[:root[data-three~=finish][data-scenes~=materials]_&]:invisible" />
            </div>
            <CropMarks className="text-ink/25" gap={14} length={16} />
          </div>
          <p className="type-meta mt-8 hidden lg:block">
            Film {String(active + 1).padStart(2, "0")} / {String(materials.length).padStart(2, "0")} · <span className="text-ink">{current.name}</span>
          </p>
          <div className="material-summary mt-5 flex max-w-xs flex-col items-center gap-3 text-center text-14 lg:hidden calm:hidden">
            {current.bestFor}
            <DurabilityIcons list={current.durability} />
          </div>
        </div>

        <div className="col-span-12 lg:col-span-6">
          <IndexRule index={materialsCopy.index} label={materialsCopy.eyebrow} />
          <h2 id="materials-title" className="type-display mt-6 max-w-[16ch] text-[clamp(2rem,3.4vw,3.5rem)]">
            {materialsCopy.title}
          </h2>
          <p className="type-meta mt-4">{materialsCopy.caption}</p>
          <ol className="material-list mt-6 border-b border-line">
            {materials.map((m, i) => {
              const on = i === active;
              return (
                <li key={m.id}>
                  <button
                    type="button"
                    data-material={i}
                    aria-pressed={on}
                    onClick={() => setActive(i)}
                    className="grid w-full grid-cols-[2.25rem_1fr_auto] items-center gap-x-4 border-t border-line py-2.5 text-left"
                  >
                    <span className={cn("type-meta", on && "text-signal-text")}>{String(i + 1).padStart(2, "0")}</span>
                    <span>
                      <span className={cn("type-h3 block text-[clamp(1.25rem,1.7vw,1.75rem)] transition-colors duration-300", on ? "text-ink" : "text-ink-soft")}>{m.name}</span>
                      <span data-best-for className={cn("mt-1 block text-14 text-ink-soft", !on && "stage:hidden")}>
                        {m.bestFor}
                      </span>
                    </span>
                    <span className="flex items-center gap-3">
                      <span data-durability className={cn(!on && "stage:hidden")}>
                        <DurabilityIcons list={m.durability} />
                      </span>
                      <span aria-hidden="true" className="size-6 rounded-xs border border-ink/15" style={{ background: m.swatch }} />
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
      <NearViewport>
        <MaterialsMotion onActive={setActive} />
      </NearViewport>
    </section>
  );
}
