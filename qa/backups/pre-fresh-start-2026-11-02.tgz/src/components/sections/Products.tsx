import { NearViewport } from "@/components/sections/motion/NearViewport";
import { ProductsMotion } from "@/components/sections/products/ProductsMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { productArt } from "@/components/stickers/productArt";
import { Arrow } from "@/components/ui/Button";
import { CropMarks } from "@/components/ui/PrintMarks";
import { SectionHead } from "@/components/ui/SectionHead";
import { productsCopy } from "@/data/copy";
import { products } from "@/data/products";

/** The roll the liner unspools from (rotates with the track on desktop). */
function RollCore() {
  return (
    <svg data-roll viewBox="0 0 200 200" className="size-full" aria-hidden="true" focusable="false">
      <circle cx="100" cy="100" r="98" fill="#FFFFFF" stroke="#0E0F10" strokeWidth="1.5" />
      {[88, 78, 68, 58].map((r) => (
        <circle key={r} cx="100" cy="100" r={r} fill="none" stroke="#0E0F10" strokeOpacity=".12" strokeWidth="1" />
      ))}
      <circle cx="100" cy="100" r="44" fill="#F1F0EC" stroke="#0E0F10" strokeWidth="2" />
      <circle cx="100" cy="100" r="24" fill="none" stroke="#0E0F10" strokeWidth="1.5" />
      <rect x="96" y="2" width="8" height="16" fill="#FF4F00" />
    </svg>
  );
}

/**
 * S5. Desktop: pinned horizontal track; a label roll unspools a liner and each product card
 * lifts off it. Touch: native scroll-snap carousel. Reduced motion: a plain grid.
 */
export function Products() {
  const total = String(products.length).padStart(2, "0");
  return (
    <section id="products" aria-labelledby="products-title" className="relative overflow-x-clip stage:flex stage:h-svh stage:flex-col stage:justify-center">
      <div className="grid gap-6 page-x pt-24 lg:grid-cols-12 lg:items-end stage:pt-[calc(var(--header-h)+1rem)]">
        <SectionHead
          id="products-title"
          index={productsCopy.index}
          eyebrow={productsCopy.eyebrow}
          title={productsCopy.title}
          meta={
            <span aria-hidden="true" className="hidden stage:inline">
              <span data-counter className="text-ink">01</span> / {total}
            </span>
          }
          aside={<p className="type-lede max-w-[36ch] lg:ml-auto lg:text-right">{productsCopy.lede}</p>}
          className="lg:col-span-12"
        />
      </div>

      <div
        data-track-viewport
        className="relative mt-12 snap-x snap-mandatory overflow-x-auto overscroll-x-contain pb-6 [scrollbar-width:none] stage:mt-[clamp(2rem,5svh,3.5rem)] stage:overflow-visible stage:pb-0 calm:snap-none calm:overflow-visible"
      >
        <div
          data-track
          className="relative flex w-max items-stretch gap-4 page-x stage:gap-6 stage:pr-[calc(var(--margin)+clamp(140px,13vw,220px)*0.6)] calm:grid calm:w-auto calm:grid-cols-1 calm:sm:grid-cols-2 calm:lg:grid-cols-4"
        >
          {/* the liner the labels sit on */}
          <div aria-hidden="true" className="absolute inset-x-0 top-[10%] bottom-[10%] -z-10 border-y border-ink/10 bg-[#E7E5DF] calm:hidden" />
          {products.map((p, i) => (
            <article
              key={p.id}
              data-product
              className="relative w-[min(80vw,320px)] shrink-0 snap-start scroll-ml-[var(--margin)] stage:w-[clamp(290px,22vw,350px)] calm:w-auto"
            >
              <div data-card className="h-full">
                <div className="group relative flex h-full flex-col rounded-xs border border-ink/10 bg-sheet p-5 transition-colors duration-300 hover:border-ink/40">
                  <div className="relative aspect-[4/3] bg-paper">
                    <span className="type-meta absolute top-3 left-3">{String(i + 1).padStart(2, "0")}</span>
                    <div className="absolute inset-[10%]">
                      <Sticker art={productArt[p.id]} className="h-full w-full transition-transform duration-500 ease-out group-hover:scale-[1.03]" />
                    </div>
                    <CropMarks className="text-ink/25" gap={4} length={8} />
                  </div>
                  <h3 className="type-h3 mt-6 text-24">{p.name}</h3>
                  <p className="mt-2 flex-1 text-15 leading-relaxed text-ink-soft">{p.line}</p>
                  <p className="type-meta mt-4 text-ink">{p.films}</p>
                  <div className="mt-4 flex items-center justify-between border-t border-line pt-4">
                    <p className="text-15">
                      <span className="type-meta mr-2">From</span>
                      <span className="font-semibold">{p.price}</span>
                    </p>
                    <a href={p.href} className="inline-flex size-11 items-center justify-center rounded-xs bg-ink text-paper transition-colors after:absolute after:inset-0 group-hover:bg-signal group-hover:text-ink">
                      <span className="sr-only">Price {p.name}</span>
                      <Arrow />
                    </a>
                  </div>
                </div>
              </div>
            </article>
          ))}
          <div aria-hidden="true" className="w-px shrink-0 calm:hidden" />
        </div>

        <div
          aria-hidden="true"
          data-anchor="roll"
          className="pointer-events-none absolute [:root[data-three~=roll][data-scenes~=products]_&]:invisible right-[calc(clamp(140px,13vw,220px)*-0.72)] top-1/2 hidden size-[clamp(140px,13vw,220px)] -translate-y-1/2 stage:block"
        >
          <RollCore />
        </div>
      </div>
      <NearViewport>
        <ProductsMotion />
      </NearViewport>
    </section>
  );
}
