import { NearViewport } from "@/components/sections/motion/NearViewport";
import { FinalCtaMotion } from "@/components/sections/motion/FinalCtaMotion";
import { Arrow, ButtonLink } from "@/components/ui/Button";
import { ColorBar, RegMark } from "@/components/ui/PrintMarks";
import { IndexRule } from "@/components/ui/SectionHead";
import { cta, finalCta, hero } from "@/data/copy";

/** One trim corner: two hairlines meeting at the headline's corner, pointing outward. */
function Corner({ at }: { at: "tl" | "tr" | "bl" | "br" }) {
  const top = at[0] === "t";
  const left = at[1] === "l";
  return (
    <span
      data-trim={at}
      aria-hidden="true"
      className="absolute size-0 text-ink/50"
      style={{ [top ? "top" : "bottom"]: 0, [left ? "left" : "right"]: 0 }}
    >
      <span className="absolute h-px w-6 bg-current" style={{ [left ? "right" : "left"]: 12, top: 0 }} />
      <span className="absolute h-6 w-px bg-current" style={{ [top ? "bottom" : "top"]: 12, left: 0 }} />
    </span>
  );
}

/** S10. Signature: trim. Crop marks travel in from the page edges and close on the headline. */
export function FinalCta() {
  return (
    <section id="cta" aria-labelledby="cta-title" className="relative overflow-hidden page-x pt-24 pb-20 lg:pt-36 lg:pb-28">
      <IndexRule index="10" label="Start a job" />
      <div className="relative mt-16 w-fit lg:mt-24">
        <h2 id="cta-title" className="type-display text-[clamp(3.25rem,9.6vw,10rem)] leading-[0.9] tracking-[-0.055em]" aria-label={finalCta.lines.join(" ")}>
          {finalCta.lines.map((line) => (
            <span key={line} aria-hidden="true" data-cta-line className="block whitespace-nowrap">
              {line}
            </span>
          ))}
        </h2>
        <Corner at="tl" />
        <Corner at="tr" />
        <Corner at="bl" />
        <Corner at="br" />
      </div>

      <div className="mt-16 grid gap-10 border-t border-ink pt-8 lg:mt-20 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="type-lede max-w-[34ch]">{finalCta.lede}</p>
          <ul className="mt-6 max-w-[28rem] border-t border-line" aria-label="Two ways to get your artwork">
            {hero.paths.map((p) => (
              <li key={p.k} className="border-b border-line">
                <a href={p.href} className="group flex h-12 items-center gap-4 text-15">
                  <span className="w-28 shrink-0 text-ink-soft">{p.k}</span>
                  <span className="font-medium">{p.v}</span>
                  <Arrow className="ml-auto text-ink-soft transition-transform duration-300 group-hover:translate-x-1 group-hover:text-ink" />
                </a>
              </li>
            ))}
          </ul>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row lg:col-span-7 lg:justify-end">
          <ButtonLink href={cta.primary.href} arrow>
            {cta.primary.label}
          </ButtonLink>
          <ButtonLink href={`mailto:${finalCta.email}`} variant="outline">
            {cta.specialist.label}
          </ButtonLink>
        </div>
      </div>
      <div className="mt-10 flex flex-wrap items-center justify-between gap-6">
        <p className="type-meta text-ink">
          {finalCta.email} · {finalCta.hours}
        </p>
        <span className="flex items-center gap-4 text-ink/40">
          <ColorBar />
          <RegMark className="size-4" />
        </span>
      </div>
      <NearViewport>
        <FinalCtaMotion />
      </NearViewport>
    </section>
  );
}
