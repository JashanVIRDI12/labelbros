"use client";

import { useRef } from "react";
import { gsap, SplitText, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";

/** Where each trim corner starts before it closes on the headline, in viewport units. */
const FROM = { tl: [-1, -1], tr: [1, -1], bl: [-1, 1], br: [1, 1] } as const;

/**
 * S10 signature: trim. Scrubbed: the headline lines rise through their masks while four crop
 * marks travel in from the page edges and close on the headline's corners. Reduced motion: static.
 */
export function FinalCtaMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(
    () => {
      const root = scope.current;
      if (!root) return;
      const mm = gsap.matchMedia();
      mm.add(MQ, (ctx) => {
        const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
        if (reduceMotion) return;
        const corners = gsap.utils.toArray<HTMLElement>("[data-trim]", root);
        const split = SplitText.create(root.querySelectorAll("[data-cta-line]"), { type: "lines", mask: "lines", aria: "none" });
        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: { trigger: root, start: "top 85%", end: isDesktop ? "center 60%" : "center 70%", scrub: 1 },
        });
        tl.from(split.lines, { yPercent: 105, duration: 0.6, stagger: 0.15 }, 0).from(
          corners,
          {
            x: (i: number) => FROM[corners[i].dataset.trim as keyof typeof FROM][0] * window.innerWidth * 0.12,
            y: (i: number) => FROM[corners[i].dataset.trim as keyof typeof FROM][1] * window.innerHeight * 0.1,
            opacity: 0,
            duration: 0.75,
          },
          0.1,
        );
        return () => split.revert();
      });
    },
    { scope },
  );
  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("section") ?? null;
      }}
    />
  );
}
