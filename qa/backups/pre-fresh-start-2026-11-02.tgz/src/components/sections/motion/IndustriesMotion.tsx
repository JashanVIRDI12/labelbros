"use client";

import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";

/** Where each plate starts, in px, before it pulls into register: [cyan, magenta] per card. */
const OFFSETS = [
  [{ x: -14, y: -8 }, { x: 12, y: 9 }],
  [{ x: 12, y: -10 }, { x: -10, y: 8 }],
  [{ x: -10, y: 10 }, { x: 14, y: -6 }],
  [{ x: 9, y: 12 }, { x: -13, y: -9 }],
];

/**
 * Industries signature: registration. Cyan and magenta plates start out of register over each
 * label and pull into alignment as the row scrolls up (scrubbed), fading as they lock.
 */
export function IndustriesMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(
    () => {
      const root = scope.current;
      if (!root) return;
      const mm = gsap.matchMedia();
      mm.add(MQ, (ctx) => {
        const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
        if (reduceMotion) return;
        const k = isDesktop ? 1 : 0.6;
        gsap.utils.toArray<HTMLElement>("[data-industry]", root).forEach((card, i) => {
          const plates = card.querySelectorAll<HTMLElement>("[data-plate]");
          const o = OFFSETS[i % OFFSETS.length];
          gsap
            .timeline({
              defaults: { ease: "none" },
              scrollTrigger: { trigger: card, start: "top 92%", end: isDesktop ? "top 40%" : "top 55%", scrub: 1 },
            })
            .fromTo(plates, { x: (j: number) => o[j].x * k, y: (j: number) => o[j].y * k, opacity: 0.9 }, { x: 0, y: 0, duration: 0.8 }, 0)
            .to(plates, { opacity: 0, duration: 0.25 }, 0.75);
        });
      });
    },
    { scope },
  );
  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("section") ?? null;
      }}
    />
  );
}
