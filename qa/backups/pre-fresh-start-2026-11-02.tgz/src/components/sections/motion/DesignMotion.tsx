"use client";

import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";

/**
 * Two ways in. Signature: the junction. The two roads draw down from each path and meet at
 * the proof (scrubbed); the proof node seats when they arrive. Each path's visual plays its
 * small beat once: the prepress checks tick through, the review markup lands.
 */
export function DesignMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(
    () => {
      const root = scope.current;
      if (!root) return;
      const q = gsap.utils.selector(root);
      const mm = gsap.matchMedia();
      mm.add(MQ, (ctx) => {
        const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
        if (reduceMotion) return;

        gsap
          .timeline({ scrollTrigger: { trigger: q('[data-path="upload"] [data-check]')[0], start: "top 80%", once: true } })
          .from(q("[data-check]"), { autoAlpha: 0, x: -10, duration: 0.5, ease: "expo.out", stagger: 0.12 })
          .from(q("[data-check] > span"), { scale: 0.4, duration: 0.4, ease: "press", stagger: 0.12 }, 0.1);

        gsap.from(q("[data-markup]"), {
          autoAlpha: 0,
          y: (i: number) => (i ? 10 : -10),
          duration: 0.6,
          ease: "press",
          stagger: 0.2,
          scrollTrigger: { trigger: q('[data-path="design"] [data-markup]')[0], start: "top 80%", once: true },
        });

        if (!isDesktop) return;
        gsap
          .timeline({ defaults: { ease: "none" }, scrollTrigger: { trigger: q("[data-junction]")[0], start: "top 90%", end: "bottom 60%", scrub: 1 } })
          .fromTo(q("[data-road]"), { drawSVG: "0% 0%" }, { drawSVG: "0% 100%", duration: 0.8 })
          .fromTo(q("[data-join-check]"), { scale: 0 }, { scale: 1, duration: 0.2 }, 0.8);
      });
    },
    { scope },
  );
  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("section") ?? null;
      }}
    />
  );
}
