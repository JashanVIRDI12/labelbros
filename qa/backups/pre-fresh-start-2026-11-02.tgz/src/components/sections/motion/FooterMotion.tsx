"use client";
import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { getLenis } from "@/lib/lenis";
import { MQ } from "@/lib/motion";

/**
 * Footer curtain support. A sticky footer's rectangle is always in the viewport even while main
 * covers it, so watch its normal-flow marker instead; keyboard focus inside reveals it.
 */
export function FooterMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(
    () => {
      const footer = scope.current;
      const marker = document.querySelector("[data-footer-start]");
      if (!footer || !marker) return;
      const mm = gsap.matchMedia();
      mm.add(MQ, () => {
        const io = new IntersectionObserver(
          ([entry]) => {
            footer.dataset.footerVisible = String(entry.isIntersecting);
          },
          { rootMargin: "100% 0px" },
        );
        io.observe(marker);
        const focus = () => {
          footer.dataset.footerVisible = "true";
          if (marker.getBoundingClientRect().top > window.innerHeight) {
            const end = document.documentElement.scrollHeight - window.innerHeight;
            const lenis = getLenis();
            if (lenis) lenis.scrollTo(end, { immediate: true });
            else window.scrollTo(0, end);
          }
        };
        footer.addEventListener("focusin", focus);
        return () => {
          io.disconnect();
          footer.removeEventListener("focusin", focus);
        };
      });
    },
    { scope },
  );
  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("footer") ?? null;
      }}
    />
  );
}
