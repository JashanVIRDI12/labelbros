"use client";

import { useRef } from "react";
import { gsap, ScrollTrigger, SplitText, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";
import { setProgress, setSceneActive } from "@/lib/scrollStore";

/**
 * S4 motion (DOM side). Pin +200% (touch +120%): store.wrap drives the 3D wrap, turn, light
 * sweep and camera pull-back; the headline lines enter through SplitText masks at 0.15 / 0.45 /
 * 0.75. store.bridge / wrapOut let the 3D jar ride in and out with the section exactly.
 */
export function WrapMotion() {
  const scope = useRef<HTMLElement | null>(null);

  useGSAP(
    () => {
      const maybeRoot = scope.current;
      if (!maybeRoot) return;
      const root: HTMLElement = maybeRoot;
      const q = gsap.utils.selector(root);
      const mm = gsap.matchMedia();

      mm.add(MQ, (ctx) => {
        const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
        if (reduceMotion) return;

        const split = SplitText.create(q("[data-wrap-title] [data-wrap-line]"), { type: "lines", mask: "lines", aria: "none" });

        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: {
            id: "wrap",
            trigger: root,
            start: "top top",
            end: isDesktop ? "+=200%" : "+=120%",
            pin: true,
            pinSpacing: true,
            anticipatePin: 1,
            scrub: 1,
            refreshPriority: 70,
            onUpdate: (self) => setProgress("wrap", self.progress),
          },
        });
        tl.set({}, {}, 1); // timeline spans 0..1 so positions read as progress
        split.lines.forEach((line, i) => {
          tl.fromTo(line, { yPercent: 110 }, { yPercent: 0, duration: 0.08 }, [0.15, 0.45, 0.75][i] ?? 0.75);
        });
        // proof points and finish chips stay put: usable from the first frame, no generic fade-up

        const pin = tl.scrollTrigger!;

        // S3 scrolling in (one viewport) and out (one viewport): raw progress for the 3D jar
        ScrollTrigger.create({
          trigger: root,
          start: "top bottom",
          end: "top top",
          refreshPriority: 75,
          onUpdate: (self) => setProgress("bridge", self.progress),
          onLeave: () => setProgress("bridge", 1),
          onLeaveBack: () => setProgress("bridge", 0),
        });
        ScrollTrigger.create({
          start: () => pin.end,
          end: () => pin.end + window.innerHeight,
          refreshPriority: 65,
          onUpdate: (self) => setProgress("wrapOut", self.progress),
          onLeave: () => setProgress("wrapOut", 1),
          onLeaveBack: () => setProgress("wrapOut", 0),
        });
        // the 3D jar exists from the moment S3 peeks in until it has scrolled away
        ScrollTrigger.create({
          trigger: root,
          start: "top bottom",
          end: () => pin.end + window.innerHeight,
          refreshPriority: 66,
          onToggle: (self) => setSceneActive("wrap", self.isActive),
        });

        return () => setSceneActive("wrap", false);
      });
    },
    { scope },
  );

  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("section") ?? null;
      }}
    />
  );
}
