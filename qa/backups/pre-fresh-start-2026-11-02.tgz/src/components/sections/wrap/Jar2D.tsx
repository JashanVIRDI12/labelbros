import { Sticker } from "@/components/stickers/Sticker";
import { honeyLabel } from "@/components/stickers/art";
import { cn } from "@/lib/utils";

export type WrapFinish = "Matte" | "Gloss" | "Holographic" | "Metallised" | "Clear";

/**
 * Flat jar with the honey label wrapped on it: the reduced-motion and low-tier stand-in
 * for the 3D wrap, and what shows before the canvas loads. Each finish changes the label overlay.
 */
export function Jar2D({ finish = "Matte", className }: { finish?: WrapFinish; className?: string }) {
  return (
    <div className={cn("relative aspect-[300/380]", className)} aria-hidden="true">
      <svg viewBox="0 0 300 380" className="absolute inset-0 h-full w-full">
        <ellipse cx="150" cy="364" rx="118" ry="10" fill="#0E0F10" opacity=".08" />
        <rect x="74" y="18" width="152" height="48" rx="8" fill="#0E0F10" />
        <g stroke="#F1F0EC" strokeOpacity=".22" strokeWidth="2">
          {[92, 112, 132, 152, 172, 192, 208].map((x) => (
            <line key={x} x1={x} y1="26" x2={x} y2="58" />
          ))}
        </g>
        <rect x="84" y="62" width="132" height="22" rx="4" fill="#D9A55A" opacity=".7" />
        <rect x="40" y="80" width="220" height="280" rx="48" fill="#C8802C" />
        <rect x="40" y="80" width="220" height="280" rx="48" fill="#E3A24A" opacity=".25" />
        <rect x="222" y="104" width="18" height="236" rx="9" fill="#0E0F10" opacity=".1" />
        <rect x="58" y="104" width="12" height="236" rx="6" fill="#FFFFFF" opacity=".4" />
      </svg>
      <div className="absolute left-[15%] top-[46%] w-[70%]">
        <div className={cn("relative", finish === "Clear" && "[&_rect:nth-of-type(-n+2)]:opacity-0")}>
          <Sticker art={honeyLabel} className="block w-full" />
          {finish === "Gloss" && <span className="absolute inset-y-[6%] left-[18%] w-[9%] -skew-x-12 bg-white/55" />}
          {finish === "Holographic" && (
            <span
              className="absolute inset-[3%] rounded-[10px] mix-blend-screen"
              style={{ background: "repeating-linear-gradient(115deg, #c9d6ff66 0 14px, #b9f0e466 14px 28px, #ffe7b355 28px 42px)" }}
            />
          )}
          {finish === "Metallised" && <span className="absolute inset-[3%] rounded-[10px] bg-white/40 mix-blend-luminosity" />}
        </div>
      </div>
    </div>
  );
}
