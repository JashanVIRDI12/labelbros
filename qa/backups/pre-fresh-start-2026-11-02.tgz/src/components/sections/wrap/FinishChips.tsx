"use client";

import { useRef } from "react";
import { cn } from "@/lib/utils";

type Props<T extends string> = {
  label: string;
  options: readonly T[];
  value: T;
  onChange: (v: T) => void;
  tone?: "ink" | "dark";
};

/** Segmented control with roving focus and arrow-key navigation (WAI-ARIA radio pattern). */
export function FinishChips<T extends string>({ label, options, value, onChange, tone = "ink" }: Props<T>) {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);

  const onKey = (e: React.KeyboardEvent, i: number) => {
    const delta = e.key === "ArrowRight" || e.key === "ArrowDown" ? 1 : e.key === "ArrowLeft" || e.key === "ArrowUp" ? -1 : 0;
    if (!delta) return;
    e.preventDefault();
    const next = (i + delta + options.length) % options.length;
    onChange(options[next]);
    refs.current[next]?.focus();
  };

  const dark = tone === "dark";
  return (
    <div
      role="radiogroup"
      aria-label={label}
      className={cn("inline-flex flex-wrap gap-1 rounded-xs border p-1", dark ? "border-white/15" : "border-ink/15 bg-sheet")}
    >
      {options.map((opt, i) => {
        const on = opt === value;
        return (
          <button
            key={opt}
            ref={(el) => {
              refs.current[i] = el;
            }}
            type="button"
            role="radio"
            aria-checked={on}
            tabIndex={on ? 0 : -1}
            onClick={() => onChange(opt)}
            onKeyDown={(e) => onKey(e, i)}
            className={cn(
              "type-label inline-flex h-10 items-center rounded-[1px] px-4 text-14 transition-colors duration-200",
              !dark && (on ? "bg-ink text-paper" : "text-ink hover:bg-ink/[0.06]"),
              dark && (on ? "bg-paper text-ink" : "text-paper hover:bg-white/[0.08]"),
            )}
          >
            {opt}
          </button>
        );
      })}
    </div>
  );
}
