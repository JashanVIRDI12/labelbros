"use client";

import { useCallback, useId, useState } from "react";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { SampleMotion } from "@/components/sections/motion/SampleMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { peelMe } from "@/components/stickers/art";
import { ButtonLink } from "@/components/ui/Button";
import { CropMarks } from "@/components/ui/PrintMarks";
import { SectionHead } from "@/components/ui/SectionHead";
import { cta, sample } from "@/data/copy";
import { cn } from "@/lib/utils";

/** The residue a lifted tamper-evident seal leaves behind. */
function VoidPattern() {
  return (
    <svg aria-hidden="true" className="absolute inset-0 h-full w-full">
      <defs>
        <pattern id="void-pattern" width="76" height="30" patternUnits="userSpaceOnUse" patternTransform="rotate(-12)">
          <text x="0" y="20" fontSize="13" fontWeight="700" letterSpacing="2" fill="var(--color-signal-text)" opacity="0.07">
            VOID
          </text>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#void-pattern)" />
    </svg>
  );
}

/**
 * S9. A tamper-evident seal hides a discount code. A teaser lift and drag-to-peel use the shared
 * 3D peel shader, with a DOM fallback when WebGL is unavailable; the Peel button is the keyboard
 * path and the reduced-motion path, and it always works.
 */
export function SamplePack() {
  const [peeled, setPeeled] = useState(false);
  const [msg, setMsg] = useState("");
  const codeId = useId();

  const peel = useCallback(async () => {
    setPeeled(true);
    try {
      await navigator.clipboard.writeText(sample.code);
      setMsg(`Code ${sample.code} revealed and copied.`);
    } catch {
      setMsg(`Code ${sample.code} revealed.`);
    }
  }, []);

  return (
    <section id="samples" aria-labelledby="samples-title" className="relative bg-graphite text-paper page-x py-24 lg:py-36">
      <div className="grid grid-cols-12 items-center gap-x-6 gap-y-16">
        <div className="col-span-12 lg:col-span-6">
          <SectionHead tone="dark" id="samples-title" index={sample.index} eyebrow={sample.eyebrow} title={sample.title} lede={sample.lede} />
          <p className="mt-10 flex items-baseline gap-3">
            <span className="type-meta text-steel">Kit</span>
            <span className="type-display text-[clamp(2.25rem,4vw,3.5rem)] leading-none [overflow-wrap:anywhere]">{sample.price}</span>
          </p>
          <ul className="mt-10 grid gap-6 sm:grid-cols-3">
            {sample.points.map((p) => (
              <li key={p.title} className="border-t border-white/15 pt-3">
                <span className="block text-16 font-semibold">{p.title}</span>
                <span className="mt-1 block text-14 text-steel">{p.caption}</span>
              </li>
            ))}
          </ul>
          <ButtonLink href={cta.secondary.href} variant="light" arrow className="mt-10">
            {cta.secondary.label}
          </ButtonLink>
        </div>

        <div className="col-span-12 flex flex-col items-center lg:col-span-6">
          <div className="relative w-[min(86vw,460px)]">
            <div className="relative flex aspect-[5/3] flex-col items-center justify-center overflow-hidden rounded-xs bg-paper p-6 text-center text-ink">
              <VoidPattern />
              <p className="type-meta relative">Your first-run code</p>
              <p id={codeId} className={cn("type-display relative mt-2 text-[clamp(2.25rem,5.4vw,4rem)] leading-none", !peeled && "invisible calm:visible")}>
                {sample.code}
              </p>
              <p className="type-meta relative mt-3 text-ink">{peeled ? "Use it at checkout" : sample.peelHint}</p>
            </div>
            <CropMarks className="text-steel/60" gap={10} length={14} />
            <div data-peel-box className="pointer-events-none absolute top-[5%] left-[19%] aspect-square w-[62%] calm:hidden">
              <div
                data-anchor="peel"
                aria-hidden="true"
                className={cn("absolute inset-0 w-full [rotate:-6deg]", peeled && "pointer-events-none -translate-y-[160%] opacity-0")}
              >
                <Sticker art={peelMe} className="block w-full [:root[data-three~=sample][data-scenes~=sample]_&]:invisible" />
              </div>
            </div>
            {!peeled && (
              <button
                type="button"
                data-peel-drag
                tabIndex={-1}
                aria-hidden="true"
                className="absolute top-0 right-[18%] flex size-12 cursor-grab touch-none items-center justify-center rounded-xs bg-signal text-ink active:cursor-grabbing calm:hidden"
              >
                <svg viewBox="0 0 20 20" className="size-5" aria-hidden="true">
                  <path d="M5 15 15 5m0 0H7m8 0v8" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
                </svg>
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={(e) => e.currentTarget.closest("section")?.dispatchEvent(new Event("lb:peel-request"))}
            disabled={peeled}
            aria-controls={codeId}
            className="type-label mt-10 inline-flex h-12 items-center gap-3 rounded-xs border border-white/25 px-6 text-15 transition-colors hover:border-paper disabled:opacity-40"
          >
            {peeled ? "Seal peeled" : "Peel the seal"}
          </button>
          <p aria-live="polite" className="mt-3 min-h-6 text-14 text-steel">
            {msg}
          </p>
        </div>
      </div>
      <NearViewport>
        <SampleMotion onReveal={peel} revealed={peeled} />
      </NearViewport>
    </section>
  );
}
