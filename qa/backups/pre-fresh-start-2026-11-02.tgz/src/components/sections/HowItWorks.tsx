import { NearViewport } from "@/components/sections/motion/NearViewport";
import { HowMotion } from "@/components/sections/how/HowMotion";
import { SectionHead } from "@/components/ui/SectionHead";
import { how } from "@/data/copy";

/**
 * S3 process: spec, proof, print, ship. Signature: the line. A production rule runs under the
 * four steps and fills in signal orange as you scroll; each station lights as the fill reaches it.
 */
export function HowItWorks() {
  return (
    <section id="how" aria-labelledby="how-title" className="relative page-x pt-24 pb-20 lg:pt-36 lg:pb-16">
      <SectionHead id="how-title" index={how.index} eyebrow={how.eyebrow} title={how.title} />

      <div className="relative mt-16 lg:mt-24">
        <div aria-hidden="true" className="absolute inset-x-0 top-0 hidden h-0.5 bg-line lg:block">
          <span data-line-fill className="absolute inset-0 origin-left scale-x-0 bg-signal calm:scale-x-100" />
        </div>
        <ol className="grid gap-y-14 sm:grid-cols-2 sm:gap-x-8 lg:grid-cols-4 lg:gap-x-0">
          {how.steps.map((s) => (
            <li key={s.n} data-step className="group relative flex flex-col border-t border-line pt-8 lg:border-t-0 lg:pt-12 lg:pr-10">
              <span aria-hidden="true" data-node className="absolute -top-1 left-0 hidden size-2.5 border border-ink bg-paper transition-colors duration-300 group-data-[on=true]:border-signal group-data-[on=true]:bg-signal calm:border-signal calm:bg-signal lg:block" />
              <p className="type-meta text-signal-text">{s.n}</p>
              <h3 className="type-display mt-3 text-[clamp(2.5rem,4.6vw,4.5rem)]">{s.title}</h3>
              <p className="mt-5 max-w-[30ch] text-16 leading-relaxed text-ink-soft">{s.line}</p>
              <div className="mt-auto pt-8">
                <p className="type-meta border-t border-line pt-3 text-ink">{s.caption}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
      <NearViewport>
        <HowMotion />
      </NearViewport>
    </section>
  );
}
