"use client";

import { useDeferredValue, useId, useMemo, useRef, useState } from "react";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { QuoteMotion } from "@/components/sections/motion/QuoteMotion";
import { ChipRadio } from "@/components/sections/quote/ChipRadio";
import { ButtonLink } from "@/components/ui/Button";
import { SectionHead } from "@/components/ui/SectionHead";
import { quoteCopy, quoteArtwork } from "@/data/copy";
import {
  breaks,
  money,
  productTypes,
  quantities,
  quote,
  quoteMaterials,
  SAMPLE_PRICING,
  SIZE_MAX,
  SIZE_MIN,
  sizeError,
  sizePresets,
  type QuoteInput,
} from "@/data/pricing";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";
import { cn } from "@/lib/utils";

const sizeOptions = [...sizePresets.map((s) => ({ id: s.id, label: s.label })), { id: "custom", label: "Custom" }];
const qtyLabel = (n: number) => n.toLocaleString("en-US");

/** A little stack of label sheets beside the price: grows with quantity. */
function SheetStack({ qty }: { qty: number }) {
  const scope = useRef<HTMLDivElement>(null);
  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      if (!motionFlags(ctx.conditions).reduceMotion) gsap.fromTo(scope.current, { scaleY: 0.85 }, { scaleY: 1, duration: 0.35, ease: "press" });
    });
  }, { scope, dependencies: [qty], revertOnUpdate: true });
  const sheets = Math.max(1, Math.min(8, Math.round(Math.log2(qty / 25))));
  return (
    <div ref={scope} data-sheet-stack aria-hidden="true" className="relative h-20 w-16 shrink-0 origin-bottom">
      {Array.from({ length: sheets }, (_, i) => (
        <span
          key={i}
          className="absolute bottom-0 left-0 h-16 w-12 rounded-[2px] border border-white/40 bg-graphite-2"
          style={{ transform: `translate(${i * 3}px, ${-i * 3}px)` }}
        >
          {i === sheets - 1 && (
            <>
              <span className="absolute inset-x-1.5 top-1.5 h-2 bg-paper" />
              <span className="absolute left-1.5 top-5 h-1 w-6 bg-white/40" />
              <span className="absolute left-1.5 top-7 h-1 w-4 bg-white/40" />
              <span className="absolute bottom-1.5 right-1.5 size-2 bg-signal" />
            </>
          )}
        </span>
      ))}
    </div>
  );
}

/**
 * S7. Mini configurator. Pricing is [[REAL_PRICING]] (sample numbers, flagged in the UI).
 * States: custom size empty → prompt; out of range → error; typing → "Updating" while the
 * deferred value catches up.
 */
export function Quote() {
  const [product, setProduct] = useState<QuoteInput["product"]>("product");
  const [material, setMaterial] = useState<QuoteInput["material"]>("matte");
  const [sizeId, setSizeId] = useState<string>("3x3");
  const [custom, setCustom] = useState({ w: "", h: "" });
  const [qtyIndex, setQtyIndex] = useState(quantities.indexOf(500));
  const [artworkId, setArtworkId] = useState<(typeof quoteArtwork)[number]["id"]>("upload");
  const artwork = quoteArtwork.find((x) => x.id === artworkId) ?? quoteArtwork[0];
  const ids = { w: useId(), h: useId(), qty: useId(), sizeErr: useId() };

  const qty = quantities[qtyIndex];
  const preset = sizePresets.find((s) => s.id === sizeId);
  const w = preset ? preset.w : parseFloat(custom.w);
  const h = preset ? preset.h : parseFloat(custom.h);
  const error = sizeError(w, h);

  const input = useMemo<QuoteInput>(() => ({ product, material, w, h, qty }), [product, material, w, h, qty]);
  const deferred = useDeferredValue(input);
  const updating = deferred !== input;
  const result = useMemo(() => (sizeError(deferred.w, deferred.h) ? null : quote(deferred)), [deferred]);
  const customEmpty = sizeId === "custom" && (!custom.w || !custom.h);
  const ticket = [
    { k: "Product", v: productTypes.find((p) => p.id === product)?.label },
    { k: "Size", v: preset ? preset.label : `${custom.w || "–"} × ${custom.h || "–"}"` },
    { k: "Material", v: quoteMaterials.find((m) => m.id === material)?.label },
    { k: "Quantity", v: qtyLabel(qty) },
  ];

  return (
    <section id="quote" aria-labelledby="quote-title" className="relative page-x py-24 lg:py-36">
      <SectionHead
        id="quote-title"
        index={quoteCopy.index}
        eyebrow={quoteCopy.eyebrow}
        title={quoteCopy.title}
        lede={quoteCopy.caption}
        meta={SAMPLE_PRICING ? <span className="rounded-xs border border-signal-text px-2 py-1 text-signal-text">Sample pricing, not final</span> : undefined}
      />

      <div data-quote className="mt-14 grid grid-cols-12 overflow-hidden rounded-xs border border-ink/15 bg-sheet lg:mt-16">
        <form className="col-span-12 flex flex-col gap-9 p-5 sm:p-8 lg:col-span-7 lg:p-10" onSubmit={(e) => e.preventDefault()}>
          <ChipRadio name="product" legend="Product" options={productTypes} value={product} onChange={(v) => setProduct(v as QuoteInput["product"])} />

          <div data-quote-control>
            <ChipRadio name="size" legend="Size (inches)" options={sizeOptions} value={sizeId} onChange={setSizeId} />
            {sizeId === "custom" && (
              <div className="mt-4 flex flex-wrap items-end gap-3">
                {(["w", "h"] as const).map((k) => (
                  <div key={k}>
                    <label htmlFor={ids[k]} className="type-meta block">
                      {k === "w" ? "Width" : "Height"}
                    </label>
                    <div className="relative mt-1">
                      <input
                        id={ids[k]}
                        name={k === "w" ? "width" : "height"}
                        autoComplete="off"
                        inputMode="decimal"
                        type="number"
                        min={SIZE_MIN}
                        max={SIZE_MAX}
                        step="0.25"
                        value={custom[k]}
                        onChange={(e) => setCustom((c) => ({ ...c, [k]: e.target.value }))}
                        aria-invalid={Boolean(error) && !customEmpty}
                        aria-describedby={ids.sizeErr}
                        className="h-11 w-28 rounded-xs border border-ink/20 bg-white pl-4 pr-9 text-16 aria-[invalid=true]:border-signal-text"
                      />
                      <span className="type-meta pointer-events-none absolute right-3 top-1/2 -translate-y-1/2">in</span>
                    </div>
                  </div>
                ))}
                <p id={ids.sizeErr} className={cn("w-full text-14", customEmpty ? "text-ink-soft" : "text-signal-text")}>
                  {error ?? ""}
                </p>
              </div>
            )}
          </div>

          <div data-quote-control>
            <div className="flex items-baseline justify-between">
              <label htmlFor={ids.qty} className="type-meta">
                Quantity
              </label>
              <span className="type-display text-32">{qtyLabel(qty)}</span>
            </div>
            <input
              id={ids.qty}
              name="quantity"
              type="range"
              min={0}
              max={quantities.length - 1}
              step={1}
              value={qtyIndex}
              onChange={(e) => setQtyIndex(Number(e.target.value))}
              aria-valuetext={`${qtyLabel(qty)} labels`}
              className="qty-range mt-3 w-full"
            />
            <div aria-hidden="true" className="relative mt-1 h-6">
              {breaks.slice(1).map((b) => {
                const i = quantities.indexOf(b.qty);
                return (
                  <span
                    key={b.qty}
                    className="type-meta absolute -translate-x-1/2 before:mx-auto before:mb-1 before:block before:h-2 before:w-px before:bg-ink/30"
                    style={{ left: `calc(11px + (100% - 22px) * ${i / (quantities.length - 1)})` }}
                  >
                    {b.qty >= 1000 ? `${b.qty / 1000}k` : b.qty}
                  </span>
                );
              })}
            </div>
          </div>

          <ChipRadio name="material" legend="Material" options={quoteMaterials} value={material} onChange={(v) => setMaterial(v as QuoteInput["material"])} />

          {/* your art or ours: decides where the CTA goes; the design fee is never folded into the sample price */}
          <ChipRadio name="artwork" legend="Artwork" options={quoteArtwork} value={artworkId} onChange={(v) => setArtworkId(v as typeof artworkId)} />
        </form>

        <div className="col-span-12 flex flex-col bg-graphite p-6 text-paper sm:p-8 lg:col-span-5 lg:p-10">
          <p className="type-meta flex items-center justify-between text-steel">
            <span>Your price</span>
            <span>USD · excl. tax</span>
          </p>
          <div aria-live="polite" aria-busy={updating} className="mt-2 min-h-[8.5rem]">
            {result && !error ? (
              <div className={cn("transition-opacity duration-200", updating && "opacity-50")}>
                <div className="flex flex-wrap items-end justify-between gap-4">
                  <p data-price data-total={result.total} className="type-display max-w-full text-[clamp(3rem,5.4vw,5.5rem)] leading-[0.9]" style={{ fontSize: money(result.total, 2).length > 8 ? "clamp(2.4rem, 4.3vw, 4.5rem)" : undefined }}>
                    <span data-price-value>{money(result.total, 2)}</span><span data-price-count aria-hidden="true" hidden />
                  </p>
                  <SheetStack qty={qty} />
                </div>
                <p className="mt-4 text-15 text-steel">
                  <span className="text-paper">{money(result.unit, 2)}</span> per label · {qtyLabel(qty)} labels
                </p>
                {updating && <p className="type-meta mt-2 text-steel">Updating…</p>}
              </div>
            ) : (
              <p className="type-display text-32 leading-[1.05] text-steel">
                {customEmpty ? "Add a size to see your price." : "Pick a size between 0.5 and 12 inches."}
              </p>
            )}
          </div>

          {result && !error && result.next && (
            <p className="type-label mt-8 flex items-center gap-3 self-start border-l-2 border-signal pl-3 text-14 text-paper">
              Add {qtyLabel(result.next.add)} more, save {result.next.savePct}% each
            </p>
          )}

          <dl className="mt-8 border-t border-white/10">
            {ticket.map((t) => (
              <div key={t.k} className="flex items-baseline justify-between gap-4 border-b border-white/10 py-2.5">
                <dt className="type-meta text-steel">{t.k}</dt>
                <dd className="text-14 text-paper">{t.v}</dd>
              </div>
            ))}
          </dl>

          {artworkId === "design" && (
            <p className="mt-4 text-14 text-steel">+ Design fee [[DESIGN_FEE]], quoted separately</p>
          )}

          <div className="mt-auto pt-10">
            <ButtonLink href={artwork.href} variant="light" arrow className="w-full" aria-disabled={Boolean(error) || undefined} tabIndex={error ? -1 : 0} onClick={(e) => { if (error) e.preventDefault(); }}>
              {artwork.cta}
            </ButtonLink>
            <p className="type-meta mt-3 text-center text-steel">Free proof before anything prints</p>
          </div>
        </div>
      </div>
      <NearViewport><QuoteMotion /></NearViewport>
    </section>
  );
}
