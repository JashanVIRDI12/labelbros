import { trust } from "@/data/copy";

/** Client logos right under the hero. [[LOGOS]] stay visible placeholders until supplied. */
export function TrustBar() {
  return (
    <section aria-label="Clients" className="border-y border-line bg-paper page-x">
      <div className="flex flex-col gap-5 py-7 lg:flex-row lg:items-center lg:gap-12">
        <p className="type-meta shrink-0">{trust.label}</p>
        <ul className="grid flex-1 grid-cols-3 gap-x-6 gap-y-4 sm:grid-cols-6">
          {trust.logos.map((logo) => (
            <li key={logo} className="wordmark truncate text-13 text-ink-soft">
              {logo}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
