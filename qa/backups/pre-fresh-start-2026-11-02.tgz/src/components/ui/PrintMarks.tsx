import { cn } from "@/lib/utils";

/**
 * Print-trade marks: crop marks, registration targets and a colour control strip.
 * They're the site's ornament because they're the trade's own vocabulary.
 */

/**
 * Crop marks at the four trim corners of the parent box (parent must be positioned): each corner
 * gets a short horizontal and vertical line pointing outward, starting `gap` px from the trim.
 */
export function CropMarks({ className, gap = 8, length = 14 }: { className?: string; gap?: number; length?: number }) {
  const out = -(gap + length);
  const lines: React.CSSProperties[] = [
    // top-left
    { top: 0, left: out, width: length, height: 1 },
    { left: 0, top: out, width: 1, height: length },
    // top-right
    { top: 0, right: out, width: length, height: 1 },
    { right: 0, top: out, width: 1, height: length },
    // bottom-left
    { bottom: 0, left: out, width: length, height: 1 },
    { left: 0, bottom: out, width: 1, height: length },
    // bottom-right
    { bottom: 0, right: out, width: length, height: 1 },
    { right: 0, bottom: out, width: 1, height: length },
  ];
  return (
    <span aria-hidden="true" className={cn("pointer-events-none absolute inset-0 text-ink/40", className)}>
      {lines.map((style, i) => (
        <span key={i} className="absolute bg-current" style={style} />
      ))}
    </span>
  );
}

/** Registration target. */
export function RegMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={cn("size-5", className)} aria-hidden="true" focusable="false">
      <circle cx="12" cy="12" r="6" fill="none" stroke="currentColor" strokeWidth="1" />
      <circle cx="12" cy="12" r="2.5" fill="currentColor" />
      <path d="M12 0v24M0 12h24" stroke="currentColor" strokeWidth="1" />
    </svg>
  );
}

const process = ["var(--color-cyan)", "var(--color-magenta)", "var(--color-yellow)"];
const tints = {
  paper: ["var(--color-ink)", "rgb(14 15 16 / 0.7)", "rgb(14 15 16 / 0.45)", "rgb(14 15 16 / 0.22)", "rgb(14 15 16 / 0.1)"],
  dark: ["var(--color-paper)", "rgb(241 240 236 / 0.7)", "rgb(241 240 236 / 0.45)", "rgb(241 240 236 / 0.25)", "rgb(241 240 236 / 0.12)"],
};

/** Colour control strip, as printed along the edge of a press sheet: C, M, Y, then a tint ramp. */
export function ColorBar({ className, tone = "paper" }: { className?: string; tone?: "paper" | "dark" }) {
  return (
    <span aria-hidden="true" className={cn("flex gap-px", className)}>
      {[...process, ...tints[tone]].map((bg, i) => (
        <span key={i} className="block h-2.5 w-3.5" style={{ background: bg }} />
      ))}
    </span>
  );
}
