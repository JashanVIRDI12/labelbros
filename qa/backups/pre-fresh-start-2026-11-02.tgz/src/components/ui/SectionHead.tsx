import { cn } from "@/lib/utils";

type Props = {
  index: string;
  eyebrow: string;
  title: string;
  lede?: string;
  /** right-aligned note on the index rule */
  meta?: React.ReactNode;
  /** sits beside the title on wide screens, aligned to its baseline (a lede, a figure) */
  aside?: React.ReactNode;
  id?: string;
  className?: string;
  titleClassName?: string;
  tone?: "paper" | "dark";
};

/**
 * Section index rule (number · name · hairline) and the H2. Every section opens the same way,
 * like the numbered parts of a spec sheet.
 */
export function SectionHead({ index, eyebrow, title, lede, meta, aside, id, className, titleClassName, tone = "paper" }: Props) {
  const dark = tone === "dark";
  const heading = (
    <h2 id={id} className={cn("type-h2 max-w-[17ch]", dark && "text-paper", titleClassName)}>
      {title}
    </h2>
  );
  return (
    <div className={className}>
      <IndexRule index={index} label={eyebrow} meta={meta} tone={tone} />
      {aside ? (
        <div className="mt-8 grid gap-8 lg:mt-10 lg:grid-cols-12 lg:items-end lg:gap-6">
          <div className="lg:col-span-7">{heading}</div>
          <div className="lg:col-span-5 lg:col-start-8 lg:pb-[0.35em]">{aside}</div>
        </div>
      ) : (
        <div className="mt-8 lg:mt-10">{heading}</div>
      )}
      {lede && <p className={cn("type-lede mt-6 max-w-[44ch]", dark && "text-steel")}>{lede}</p>}
    </div>
  );
}

export function IndexRule({ index, label, meta, tone = "paper", className }: { index: string; label: string; meta?: React.ReactNode; tone?: "paper" | "dark"; className?: string }) {
  const dark = tone === "dark";
  return (
    <p className={cn("type-meta flex items-center gap-4", dark && "text-steel", className)}>
      <span className={cn(dark ? "text-signal" : "text-signal-text")}>{index}</span>
      <span className={dark ? "text-paper" : "text-ink"}>{label}</span>
      <span aria-hidden="true" className={cn("h-px min-w-8 flex-1", dark ? "bg-white/15" : "bg-line")} />
      {meta && <span>{meta}</span>}
    </p>
  );
}
