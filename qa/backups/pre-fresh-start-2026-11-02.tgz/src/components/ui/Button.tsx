import { cn } from "@/lib/utils";

type Variant = "primary" | "outline" | "light" | "outline-light";
type Size = "md" | "lg";

const variants: Record<Variant, { body: string; cell: string }> = {
  primary: { body: "bg-ink text-paper hover:bg-graphite-2", cell: "bg-signal text-ink" },
  outline: { body: "border border-ink/25 text-ink hover:border-ink hover:bg-ink/[0.03]", cell: "border-l border-ink/15 text-ink" },
  light: { body: "bg-paper text-ink hover:bg-white", cell: "bg-signal text-ink" },
  "outline-light": { body: "border border-white/25 text-paper hover:border-paper hover:bg-white/[0.04]", cell: "border-l border-white/20 text-paper" },
};

const sizes: Record<Size, { body: string; text: string; cell: string }> = {
  md: { body: "h-11 text-14", text: "px-4", cell: "w-11" },
  lg: { body: "h-14 text-15", text: "px-6", cell: "w-14" },
};

export function buttonClass(variant: Variant = "primary", size: Size = "lg", className?: string) {
  return cn(
    "type-label group inline-flex items-stretch justify-between overflow-hidden rounded-xs whitespace-nowrap select-none",
    "transition-colors duration-200 ease-out",
    variants[variant].body,
    sizes[size].body,
    className,
  );
}

export function Arrow({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={cn("size-[1.05em] shrink-0", className)} aria-hidden="true" focusable="false">
      <path d="M3 10h13M11 4.5 16.5 10 11 15.5" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
    </svg>
  );
}

type ButtonLinkProps = React.AnchorHTMLAttributes<HTMLAnchorElement> & {
  variant?: Variant;
  size?: Size;
  /** the signal-orange arrow tab: the primary action's mark */
  arrow?: boolean;
};

/** Square-cornered action link. The arrow sits in its own tab, which nudges on hover. */
export function ButtonLink({ variant = "primary", size = "lg", arrow, className, children, ...props }: ButtonLinkProps) {
  return (
    <a className={buttonClass(variant, size, className)} {...props}>
      <span className={cn("flex items-center", sizes[size].text)}>{children}</span>
      {arrow && (
        <span className={cn("flex shrink-0 items-center justify-center", sizes[size].cell, variants[variant].cell)}>
          <Arrow className="transition-transform duration-300 ease-out group-hover:translate-x-0.5" />
        </span>
      )}
    </a>
  );
}
