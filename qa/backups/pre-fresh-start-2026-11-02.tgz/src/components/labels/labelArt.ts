import type { StickerArt } from "@/components/stickers/art";
import { C } from "@/lib/palette";

/**
 * Specimen labels for the four industries. They depict customers' labels, so they carry their
 * own (fictional) brands and real-world safety colours; the site's UI tokens don't apply inside.
 * Display text uses the embedded label face (Anton); `class="s"` text uses the page sans.
 * DOM only (not used as WebGL textures).
 */

const A = `font-family="Anton"`;

/** Deterministic pseudo-random sequence so barcodes and codes render the same on server and client. */
function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

/** Linear barcode: bars in [x, x+w] × [y, y+h]. */
export function barcode(x: number, y: number, w: number, h: number, seed = 7, fill: string = C.ink) {
  const r = rng(seed);
  const units: number[] = [];
  let total = 0;
  while (total < 96) {
    const u = 1 + Math.floor(r() * 3);
    units.push(u);
    total += u;
  }
  const k = w / total;
  let cx = x;
  let out = "";
  units.forEach((u, i) => {
    if (i % 2 === 0) out += `<rect x="${cx.toFixed(2)}" y="${y}" width="${(u * k).toFixed(2)}" height="${h}" fill="${fill}"/>`;
    cx += u * k;
  });
  return out;
}

/** 2D data-matrix-style code: solid L finder, clocked top/right edges, seeded data. */
export function dataMatrix(x: number, y: number, size: number, n = 14, seed = 11, fill: string = C.ink) {
  const r = rng(seed);
  const m = size / n;
  let out = "";
  for (let row = 0; row < n; row++) {
    for (let col = 0; col < n; col++) {
      const left = col === 0;
      const bottom = row === n - 1;
      const top = row === 0;
      const right = col === n - 1;
      const on = left || bottom || (top && col % 2 === 0) || (right && row % 2 === 1) || (!top && !right && r() > 0.52);
      if (on) out += `<rect x="${(x + col * m).toFixed(2)}" y="${(y + row * m).toFixed(2)}" width="${m.toFixed(2)}" height="${m.toFixed(2)}" fill="${fill}"/>`;
    }
  }
  return out;
}

/** Grey text rules standing in for small print. */
function rules(x: number, y: number, widths: number[], gap = 9, h = 3.2, fill = "rgba(14,15,16,0.42)") {
  return widths.map((w, i) => `<rect x="${x}" y="${y + i * gap}" width="${w}" height="${h}" fill="${fill}"/>`).join("");
}

// ---------------------------------------------------------------- food & beverage (120 × 50 mm)
export const foodLabel: StickerArt = {
  id: "spec-food",
  label: "Northfield Pantry smoked chili oil product label",
  w: 480,
  h: 200,
  svg: `
  <rect x="1" y="1" width="478" height="198" rx="10" fill="${C.cream}"/>
  <rect x="12" y="12" width="456" height="176" rx="5" fill="none" stroke="${C.ink}" stroke-width="1.2"/>
  <text class="s" x="30" y="42" font-size="10.5" font-weight="650" letter-spacing="2.4" fill="${C.ink}">NORTHFIELD PANTRY</text>
  <rect x="30" y="50" width="26" height="2" fill="#B3261E"/>
  <text ${A} x="28" y="106" font-size="50" letter-spacing="0.5" fill="${C.ink}">SMOKED</text>
  <text ${A} x="28" y="156" font-size="50" letter-spacing="0.5" fill="#B3261E">CHILI OIL</text>
  <text class="s" x="30" y="177" font-size="9" font-weight="500" letter-spacing="1.2" fill="${C.ink}">SMALL BATCH  ·  NET 8 FL OZ (237 mL)</text>
  <line x1="300" y1="24" x2="300" y2="176" stroke="${C.ink}" stroke-width="1"/>
  <text class="s" x="314" y="40" font-size="12" font-weight="800" fill="${C.ink}">Nutrition Facts</text>
  <rect x="314" y="45" width="140" height="4" fill="${C.ink}"/>
  <text class="s" x="314" y="61" font-size="8" font-weight="500" fill="${C.ink}">Serving size 1 tbsp (15 mL)</text>
  <rect x="314" y="66" width="140" height="2" fill="${C.ink}"/>
  <text class="s" x="314" y="81" font-size="10" font-weight="800" fill="${C.ink}">Calories</text>
  <text class="s" x="454" y="81" font-size="10" font-weight="800" fill="${C.ink}" text-anchor="end">120</text>
  <rect x="314" y="86" width="140" height="1" fill="${C.ink}"/>
  ${rules(314, 93, [118, 96, 128, 84], 8.5, 2.6)}
  ${barcode(318, 136, 112, 30, 3)}
  <text class="s" x="374" y="177" font-size="7" font-weight="500" letter-spacing="1.4" fill="${C.ink}" text-anchor="middle">0 84522 10734 6</text>`,
};

// ---------------------------------------------------------------- defense ID plate (76 × 38 mm)
const brushed = Array.from({ length: 24 }, (_, i) => `<rect x="2" y="${44 + i * 6.4}" width="396" height="1" fill="${i % 2 ? "#ffffff" : "#000000"}" opacity="${i % 3 ? 0.05 : 0.08}"/>`).join("");

export const defenseLabel: StickerArt = {
  id: "spec-defense",
  label: "Metallised polyester equipment ID plate with serial number and 2D code",
  w: 400,
  h: 200,
  svg: `
  <rect x="1" y="1" width="398" height="198" rx="9" fill="${C.silver}"/>
  ${brushed}
  <path d="M1 10a9 9 0 0 1 9-9h380a9 9 0 0 1 9 9v32H1z" fill="${C.ink}"/>
  <text ${A} x="18" y="31" font-size="21" letter-spacing="2.2" fill="${C.silver}">EQUIPMENT ID</text>
  <rect x="318" y="11" width="64" height="20" rx="2" fill="none" stroke="${C.silver}" stroke-width="1.2"/>
  <text class="s" x="350" y="25" font-size="9.5" font-weight="700" letter-spacing="1.6" fill="${C.silver}" text-anchor="middle">UID</text>
  <text class="s" x="18" y="66" font-size="8.5" font-weight="700" letter-spacing="1.8" fill="${C.ink}">PART NO.</text>
  <text ${A} x="17" y="93" font-size="24" letter-spacing="0.6" fill="${C.ink}">LB-4471-02A</text>
  <text class="s" x="18" y="118" font-size="8.5" font-weight="700" letter-spacing="1.8" fill="${C.ink}">SERIAL</text>
  <text ${A} x="17" y="145" font-size="24" letter-spacing="0.6" fill="${C.ink}">SN 0001274</text>
  <line x1="18" y1="160" x2="246" y2="160" stroke="${C.ink}" stroke-width="1"/>
  <text class="s" x="18" y="178" font-size="8.5" font-weight="600" letter-spacing="1.2" fill="${C.ink}">LOT 0426-B   ·   REV C   ·   2026-03</text>
  <rect x="262" y="52" width="122" height="122" fill="${C.white}" opacity="0.55"/>
  ${dataMatrix(267, 57, 112, 16, 21)}
  <text class="s" x="323" y="189" font-size="7.5" font-weight="700" letter-spacing="1.6" fill="${C.ink}" text-anchor="middle">2D · ECC 200</text>`,
};

// ---------------------------------------------------------------- automotive warning (90 × 55 mm)
export const autoLabel: StickerArt = {
  id: "spec-auto",
  label: "Automotive under-hood warning label: hot coolant, system under pressure",
  w: 360,
  h: 220,
  svg: `
  <rect x="1" y="1" width="358" height="218" rx="7" fill="${C.white}"/>
  <path d="M1 8a7 7 0 0 1 7-7h344a7 7 0 0 1 7 7v48H1z" fill="${C.signal}"/>
  <path d="M38 12 60 48H16z" fill="${C.ink}"/>
  <rect x="36" y="23" width="4" height="13" fill="${C.signal}"/>
  <rect x="36" y="39" width="4" height="4" fill="${C.signal}"/>
  <text ${A} x="72" y="44" font-size="34" letter-spacing="2" fill="${C.ink}">WARNING</text>
  <rect x="14" y="68" width="100" height="100" rx="3" fill="none" stroke="${C.ink}" stroke-width="2"/>
  <circle cx="64" cy="136" r="22" fill="none" stroke="${C.ink}" stroke-width="5"/>
  <circle cx="64" cy="136" r="7" fill="${C.ink}"/>
  <path d="M48 104c-6-6 6-10 0-16M64 104c-6-6 6-10 0-16M80 104c-6-6 6-10 0-16" fill="none" stroke="${C.ink}" stroke-width="3" stroke-linecap="round"/>
  <text ${A} x="130" y="92" font-size="25" letter-spacing="0.8" fill="${C.ink}">HOT COOLANT</text>
  <text class="s" x="131" y="114" font-size="11.5" font-weight="600" fill="${C.ink}">Never open when engine is hot.</text>
  <text class="s" x="131" y="131" font-size="11.5" font-weight="500" fill="${C.ink}">System is under pressure.</text>
  ${rules(131, 145, [190, 150], 9, 3)}
  <line x1="14" y1="182" x2="346" y2="182" stroke="${C.ink}" stroke-width="1"/>
  <text class="s" x="14" y="204" font-size="9" font-weight="700" letter-spacing="1.4" fill="${C.ink}">PART 21710-44A</text>
  ${barcode(200, 190, 146, 20, 9)}`,
};

// ---------------------------------------------------------------- industrial GHS (100 × 100 mm)
const diamond = (cx: number, cy: number, r: number) =>
  `<path d="M${cx} ${cy - r}L${cx + r} ${cy}L${cx} ${cy + r}L${cx - r} ${cy}Z" fill="${C.white}" stroke="${C.hazard}" stroke-width="5" stroke-linejoin="miter"/>`;

const flameGlyph = (cx: number, cy: number) =>
  `<path transform="translate(${cx - 11.2} ${cy - 19}) scale(0.14)" d="M84 10C92 40 124 58 138 92C152 124 150 158 128 178C114 190 98 194 80 194C58 194 34 186 22 164C8 138 14 108 30 88C34 104 42 114 54 116C46 82 58 40 84 10Z" fill="${C.ink}"/><rect x="${cx - 14}" y="${cy + 12}" width="28" height="3" fill="${C.ink}"/>`;

const bangGlyph = (cx: number, cy: number) =>
  `<rect x="${cx - 3.5}" y="${cy - 17}" width="7" height="22" rx="1" fill="${C.ink}"/><rect x="${cx - 3.5}" y="${cy + 9}" width="7" height="7" rx="1" fill="${C.ink}"/>`;

export const industrialLabel: StickerArt = {
  id: "spec-industrial",
  label: "GHS hazard label for an industrial degreaser with flame and exclamation pictograms",
  w: 300,
  h: 300,
  svg: `
  <rect x="1" y="1" width="298" height="298" rx="6" fill="${C.white}"/>
  <rect x="10" y="10" width="280" height="280" rx="3" fill="none" stroke="${C.ink}" stroke-width="1.2"/>
  <text ${A} x="22" y="52" font-size="32" letter-spacing="0.6" fill="${C.ink}">DEGREASER XR-7</text>
  <text class="s" x="23" y="71" font-size="10" font-weight="500" fill="${C.ink}">Industrial solvent cleaner  ·  20 L</text>
  <line x1="22" y1="84" x2="278" y2="84" stroke="${C.ink}" stroke-width="1"/>
  ${diamond(56, 132, 34)}${flameGlyph(56, 132)}
  ${diamond(128, 132, 34)}${bangGlyph(128, 132)}
  <text ${A} x="176" y="114" font-size="25" letter-spacing="1.6" fill="${C.ink}">DANGER</text>
  ${rules(177, 126, [100, 86, 96, 70], 9, 3)}
  <line x1="22" y1="182" x2="278" y2="182" stroke="${C.ink}" stroke-width="1"/>
  <text class="s" x="23" y="200" font-size="9" font-weight="700" letter-spacing="1.4" fill="${C.ink}">PRECAUTIONARY STATEMENTS</text>
  ${rules(23, 210, [250, 230, 244, 180], 9, 3)}
  <text class="s" x="23" y="272" font-size="8.5" font-weight="600" fill="${C.ink}">Northfield Chemical Co.</text>
  ${barcode(190, 258, 88, 20, 15)}`,
};

export const industryLabels = {
  food: foodLabel,
  defense: defenseLabel,
  auto: autoLabel,
  industrial: industrialLabel,
} as const;
