import type { Metadata, Viewport } from "next";
import { Mona_Sans } from "next/font/google";
import Script from "next/script";
import { Footer } from "@/components/layout/Footer";
import { Header } from "@/components/layout/Header";
import { PaperGuides } from "@/components/layout/PageFrame";
import { SmoothScroll } from "@/components/layout/SmoothScroll";
import { CanvasRoot } from "@/components/three/CanvasRoot";
import { brand } from "@/data/copy";
import { reduceMotionBootScript } from "@/lib/motion";
import "./globals.css";

// One variable family for display, UI and body: Mona Sans (wdth 75–125, wght 200–900).
const mona = Mona_Sans({
  subsets: ["latin"],
  variable: "--font-mona",
  display: "swap",
  axes: ["wdth"],
  preload: true,
  fallback: ["Helvetica Neue", "Arial", "sans-serif"],
});

export const metadata: Metadata = {
  // [[DOMAIN]]: add metadataBase + canonical once the domain is known
  title: brand.title,
  description: brand.description,
  openGraph: {
    title: brand.title,
    description: brand.description,
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#F1F0EC",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={mona.variable} suppressHydrationWarning>
      <head>
        <Script id="reduce-motion-boot" strategy="beforeInteractive">
          {reduceMotionBootScript}
        </Script>
      </head>
      <body>
        <a
          href="#main"
          className="type-label sr-only fixed left-4 top-4 z-[60] rounded-xs bg-ink px-5 py-3 text-14 text-paper focus:not-sr-only"
        >
          Skip to content
        </a>
        <Header />
        <main id="main" className="relative z-[1] overflow-x-clip bg-paper" style={{ clipPath: "inset(0)" }}>
          <PaperGuides />
          {children}
        </main>
        <span data-footer-start aria-hidden="true" className="block h-px" />
        <Footer />
        <aside aria-label="Label illustrations"><CanvasRoot /></aside>
        <SmoothScroll />
      </body>
    </html>
  );
}
