import { DesignChoice } from "@/components/sections/DesignChoice";
import { FinalCta } from "@/components/sections/FinalCta";
import { Hero } from "@/components/sections/Hero";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { Industries } from "@/components/sections/Industries";
import { Materials } from "@/components/sections/Materials";
import { Products } from "@/components/sections/Products";
import { Quote } from "@/components/sections/Quote";
import { Reviews } from "@/components/sections/Reviews";
import { SamplePack } from "@/components/sections/SamplePack";
import { TrustBar } from "@/components/sections/TrustBar";
import { Wrap } from "@/components/sections/Wrap";

export default function Home() {
  return (
    <>
      <Hero />
      <TrustBar />
      <Industries />
      <DesignChoice />
      <HowItWorks />
      <Wrap />
      <Products />
      <Quote />
      <Materials />
      <Reviews />
      <SamplePack />
      <FinalCta />
    </>
  );
}
