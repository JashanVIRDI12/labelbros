/** Footer links. Routes other than in-page anchors are placeholders until those pages exist. [[LINKS]] */
export const footerColumns = [
  {
    title: "Industries",
    links: [
      { label: "Food & beverage", href: "#industries" },
      { label: "Defense & government", href: "#industries" },
      { label: "Automotive & parts", href: "#industries" },
      { label: "Industrial & chemical", href: "#industries" },
    ],
  },
  {
    title: "Products",
    links: [
      { label: "Roll labels", href: "#products" },
      { label: "Product labels", href: "#products" },
      { label: "Asset & ID tags", href: "#products" },
      { label: "Warning & safety", href: "#products" },
      { label: "Tamper-evident", href: "#products" },
    ],
  },
  {
    title: "Materials",
    links: [
      { label: "Paper & BOPP", href: "#materials" },
      { label: "Vinyl & PET", href: "#materials" },
      { label: "Holographic security", href: "#materials" },
      { label: "Sample kit", href: "#samples" },
    ],
  },
  {
    title: "Help",
    links: [
      { label: "Artwork guidelines", href: "/artwork-guidelines" },
      { label: "Upload artwork", href: "/upload" },
      { label: "Shipping", href: "/shipping" },
      { label: "FAQ", href: "/faq" },
      { label: "Contact", href: "mailto:[[EMAIL]]" },
    ],
  },
] as const;

export const socials = [
  { label: "LinkedIn", href: "[[LINKEDIN_URL]]" },
  { label: "Instagram", href: "[[INSTAGRAM_URL]]" },
] as const;

export const company = {
  email: "[[EMAIL]]",
  hours: "[[HOURS]]",
  address: "[[COMPANY_ADDRESS]]",
  certifications: "[[CERTIFICATIONS]]",
};
