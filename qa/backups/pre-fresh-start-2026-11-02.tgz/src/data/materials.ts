/**
 * S6 materials. [[MATERIALS]]: names, best-for lines and durability flags are placeholders
 * to confirm with the client ([[MATERIAL_SPECS]]). `pbr` drives the 3D finish morph;
 * `swatch` is the 2D fallback (gradients are allowed here because they depict the film).
 */
export type Durability = "waterproof" | "uv" | "scratch" | "removable" | "chemical" | "heat";

export type Material = {
  id: string;
  name: string;
  bestFor: string;
  durability: Durability[];
  /** page tint while this film is on stage */
  tint: string;
  pbr: {
    color: string;
    roughness: number;
    metalness: number;
    clearcoat: number;
    iridescence: number;
    /** 0 = opaque film, 1 = clear film (ink stays opaque) */
    clear: number;
    glitter: number;
    kraft: number;
  };
  swatch: string;
};

const KRAFT = "#C9A47C"; // material depiction only, not a UI token

export const materials: Material[] = [
  {
    id: "paper",
    name: "Matte paper",
    bestFor: "Dry goods, cartons and shipping", // COPY:
    durability: ["scratch"],
    tint: "#F1F0EC",
    pbr: { color: "#FFFFFF", roughness: 0.9, metalness: 0, clearcoat: 0, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "#FFFFFF",
  },
  {
    id: "bopp",
    name: "Gloss BOPP",
    bestFor: "Food and drink, chilled and wet", // COPY:
    durability: ["waterproof", "scratch"],
    tint: "#F2F1EB",
    pbr: { color: "#FFFFFF", roughness: 0.22, metalness: 0, clearcoat: 1, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "linear-gradient(135deg, #ffffff 0%, #ffffff 42%, #e6e5e1 50%, #ffffff 58%, #ffffff 100%)",
  },
  {
    id: "clear",
    name: "Clear BOPP",
    bestFor: "Glass and PET bottles: only the ink shows", // COPY:
    durability: ["waterproof", "uv"],
    tint: "#E9EDEE",
    pbr: { color: "#FFFFFF", roughness: 0.15, metalness: 0, clearcoat: 1, iridescence: 0, clear: 1, glitter: 0, kraft: 0 },
    swatch: "repeating-conic-gradient(#dcdad4 0% 25%, #f1f0ec 0% 50%) 50% / 12px 12px",
  },
  {
    id: "vinyl",
    name: "White vinyl",
    bestFor: "Outdoor equipment and curved surfaces", // COPY:
    durability: ["waterproof", "uv", "chemical"],
    tint: "#EEEEEB",
    pbr: { color: "#FFFFFF", roughness: 0.45, metalness: 0, clearcoat: 0.5, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "linear-gradient(160deg, #ffffff 0%, #f4f4f2 60%, #ebebe8 100%)",
  },
  {
    id: "pet",
    name: "Metallised PET",
    bestFor: "Nameplates, asset tags, electronics", // COPY:
    durability: ["waterproof", "chemical", "heat"],
    tint: "#E8E9EA",
    pbr: { color: "#D6D8DA", roughness: 0.14, metalness: 1, clearcoat: 1, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "linear-gradient(160deg, #5b5d61 0%, #ffffff 30%, #9a9da2 52%, #ffffff 70%, #5b5d61 100%)",
  },
  {
    id: "holo",
    name: "Holographic security",
    bestFor: "Brand protection and tamper evidence", // COPY:
    durability: ["waterproof", "scratch"],
    tint: "#ECEAF0",
    pbr: { color: "#E9E9F2", roughness: 0.2, metalness: 0.9, clearcoat: 1, iridescence: 1, clear: 0, glitter: 0, kraft: 0 },
    swatch: "conic-gradient(from 210deg, #c9d6ff, #ffe7b3, #ffffff, #b9f0e4, #f4c6ff, #ffffff, #c9d6ff)",
  },
  {
    id: "kraft",
    name: "Kraft paper",
    bestFor: "Natural and artisan food", // COPY:
    durability: [],
    tint: "#EFE7DA",
    pbr: { color: KRAFT, roughness: 0.95, metalness: 0, clearcoat: 0, iridescence: 0, clear: 0, glitter: 0, kraft: 1 },
    swatch: `radial-gradient(circle at 20% 30%, rgb(0 0 0 / 0.06) 0 1px, transparent 2px) 0 0 / 7px 7px, ${KRAFT}`,
  },
  {
    id: "removable",
    name: "Removable film",
    bestFor: "Temporary marking, no residue", // COPY:
    durability: ["removable", "waterproof"],
    tint: "#ECEEEA",
    pbr: { color: "#FFFFFF", roughness: 0.7, metalness: 0, clearcoat: 0.2, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "#FFFFFF",
  },
];

export const durabilityLabel: Record<Durability, string> = {
  waterproof: "Waterproof",
  uv: "UV resistant",
  scratch: "Scuff resistant",
  removable: "Removable",
  chemical: "Chemical resistant",
  heat: "Heat resistant",
};
