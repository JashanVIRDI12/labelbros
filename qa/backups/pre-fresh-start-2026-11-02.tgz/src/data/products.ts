/** S5 products. [[PRODUCTS]] and [[PRICE]] are placeholders until the client confirms the range. */
export type Product = {
  id: string;
  name: string;
  line: string;
  /** typical films, for scanning */
  films: string;
  price: string;
  href: string;
};

export const products: Product[] = [
  { id: "roll", name: "Roll labels", line: "Wound to your core size and direction, for hand or automatic applicators.", films: "Paper · BOPP · PET", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "product", name: "Product labels", line: "Bottles, jars, tins and tubs. The label that sells the thing.", films: "BOPP · Paper · Clear", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "asset", name: "Asset & ID tags", line: "Metallised polyester tags with serial numbers and 2D codes.", films: "Metallised PET", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "warning", name: "Warning & safety", line: "Signal-word panels and pictograms that stay legible on the job.", films: "Vinyl · PET", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "variable", name: "Variable data", line: "Sequential serials, barcodes and QR codes, different on every label.", films: "Paper · PET", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "tamper", name: "Tamper-evident", line: "VOID-pattern and destructible films that show if they've been lifted.", films: "Void PET · Destructible vinyl", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "clear", name: "Clear labels", line: "The no-label look on glass and PET: only your ink shows.", films: "Clear BOPP · Clear PET", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "decal", name: "Die-cut decals", line: "Cut to any outline, for equipment, vehicles and merch.", films: "Vinyl · Reflective", price: "[[PRICE]]", href: "#quote" }, // COPY:
];
