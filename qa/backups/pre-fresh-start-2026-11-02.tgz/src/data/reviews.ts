import type { IndustryId } from "@/data/copy";

/** S8 social proof. Every quote, name, company and logo is a visible placeholder until [[REVIEWS]] / [[LOGOS]] arrive. */
export type Review = { quote: string; name: string; role: string; company: string; industry: IndustryId };

const short = "Placeholder: a short customer quote about the labels holding up.";
const mid = "Placeholder: a customer quote about the print quality, the free proof and how the labels performed in use.";
const long = "Placeholder: a longer customer quote about the spec conversation, the proof, the turnaround and how the labels held up on the line.";

export const reviews: Review[] = [
  { quote: long, name: "[[NAME]]", role: "[[ROLE]]", company: "[[COMPANY]]", industry: "food" },
  { quote: mid, name: "[[NAME]]", role: "[[ROLE]]", company: "[[COMPANY]]", industry: "defense" },
  { quote: short, name: "[[NAME]]", role: "[[ROLE]]", company: "[[COMPANY]]", industry: "auto" },
  { quote: mid, name: "[[NAME]]", role: "[[ROLE]]", company: "[[COMPANY]]", industry: "industrial" },
  { quote: short, name: "[[NAME]]", role: "[[ROLE]]", company: "[[COMPANY]]", industry: "food" },
  { quote: mid, name: "[[NAME]]", role: "[[ROLE]]", company: "[[COMPANY]]", industry: "auto" },
];

export const rating = { value: "[[RATING]]", count: "[[REVIEW_COUNT]]" };

export const logos = Array.from({ length: 8 }, (_, i) => `[[LOGO_${String(i + 1).padStart(2, "0")}]]`);

export const caseStudies: { company: string; industry: IndustryId; title: string; body: string }[] = [
  {
    company: "[[CASE_STUDY_1]]",
    industry: "food",
    title: "Placeholder: what they make and what we printed", // COPY:
    body: "Placeholder: two lines on the problem, the label we specified and what changed on the line. Real numbers only.",
  },
  {
    company: "[[CASE_STUDY_2]]",
    industry: "defense",
    title: "Placeholder: a second customer story", // COPY:
    body: "Placeholder: two lines on the requirement, the label we specified and how it performed. Real numbers only.",
  },
];
