/**
 * Site copy. Anything in [[DOUBLE_BRACKETS]] is a placeholder that must stay visible
 * until the client supplies it. Lines marked COPY: are placeholder voice copy.
 * Voice: a precise print house for B2B buyers. Plain, specific, confident. No hype, no claims
 * we can't back (certifications, specs and numbers stay as placeholders).
 */

export const brand = {
  name: "Label Bros",
  // [[LOGO_SVG]]: typeset wordmark until the logo arrives
  wordmark: "Label Bros",
  title: "Label Bros: custom labels for food, defense, automotive and industry", // COPY:
  // [[ONE_LINE_DESCRIPTION]]
  description:
    "Custom product, compliance and durable ID labels for food producers, defense suppliers, automotive parts makers and industrial teams. Send your artwork or let our designers build it. Get instant pricing or order a sample kit.", // COPY:
};

export const nav = [
  { label: "Industries", href: "#industries" },
  { label: "Artwork", href: "#design" },
  { label: "Products", href: "#products" },
  { label: "Materials", href: "#materials" },
  { label: "Process", href: "#how" },
  { label: "Samples", href: "#samples" },
] as const;

export const cta = {
  primary: { label: "Get instant pricing", href: "#quote" },
  secondary: { label: "Order a sample kit", href: "#samples" },
  quote: { label: "Get a quote", href: "#quote" },
  specialist: { label: "Talk to a specialist", href: "mailto:[[EMAIL]]" },
};

export const hero = {
  eyebrow: "Custom labels for food, defense, automotive & industry", // COPY:
  // [[HERO_HEADLINE]] default
  lines: ["Labels built", "to spec."] as const, // COPY:
  lede: "Product, compliance and durable ID labels, matched to the surface, the environment and the paperwork. Send your artwork, or our designers will build it with you.", // COPY:
  paths: [
    { k: "Have artwork?", v: "Upload your file", href: "/upload" },
    { k: "Need artwork?", v: "We'll design it", href: "[[DESIGN_BRIEF_URL]]" },
  ],
  facts: [
    { k: "Proof", v: "Free, in [[PROOF_TIME]]" },
    { k: "Turnaround", v: "[[TURNAROUND]]" },
    { k: "Rated", v: "[[RATING]] / [[REVIEW_COUNT]] reviews" },
  ],
};

/** Hero specimen + industries section share these. Label art lives in components/labels. */
export type IndustryId = "food" | "defense" | "auto" | "industrial";

export const industries: {
  id: IndustryId;
  name: string;
  short: string;
  line: string;
  types: string[];
  spec: { k: string; v: string }[];
  size: { w: string; h: string };
}[] = [
  {
    id: "food",
    name: "Food & beverage",
    short: "Food & bev",
    line: "Shelf-ready product labels that stay put through the chiller, the freezer and the wash-down.", // COPY:
    types: ["Product labels", "Roll labels for applicators", "Nutrition & date panels", "Clear no-label look"], // COPY:
    spec: [
      { k: "Material", v: "White BOPP" },
      { k: "Adhesive", v: "Freezer-grade" },
      { k: "Finish", v: "Matte laminate" },
      { k: "Supplied", v: "Rolls, 3\" core" },
    ], // COPY:
    size: { w: "120 mm", h: "50 mm" },
  },
  {
    id: "defense",
    name: "Defense & government",
    short: "Defense",
    line: "Durable ID plates, asset tags and serialised labels for parts that see real conditions.", // COPY:
    types: ["Asset & ID tags", "Serialised nameplates", "2D data matrix", "[[MIL_SPEC_SUPPORT]]"], // COPY:
    spec: [
      { k: "Material", v: "Metallised PET" },
      { k: "Print", v: "Thermal transfer" },
      { k: "Data", v: "Serial + 2D code" },
      { k: "Spec", v: "[[MIL_SPEC_SUPPORT]]" },
    ], // COPY:
    size: { w: "76 mm", h: "38 mm" },
  },
  {
    id: "auto",
    name: "Automotive & parts",
    short: "Automotive",
    line: "Part ID, warning and under-hood labels, with the film and laminate matched to where the part lives.", // COPY:
    types: ["Warning & caution labels", "Part ID & barcodes", "Under-hood labels", "Aftermarket packaging"], // COPY:
    spec: [
      { k: "Material", v: "White polyester" },
      { k: "Laminate", v: "Chemical-resistant" },
      { k: "Temp range", v: "[[TEMP_RANGE]]" },
      { k: "Barcode", v: "Code 128, graded" },
    ], // COPY:
    size: { w: "90 mm", h: "55 mm" },
  },
  {
    id: "industrial",
    name: "Industrial & chemical",
    short: "Industrial",
    line: "GHS, safety and equipment labels on films chosen for the chemicals and weather they meet.", // COPY:
    types: ["GHS & hazard labels", "Equipment & safety signs", "Drum & tote labels", "[[COMPLIANCE_STANDARD]]"], // COPY:
    spec: [
      { k: "Material", v: "White vinyl" },
      { k: "Adhesive", v: "High-tack" },
      { k: "Exposure", v: "[[OUTDOOR_RATING]]" },
      { k: "Standard", v: "[[COMPLIANCE_STANDARD]]" },
    ], // COPY:
    size: { w: "100 mm", h: "100 mm" },
  },
];

export const industriesCopy = {
  index: "01",
  eyebrow: "Industries",
  title: "Built for the line, the field and the road.", // COPY:
  lede: "Every industry breaks labels differently. We spec the film, adhesive and finish for where yours will live, and print to the standard your buyer asks for.", // COPY:
  also: "Also printing for cosmetics, supplements, craft drinks and retail.", // COPY:
};

export const trust = {
  label: "Printing for teams at", // COPY:
  // [[LOGOS]]
  logos: Array.from({ length: 6 }, (_, i) => `[[LOGO_${String(i + 1).padStart(2, "0")}]]`),
};

/** Two ways in: send your own artwork, or have a Label Bros designer build it. */
export const designChoice = {
  index: "02",
  eyebrow: "Artwork",
  title: "Your artwork, or ours.", // COPY:
  lede: "Bring a print-ready file or bring a brief. Both roads end at the same place: a proof you approve before anything prints.", // COPY:
  join: "Proof approved. Then we print.", // COPY:
  joinNote: "Free proof in [[PROOF_TIME]], either way", // COPY:
  paths: [
    {
      id: "upload",
      kicker: "Path A",
      name: "Send your artwork",
      line: "Upload a print-ready file. Prepress checks bleed, die lines, barcodes and small type, then sends a proof.", // COPY:
      points: [
        { k: "Files", v: "PDF, AI, EPS, SVG" }, // COPY:
        { k: "File check", v: "[[PREFLIGHT_TERMS]]" },
        { k: "Proof", v: "In [[PROOF_TIME]]" },
      ],
      cta: { label: "Upload artwork", href: "/upload" },
    },
    {
      id: "design",
      kicker: "Path B",
      name: "We design it",
      line: "Share your brand, product data and compliance copy. A Label Bros designer lays it out and sends v1 for review.", // COPY:
      points: [
        { k: "Design fee", v: "[[DESIGN_FEE]]" },
        { k: "First draft", v: "In [[DESIGN_TURNAROUND]]" },
        { k: "Revisions", v: "[[DESIGN_REVISIONS]] rounds" },
      ],
      cta: { label: "Start a design brief", href: "[[DESIGN_BRIEF_URL]]" },
    },
  ],
};

// [[STEP_COPY]]: placeholder voice copy for the four steps
export const how = {
  index: "03",
  eyebrow: "Process",
  title: "From spec to shipped, in four steps.", // COPY:
  steps: [
    {
      n: "01",
      title: "Spec",
      line: "Pick the label type, material, size and quantity. The price updates as you go.", // COPY:
      caption: "Instant pricing, no sales call", // COPY:
    },
    {
      n: "02",
      title: "Proof",
      line: "A prepress specialist checks your file, or our designer builds it, and sends a proof.", // COPY:
      caption: "Free proof in [[PROOF_TIME]]",
    },
    {
      n: "03",
      title: "Print",
      line: "Printed in-house on the film you chose, colour-matched to the approved proof.", // COPY:
      caption: "[[PRINT_SPEC]]",
    },
    {
      n: "04",
      title: "Ship",
      line: "Cut, inspected and packed on rolls, sheets or fan-fold, ready for your line.", // COPY:
      caption: "Ships in [[TURNAROUND]]",
    },
  ],
};

export const wrap = {
  index: "04",
  eyebrow: "Application",
  // [[WRAP_HEADLINE]] default
  lines: ["Flat on the proof.", "Flawless on", "the pack."] as const, // COPY:
  lede: "Labels are cut and laminated to conform to curves, so they go on smooth and stay that way.", // COPY:
  proof: ["Waterproof films", "Scuff-resistant laminate", "[[CLAIM]]"], // COPY:
  finishes: ["Matte", "Gloss", "Holographic", "Metallised", "Clear"] as const,
};

export const productsCopy = {
  index: "05",
  eyebrow: "Products",
  title: "Pick the label. We match the spec.", // COPY:
  lede: "Eight label types from one press room, each available on the films that suit it.", // COPY:
};

export const materialsCopy = {
  index: "07",
  eyebrow: "Materials",
  title: "Eight films, matched to the job.", // COPY:
  caption: "Scroll to change the material", // COPY:
};

export const quoteCopy = {
  index: "06",
  eyebrow: "Instant quote",
  title: "Price it in seconds.", // COPY:
  caption: "No email, no call, no waiting", // COPY:
};

export const reviewsCopy = {
  index: "08",
  eyebrow: "Customers",
  title: "Trusted on the line.", // COPY:
};

export const sample = {
  index: "09",
  eyebrow: "Sample kit",
  title: "Test the film before you commit.", // COPY:
  lede: "Every material and finish we print, on real labels, so you can put them through your own fridge, engine bay or wash-down test.", // COPY:
  price: "[[SAMPLE_PRICE]]",
  points: [
    { title: "Every material", caption: "All eight films and finishes" }, // COPY:
    { title: "Proof first", caption: "On every single order" }, // COPY:
    { title: "Reprint guarantee", caption: "[[GUARANTEE_TERMS]]" },
  ],
  code: "[[CODE]]",
  peelHint: "Peel the seal for your code", // COPY:
};

export const finalCta = {
  // [[CTA_HEADLINE]] default
  lines: ["Send the spec.", "Get the proof."] as const, // COPY:
  lede: "Instant pricing for standard runs. A specialist for everything else.", // COPY:
  email: "[[EMAIL]]",
  hours: "[[HOURS]]",
};

/** Quote widget: who makes the artwork decides where the CTA goes. */
export const quoteArtwork = [
  { id: "upload", label: "I have artwork", cta: "Continue to upload", href: "/upload" }, // COPY:
  { id: "design", label: "Design it for me", cta: "Start a design brief", href: "[[DESIGN_BRIEF_URL]]" }, // COPY:
] as const;
