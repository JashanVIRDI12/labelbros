/** Hex mirrors of the @theme tokens, for SVG strings and three.js (CSS vars don't reach either). */
export const C = {
  paper: "#F1F0EC",
  sheet: "#FAFAF7",
  line: "#D9D7D1",
  ink: "#0E0F10",
  inkSoft: "#5B5D61",
  graphite: "#141516",
  graphite2: "#1F2123",
  steel: "#9A9DA2",
  signal: "#FF4F00",
  signalText: "#B83700",
  white: "#FFFFFF",
  cyan: "#00A3E0",
  magenta: "#E4007C",
  yellow: "#FFE500",
  // Label artwork only: customers' own brand and safety colours, never page UI.
  marigold: "#F5BA18",
  forest: "#0A5E46",
  orange: "#E8641F",
  cream: "#F3EBDC",
  hazard: "#D71A28",
  silver: "#C8CBCF",
  /** @deprecated legacy liner tone, kept for the 3D roll */
  frame: "#E4E2DC",
} as const;
