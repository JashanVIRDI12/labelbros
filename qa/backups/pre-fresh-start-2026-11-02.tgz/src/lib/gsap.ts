"use client";

import gsap from "gsap";
import { CustomEase } from "gsap/CustomEase";
import { Draggable } from "gsap/Draggable";
import { DrawSVGPlugin } from "gsap/DrawSVGPlugin";
import { Flip } from "gsap/Flip";
import { InertiaPlugin } from "gsap/InertiaPlugin";
import { Observer } from "gsap/Observer";
import { Physics2DPlugin } from "gsap/Physics2DPlugin";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import { useGSAP } from "@gsap/react";

if (typeof window !== "undefined") {
  gsap.registerPlugin(
    useGSAP,
    ScrollTrigger,
    SplitText,
    Flip,
    DrawSVGPlugin,
    CustomEase,
    Draggable,
    InertiaPlugin,
    Physics2DPlugin,
    Observer,
  );

  // "press": anything that seats, registers or lands. Fast in, firm stop, no overshoot:
  // machined, not bouncy.
  CustomEase.create("press", "M0,0 C0.32,0 0.12,1 1,1");

  // dev only: lets the QA scripts read pin ranges
  if (process.env.NODE_ENV !== "production") Object.assign(window, { ScrollTrigger });
}

/** Durations and staggers from the motion spec. */
export const DUR = { ui: 0.35, reveal: 0.7, press: 0.8, load: 1.1 } as const;
export const STAGGER = { chars: 0.04, lines: 0.08, cards: 0.06 } as const;

export {
  gsap,
  CustomEase,
  Draggable,
  DrawSVGPlugin,
  Flip,
  InertiaPlugin,
  Observer,
  Physics2DPlugin,
  ScrollTrigger,
  SplitText,
  useGSAP,
};
