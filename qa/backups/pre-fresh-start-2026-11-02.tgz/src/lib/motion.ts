/** gsap.matchMedia() conditions shared by every section. */
export const MQ = {
  isDesktop: "(min-width: 1024px) and (pointer: fine)",
  isTouch: "(max-width: 1023px), (pointer: coarse)",
  reduceMotion: "(prefers-reduced-motion: reduce)",
} as const;

export type MotionFlags = { isDesktop: boolean; isTouch: boolean; reduceMotion: boolean };

const REDUCE_KEY = "lb-reduce-motion";
export const REDUCE_EVENT = "lb:reducemotion";

/** The footer toggle can force reduced motion on top of the OS setting. */
export function userReducedMotion(): boolean {
  return typeof document !== "undefined" && document.documentElement.dataset.reduceMotion === "true";
}

export function setUserReducedMotion(on: boolean) {
  document.documentElement.dataset.reduceMotion = String(on);
  try {
    localStorage.setItem(REDUCE_KEY, on ? "1" : "0");
  } catch {}
  window.dispatchEvent(new Event(REDUCE_EVENT));
}

/** Runs before first paint (inlined in <head>): marks JS as available and applies the saved toggle. */
export const reduceMotionBootScript = `document.documentElement.classList.add("js");try{if(localStorage.getItem("${REDUCE_KEY}")==="1")document.documentElement.dataset.reduceMotion="true"}catch(e){}`;

/** Merge matchMedia conditions with the footer toggle. */
export function motionFlags(conditions: gsap.Conditions | undefined): MotionFlags {
  const c = conditions ?? {};
  const reduceMotion = Boolean(c.reduceMotion) || userReducedMotion();
  return { isDesktop: Boolean(c.isDesktop), isTouch: Boolean(c.isTouch), reduceMotion };
}

export function prefersReducedMotion(): boolean {
  return window.matchMedia(MQ.reduceMotion).matches || userReducedMotion();
}

/** Dev-only QA switch (window.__qaNoSnap): lets capture scripts stop between snap points. */
export function snapEnabled() {
  return process.env.NODE_ENV === "production" || !(window as Window & { __qaNoSnap?: boolean }).__qaNoSnap;
}

export type Tier = "high" | "low";
let cachedTier: Tier | null = null;

/** Low tier: few cores, no WebGL2, Save-Data, or ?tier=low. Gets the 2D stand-ins. */
export function getTier(): Tier {
  if (cachedTier) return cachedTier;
  const params = new URLSearchParams(window.location.search);
  const forced = params.get("tier");
  if (forced === "low" || forced === "high") return (cachedTier = forced);

  const nav = navigator as Navigator & { connection?: { saveData?: boolean } };
  const fewCores = (nav.hardwareConcurrency ?? 8) <= 4;
  const saveData = Boolean(nav.connection?.saveData);
  let webgl2 = false;
  try {
    const probe = document.createElement("canvas").getContext("webgl2");
    webgl2 = Boolean(probe);
    probe?.getExtension("WEBGL_lose_context")?.loseContext();
  } catch {}
  return (cachedTier = fewCores || saveData || !webgl2 ? "low" : "high");
}
