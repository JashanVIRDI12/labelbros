# Label Bros homepage v2: Claude Code build prompt

**What this is:** a single brief for Claude Code that builds the Label Bros homepage from scratch, in the style of the client's Pinterest reference, with one signature GSAP/Three.js scroll moment per section. It follows Anthropic's prompting guidance for current models: XML-tagged context, an explicit role, the reason behind each rule, named anti-patterns instead of "avoid generic", a stated scope ("be ambitious"), plan first, and checkable verification.

## Before you paste (run once)

```bash
# 1) Drop the skeleton into the empty project folder (skills, MCP, CLAUDE.md, reference image)
unzip label-bros-claude-setup.zip -d /tmp/lb && bash /tmp/lb/setup.sh /Users/mac/DigiClicks-projects/labelbros
#    optional 21st MCP:  export API_KEY_21ST=...  then add  --with-21st

# 2) Update and open Claude Code in the project
cd /Users/mac/DigiClicks-projects/labelbros
claude update        # Opus 5.5 needs >= v2.1.280, Sonnet 5.5 >= v2.1.284, Fable 5.1 >= v2.1.257
claude               # accept workspace trust + the project MCP servers; check with /mcp and /skills
```

**Model plan (verified against Claude Code docs, Nov 2026):**
- **Plan:** `/model opus` (Opus 5.5) with `/effort high`, in Plan Mode (Shift+Tab). If your plan includes it, `/model fable` (Fable 5.1, the most capable model for long autonomous work) is the premium option for the plan and the shader sections. It may bill to usage credits.
- **Build:** `/model opusplan` for scaffolding, static layout and simple sections (Opus plans, Sonnet 5.5 writes). Switch to `/model opus` with `/effort xhigh` for the hardest parts: the S1 peel shader, the S2 pinned timeline and Flip travel, the S3 jar wrap shader and the S5 finish morph. Add `ultrathink` to a single prompt when one turn needs extra depth.
- Use `/clear` between big phases. The plan and the progress log on disk carry the state.

Paste everything below this line.

---

<role>
You are the lead creative developer and interaction designer at a studio that regularly wins Awwwards Site of the Day and FWA. You ship premium, fast, accessible marketing sites with Next.js, GSAP and Three.js / React Three Fiber, and you have taste: you commit to a specific visual language and execute it precisely instead of drifting to templates. On this project you are building, not advising. Implement everything directly in this repository.
</role>

<context>
Client: **Label Bros**, a custom label and sticker printing company ([[ONE_LINE_DESCRIPTION, e.g. "custom product labels, roll labels and die-cut stickers for small brands, printed in-house"]]).
Audience: small and mid-size product brands (coffee, candles, cosmetics, craft drinks, food, merch), creators and agencies who need labels that look premium on the shelf.
Homepage goal: within one or two scrolls, a visitor understands the quality, trusts the process, and clicks **"Get instant pricing"** (primary) or **"Order a sample pack"** (secondary).
Brief from the client: "a good interactive website that is very good and clean and GSAP/Three.js worthy." Category reference: StickerBros (clear product grid, price anchors, proof-first, materials). **Visual reference: the Pinterest design in `reference/pinterest-reference.jpg`. This is the look we want.** Open the image now and keep it open as you work.

Repository state: this folder is a brand-new project. It currently contains only `CLAUDE.md`, `.claude/` (skills, a `design-reviewer` subagent, settings with a typecheck Stop hook), `.mcp.json` (Playwright + shadcn MCP), `reference/` and this prompt. There is no app yet; you will scaffold it here (see <workflow> step 1).

Installed project skills, and when to load them:
- `labelbros-motion`: our design system and the S0–S10 scroll spec (also embedded below). Load it at the start of every section.
- `frontend-design` (Anthropic): aesthetic direction and typography decisions.
- `gsap-core`, `gsap-timeline`, `gsap-scrolltrigger`, `gsap-plugins`, `gsap-react`, `gsap-performance`, `gsap-utils`, `gsap-frameworks` (official GreenSock): correct GSAP APIs, ScrollTrigger pin/scrub/snap/containerAnimation, SplitText/Flip/DrawSVG/Physics2D, `useGSAP` cleanup.
- `threejs-*` (fundamentals, react-three-fiber, shaders, materials, textures, lighting, loaders, asset-pipeline, performance, interaction, animation, geometry, postprocessing): R3F scene, custom vertex/fragment shaders for peel, wrap and finish, GLB pipeline, performance.
- `webapp-testing` (Anthropic) + Playwright MCP: run the site, screenshot, read console logs.
- `web-design-guidelines` and `vercel-react-best-practices` (Vercel): UI/a11y audit and React/Next performance review in QA.
- Subagent `design-reviewer`: an independent read-only visual QA pass after each section.
</context>

<design_reference>
## The reference (Pinterest pin 1145040274100092660, "Sticker app website: visual exploration" by Екатерина М)

File: `reference/pinterest-reference.jpg` (1200x900). Open it and look at it before you design anything.

**Layout.** A single landing-page artboard sits inside a warm grey frame (#E2E1DD) with about 5% padding. The artboard is warm off-white paper (#F5F4F2) with a faint square graph-paper grid, roughly 24px cells drawn at about 4-5% ink. The page is a two-column split. The left ~55% holds a giant three-line headline with a 3-step row under it. The right ~45% holds a phone mockup of a sticker editor, with flat stickers overlapping its edges. The nav runs across the top: PRODUCTS · TOOLS · SAMPLES · DEALS on the left, CART on the right, and SIGN IN in orange.

**Typography.** The headline "STICK IT 🔥 LIKE IT'S HOT" is set in an ultra-condensed, heavy grotesk (Druk/Tusker style) in all caps, pure black. Leading is about 0.86, tracking is tight, and the cap height is about 12vw. Illustrated stickers sit inline inside the type: a yellow round "THE BEST QUALITY / Nº1" badge tucked after STICK, and an orange-and-yellow flame standing in for a word gap between IT and LIKE. Nav and UI labels use a condensed grotesk at medium weight in caps, about 15-16px. The step row reads 01 DESIGN / 02 ORDER / 03 STICK: tiny step numbers, condensed bold titles at about 22-24px, and small grey caps captions ("CHOOSE FROM OVER 40 STYLES", "WITH 7-DAYS DELIVERY GUARANTEE", "LIKE YOU F*CKIN' MEAN IT").

**Color (sampled from the image).** Ink #0A0A0A · paper #F5F4F2 · frame #E2E1DD · orange #E8641F · marigold #F5BA18 · forest green #0A5E46 · bubblegum pink #F89ABC · periwinkle #565DC5 · caption grey #A1A09E · white #FFFFFF.

**Imagery and illustration.** Everything is flat vector with no gradients and no drop shadows. The stickers are chunky and playful, and most have a white die-cut border. They include: a green oval with "HELLO HELLO" running around a yellow smiley; the yellow Nº1 badge with orange curved text and a periwinkle "Nº1"; a pink rounded tag reading "QUALITY PRODUCT" over orange blobs; a periwinkle striped sphere; bubble letters "LO / VE" in green on pink; and a yellow hand-drawn crown die-cut sticker on the phone canvas with a thick white offset outline.

**UI elements.** The phone has about 36px corners, an orange header bar with a back arrow, "UNTITLED / DIE CUT STICKER" and a save icon, a dotted canvas, a row of pill chips (COLOR · THICKNESS · FILL · ERASER), and an icon tab bar (TEMPLATES · TEXT · SHAPES · DRAW, with DRAW active in orange). The pill chips have thin grey borders.

**Spacing and composition.** Margins are generous, and the headline block nearly touches the left margin. The stickers break the phone's bounding box, giving controlled chaos on a calm grid. The page has very few elements, and the contrast between black and paper is very strong.

**Mood.** Streetwear and zine attitude with clean execution. Confident, cheeky, tactile and fun, but premium and uncluttered. The brand speaks in a casual voice.

**Translating it to Label Bros.** Keep: the paper-and-grid canvas, the ultra-condensed black display type with inline illustrated stickers, the flat sticker vocabulary with white die-cut borders, the five-accent palette, the numbered step row, the pill chips, and the cheeky copy voice. Add: depth and motion. The flat stickers become real 3D die-cut objects that peel, fly, wrap onto products and change finish as you scroll, and the phone "editor" becomes a live label-designer moment.
</design_reference>

<design_tokens>
## Design tokens (derived from the reference)

Define these as CSS variables in `app/globals.css` using Tailwind v4's `@theme`, and use only these values.

```css
@theme {
  /* color */
  --color-paper:    #F5F4F2;  /* page canvas */
  --color-frame:    #E2E1DD;  /* outer frame / alt section bg */
  --color-ink:      #0A0A0A;  /* type, 18:1 on paper */
  --color-ink-soft: #6B6A66;  /* captions; 4.9:1 on paper (the ref's #A1A09E fails AA, use only for decoration) */
  --color-orange:   #E8641F;  /* brand accent; on paper only for text >= 24px or as a fill with ink text (5.9:1) */
  --color-orange-text: #C2470F; /* orange for small text on paper, 4.55:1 */
  --color-marigold: #F5BA18;
  --color-forest:   #0A5E46;  /* white text on it 7.8:1 */
  --color-bubblegum:#F89ABC;
  --color-periwinkle:#565DC5; /* white text on it 5.6:1 */
  --color-white:    #FFFFFF;  /* die-cut borders, phone body */
  --color-grid:     rgb(10 10 10 / 0.05); /* 24px graph-paper lines */

  /* type */
  --font-display: "Anton", "Arial Narrow", sans-serif;          /* headlines, step titles, prices */
  --font-sans:    "Archivo", system-ui, sans-serif;             /* variable: wdth 62-125, wght 100-900 */

  /* radii */
  --radius-chip: 999px;   /* pills, round stickers, primary buttons (the reference uses pills) */
  --radius-card: 20px;
  --radius-phone: 36px;
  --radius-tag: 28px;     /* rounded-rect stickers */

  /* motion */
  --ease-slap:  cubic-bezier(.2,1.4,.4,1);   /* CSS mirror of the GSAP "slap" CustomEase */
  --ease-out:   cubic-bezier(.16,1,.3,1);    /* mirror of expo.out */
}
```

**Fonts (all free on Google Fonts, self-hosted with `next/font/google`):**
- Display: **Anton** (400, the only weight; already ultra-condensed and heavy, the closest free match to the reference's Druk/Tusker-style face). Set it uppercase with `line-height: .86`, `letter-spacing: -0.01em`, and size `clamp(4.25rem, 12.5vw, 13.5rem)` for the hero. Alternative if the client wants more weight range: **Big Shoulders Display 800-900**.
- UI and body: **Archivo** variable with the width axis. Nav, chips and labels use `font-stretch: 75%` at weight 600 in uppercase, 15-16px, `letter-spacing: .01em`, which matches the reference's condensed nav. Body copy uses `font-stretch: 100%` at weight 400, 16-18px, line-height 1.5. Captions use 75% width, weight 500, uppercase, 12px, `letter-spacing: .04em`, in `--color-ink-soft`.

**Type scale (rem):** 0.75 · 0.875 · 1 · 1.125 · 1.5 · 2 · 3 · 4.5 · 7 · fluid hero clamp.
**Spacing scale (4px base):** 4 · 8 · 12 · 16 · 24 · 32 · 48 · 64 · 96 · 128 · 192.
**Grid:** 12 columns, 24px gutter, side margin `clamp(20px, 5vw, 96px)`. On desktop the page sits inside a 16-24px `--color-frame` border like the reference artboard, and the paper canvas carries a 24px CSS-gradient graph grid.
**Stickers:** flat fills from the palette with a 6-8px white die-cut border (SVG stroke or an outline mesh in 3D) and no drop shadows in 2D. In 3D, use only a soft contact shadow.
**Iconography:** thick-stroke (2px) line icons, as in the reference's phone tab bar.
</design_tokens>

<sections_and_scroll_choreography>
## Global motion system (applies to every section)

**Stack.** GSAP 3.15 from the public `gsap` package. All plugins are free, with no token or private registry: ScrollTrigger, SplitText, Flip, DrawSVGPlugin, CustomEase, Draggable, InertiaPlugin, Physics2DPlugin, Observer. Use `@gsap/react` `useGSAP()` for every animation scope. Lenis 1.3 handles smooth scroll. three r187 + @react-three/fiber 9 + @react-three/drei 10 render the 3D.

**One easing language.** Use only these, and register them once in `lib/gsap.ts`:
- `CustomEase.create("slap", "M0,0 C0.2,0 0.1,1.12 0.5,1.04 0.75,1 1,1")` is the sticker-landing overshoot. Use it for anything that sticks, lands or snaps.
- `expo.out` for type reveals and UI entrances.
- `power2.inOut` for camera moves and Flip travels.
- `ease: "none"` on every scrubbed tween. The scrub smoothing (`scrub: 1`) supplies the feel.
- Durations: 0.35 (UI), 0.6 (reveals), 0.9 (slaps), 1.2 (hero load). Staggers: 0.04 chars, 0.08 lines, 0.06 cards.

**Rules.**
1. Animate only `transform` and `opacity`. The exceptions are `clip-path` (two moments, marked below), SVG stroke (DrawSVG) and shader uniforms.
2. Wrap every setup in `gsap.matchMedia()` with conditions `{ isDesktop: "(min-width: 1024px) and (pointer: fine)", isTouch: "(max-width: 1023px), (pointer: coarse)", reduceMotion: "(prefers-reduced-motion: reduce)" }`, inside `useGSAP({ scope })`. Never nest `gsap.context()` inside matchMedia. A footer "Reduce motion" toggle sets a `data-reduce-motion` attribute and calls `gsap.matchMediaRefresh()`.
3. Lenis: `new Lenis({ autoRaf: false })`, `lenis.on("scroll", ScrollTrigger.update)`, `gsap.ticker.add(t => lenis.raf(t * 1000))`, `gsap.ticker.lagSmoothing(0)`. Don't create Lenis when `reduceMotion` is true.
4. Call `ScrollTrigger.refresh()` after `document.fonts.ready`, after the GLB and textures load, and after any image-driven layout change. Use SplitText with `autoSplit: true`, create the animation inside `onSplit()` and return it.
5. Create ScrollTriggers top-to-bottom in page order, or set `refreshPriority`. Pinned sections use `pinSpacing: true` and `anticipatePin: 1`. Never pin inside a `containerAnimation`.
6. **Three.js sync.** Use one fixed, full-viewport `<Canvas>` (pointer-events: none, `frameloop="demand"`, `dpr={[1, 2]}`, 1.5 max on touch) shared by every 3D moment. ScrollTriggers write progress into a plain mutable store (`lib/scrollStore.ts`: `{ hero, cut, wrap, finish, finishIndex }`) in `onUpdate` and call `invalidate()`. `useFrame` reads the store and eases toward it with `THREE.MathUtils.damp(current, target, 6, delta)`. GSAP never tweens three objects directly from the DOM tree, which keeps React out of the hot path. Pause rendering when the tab is hidden or no 3D section is in view.
7. No generic fade-ups. Every section gets exactly one signature moment from the list below. Everything else in that section stays still or uses a small `expo.out` reveal, so the signature reads clearly.
8. Device tier: `navigator.hardwareConcurrency <= 4`, no WebGL2, or `saveData` puts the visitor in the low tier. The low tier uses posters (AVIF) plus the 2D fallbacks listed per section.
9. Reduced motion: no Lenis, no pin, no scrub, no parallax and no marquees. Every section renders its final state, with at most a 200ms opacity fade. Information never depends on motion.

## Section-by-section spec with signature scroll moments

### S0. Header
Content: wordmark (logo [[LOGO_SVG]] or Anton wordmark "LABEL BROS"), PRODUCTS · MATERIALS · HOW IT WORKS · SAMPLES · DEALS, CART (count), SIGN IN in `--color-orange-text`, and a pill "GET A QUOTE" in ink.
Motion: the header hides on scroll-down and shows on scroll-up (one ScrollTrigger `onUpdate` with `self.direction`, `yPercent` tween of 0.35s `expo.out`). The CTA pill is magnetic (React Bits Magnet). This is not a signature moment.

### S1. Hero: "Slap-in" on load, "Peel-off" on scroll
Layout: matches the reference. The left 7 columns hold a three-line Anton headline [[HERO_HEADLINE, default: "LABEL IT / 🔥 LIKE YOU / MEAN IT"]]. Two illustrated stickers sit inline in the type: a marigold round "Nº1 / PRINTED IN-HOUSE" badge, and an orange flame (or a custom Label Bros mascot sticker) replacing a word gap. Under it sits the step row: 01 DESIGN "Upload or build your label", 02 PROOF "Free proof in [[PROOF_TIME]]", 03 STICK "Ships in [[TURNAROUND]]". A primary CTA reads "GET INSTANT PRICING", a secondary reads "ORDER A SAMPLE PACK", and a trust line shows [[RATING]] ★ · [[REVIEW_COUNT]] reviews. The right 5 columns hold the "Label Studio" phone (DOM, crisp UI cloned from the reference: orange header "UNTITLED / CUSTOM LABEL", dotted canvas, chips COLOR · SHAPE · FINISH · SIZE, tab bar TEMPLATES · TEXT · SHAPES · UPLOAD). The canvas shows a jar label design. Four or five 3D die-cut stickers float around the phone: a green "HELLO" oval, a pink "QUALITY PRODUCT" tag, a periwinkle striped ball and a "LO/VE" bubble, re-themed with Label Bros words such as "FRESH BATCH" and "SMALL BRAND, BIG SHELF".
- **Load (signature, not scroll), timeline about 1.4s:** headline lines rise through SplitText `mask: "lines"` (`yPercent: 110 → 0`, `expo.out`, stagger 0.08). At 0.35s each inline sticker slaps in (`scale 1.6 → 1`, `rotation ±18 → final`, `slap` ease, 0.9s) with a one-frame squash (`scaleY .9`). The phone rises from `y: 60` (`expo.out`), and a DrawSVG die-cut line traces around the label artwork on the phone canvas (`drawSVG: "0% 0%" → "0% 100%"`, 0.9s). The 3D stickers drop in with damped spring rotation.
- **Scroll (signature): "Peel-off".** `trigger: hero, start: "top top", end: "+=100%", pin: true, scrub: 1`. Over 0→0.5 progress the inline headline stickers peel off the type: a WebGL plane copy of each sticker takes over from the DOM and its `uPeel` uniform goes 0→1 (vertex-shader curl around a diagonal hinge, back face rendered as the white liner). They then lift into 3D space and orbit toward the right. At the same time the headline lines slide out sideways through their masks (line 1 `xPercent: -110`, line 2 `+110`, line 3 `-110`, `ease: "none"`). Over 0.5→1 the phone eases toward the horizontal centre (`xPercent`, `scale .92`). Its full Flip travel into S2 starts once the pin releases (see S2).
- Three sync: `store.hero = self.progress` drives the sticker peel uniforms, their positions along a CatmullRom curve, and a 6% camera dolly-in.
- Touch: no pin. Load timeline only. Stickers in 2D (SVG) with a CSS hover wobble, and a single tap-to-peel on the Nº1 badge.
- Reduced motion: static composition as in the reference, with no 3D motion.

### S2. How it works: "The die-cut" (phone travels in, cut line draws)
Content: 01 DESIGN → 02 PROOF → 03 PRINT → 04 STICK, each with a one-line benefit and a tiny caption in the reference's grey caps style ([[STEP_COPY]]).
- **Scroll (signature):** the hero phone travels into this section with consecutive scrubbed Flips. `Flip.fit(phone, slotEl, { ease: "power2.inOut" })` sits inside a ScrollTrigger timeline: `trigger: "#how", start: "clamp(top bottom)", end: "clamp(top top)", scrub: 1, immediateRender: false`. This is the GSAP "Consecutive Scrub Flips" pattern. Once docked, the section pins (`start: "top top", end: "+=250%", pin: true, scrub: 1`) and one master timeline plays four labelled steps:
  1. DESIGN: artwork elements Flip from a scattered sticker-sheet layout into the label layout on the phone canvas.
  2. PROOF: a proof stamp "APPROVED ✓" slaps on (`slap` ease), the only non-`none` ease inside the scrub, wrapped in its own short sub-tween.
  3. PRINT: the canvas becomes a printed sheet. A halftone/CMYK registration sweep runs as a `clip-path: inset()` wipe (clip-path moment 1 of 2).
  4. STICK: a die-cut path draws around the label (`drawSVG: "0% 100%"`), the kiss-cut label lifts off its liner (3D peel `store.cut`), and it flies out of frame toward S3.
  A left rail shows 01-04 with the active number filling ink, and step copy changes through SplitText line masks. `snap: { snapTo: "labels", duration: { min: .2, max: .6 }, ease: "power1.inOut" }`.
- Touch: no pin. Four stacked cards. Each card's mini-animation (Flip / stamp / wipe / draw) plays once with `toggleActions: "play none none reverse"`, `start: "top 70%"`.
- Reduced motion: four static cards with final-state illustrations.

### S3. "The wrap": a label wraps a 3D jar on scroll
Content: H2 [[WRAP_HEADLINE, default: "FLAT ART. FULL WRAP. ZERO BUBBLES."]], three short proof points (waterproof · scuff-proof · [[CLAIM]]), and finish chips (MATTE · GLOSS · HOLO · CHROME · CLEAR).
- **Scroll (signature):** `trigger: "#wrap", start: "top top", end: "+=200%", pin: true, scrub: 1`. The label that flew out of S2 arrives as a flat plane in front of a 3D jar (default jar; `PRODUCT_MODEL` can be jar | bottle | can, sharing one geometry pipeline). `store.wrap` 0→0.6 drives a `uWrap` vertex uniform that bends the plane around the jar's radius (cylindrical mapping: `angle = (x / width) * uWrap * 2π`, lerped from flat to wrapped, with a tiny overshoot settle using `slap` in the damp target). From 0.6→1 the jar turns 300°, the key light sweeps across the label to show the finish, and the camera pulls back to reveal the jar standing on a paper-grid "shelf". Copy lines enter through SplitText masks at 0.15, 0.45 and 0.75 (labels on the same timeline).
- Finish chips are interactive (not scroll). Clicking tweens material uniforms (roughness, metalness, clearcoat, iridescence, transmission) over 0.6s `expo.out`, with keyboard arrow navigation.
- Touch: pin reduced to `+=120%`, half the geometry segments, no light sweep. Low tier gets a 3-frame AVIF crossfade (flat → half → wrapped).
- Reduced motion: the wrapped jar poster with chips that swap poster images.

### S4. Products: "Label roll unspool" (pinned horizontal)
Content: 6-8 product types [[PRODUCTS: roll labels, product labels, die-cut stickers, sticker sheets, clear labels, holographic, embossed, custom packaging]], each with an image, a one-liner, "FROM [[PRICE]]" set in Anton, and an arrow link.
- **Scroll (signature):** a label roll (SVG roll core at the left edge, plus a 3D cylinder on desktop) unspools a long liner strip across the screen. The product cards are the labels on that liner. `const track = gsap.to(".roll-track", { x: () => -(track.scrollWidth - innerWidth), ease: "none", scrollTrigger: { trigger: "#products", start: "top top", end: () => "+=" + track.scrollWidth, pin: true, scrub: 1, invalidateOnRefresh: true } })`. The roll core rotates in sync (`rotation: progress * 1440`). Each card gets its own ScrollTrigger with `containerAnimation: track, start: "left 60%"`: it peels up off the liner (`rotationX: -12 → 0`, `y: 24 → 0`, `transformOrigin: "50% 100%"`, `slap`, played rather than scrubbed). The liner's backing-paper texture reveals the die-cut gap where each card sat. A progress counter "03 / 08" in Anton follows.
- Touch: native horizontal scroll-snap carousel (`scroll-snap-type: x mandatory`) with the same peel on card enter via IntersectionObserver-driven `gsap.from`. No pin.
- Reduced motion: a regular 2- or 4-column grid.

### S5. Materials and finishes: "Finish morph" (one sticker, every finish)
Content: 6-8 materials [[MATERIALS: matte white, gloss white, clear, holographic, chrome/metallic, kraft, glitter, removable]], each with a name, a "best for" line, and durability icons.
- **Scroll (signature):** a sticky stage. On the left is a big 3D Label Bros sticker (rounded die-cut). On the right is a vertical list of materials. `trigger: "#materials", start: "top top", end: "+=" + (n * 60) + "%", pin: true, scrub: 1, snap: 1 / (n - 1)`. `store.finish` (0→n-1) cross-blends shader parameters between adjacent materials: roughness, metalness, an iridescence thin-film term for holo, transmission for clear, a sparkle-noise layer for glitter, and a paper-fibre normal map for kraft. The sticker tilts toward the cursor (damped) and does a quarter turn per material so the light catches the new finish. The page background tints toward each material's accent (a `--stage-tint` CSS var tween, opacity layer only). The active material name gets React Bits ShinyText for holo and chrome.
- Touch: shorter pin (`n * 35%`), no cursor tilt. Low tier and no-WebGL: a 2D sticker with layered CSS gradients per finish, swapped with a `clip-path` circle wipe (clip-path moment 2 of 2).
- Reduced motion: a static swatch grid. Click a swatch to swap the poster.

### S6. Instant quote: "Sheet assembly"
Content: a mini configurator for product type, size (preset chips + custom W×H), quantity (slider with price-break ticks) and material. It shows a live total, a per-unit price, a break hint ("ADD 250 MORE, SAVE 18%"), and a "CONTINUE TO UPLOAD" CTA. Pricing comes from `data/pricing.ts` [[REAL_PRICING]].
- **Scroll (signature, play once):** on `start: "top 65%"` the configurator's controls start out scattered like loose stickers on a sheet (random x/y/rotation set from a seeded layout). `Flip.from(state, { absolute: true, ease: "slap", duration: .9, stagger: .05 })` snaps them into the form grid. The price counts up from 0 (`textContent` tween with `snap: { textContent: 1 }`, `expo.out`). On quantity change, a tiny stack of sticker sheets beside the price grows or shrinks (`scaleY`, `slap`).
- Touch: same, with a shorter stagger. Reduced motion: the form is simply present.

### S7. Social proof: "Sticker-bomb wall"
Content: rating summary, 9-12 reviews [[REVIEWS]], client logos [[LOGOS]], and 2 mini case studies with photos.
- **Scroll (signature):** reviews are rendered as die-cut stickers (palette fills, white border, slight random rotation). `ScrollTrigger.batch(".review-sticker", { start: "top 85%", onEnter: b => gsap.from(b, { scale: 1.5, rotation: "random(-25,25)", opacity: 0, ease: "slap", duration: .8, stagger: .07 }) })` slaps them onto a "laptop lid" / wall. Below that, two logo marquee rows (React Bits ScrollVelocity) skew with scroll velocity (`gsap.quickTo(row, "skewX", { duration: .4, ease: "power3" })`, value clamped to ±8° from `self.getVelocity() / 300`) and reverse direction with `self.direction`.
- Touch: batch slaps kept, velocity skew off, marquees at slower speed. Reduced motion: a static grid with paused marquees.

### S8. Sample pack + guarantee: "Drag to peel"
Content: "FEEL IT BEFORE YOU ORDER". Sample pack price [[SAMPLE_PRICE]], reprint guarantee, free proof.
- **Signature (interaction, scroll-armed):** a large sticker lies over a discount code [[CODE]]. ScrollTrigger (`start: "top 70%"`) plays a teaser corner lift (`uPeel 0 → .15 → 0`, `slap`) once. The visitor drags the corner (Draggable + InertiaPlugin, `type: "x,y"`, bounded) to peel it, using the 3D peel shader (or React Bits StickerPeel on low tier). Past 55% it releases and the code is revealed and copied with an aria-live confirmation. A keyboard-accessible "PEEL" button does the same.

### S9. Final CTA: "Stamp and scatter"
Content: a giant Anton line [[CTA_HEADLINE, default: "STICK WITH US."]], "GET INSTANT PRICING", and "TALK TO A HUMAN" ([[EMAIL]] · [[HOURS]]).
- **Scroll (signature):** `trigger: "#cta", start: "top 80%", end: "center center", scrub: 1`. The headline letters press down like a rubber stamp (SplitText chars, `scale: 1.25 → 1`, `yPercent: -30 → 0`, stagger 0.03, `ease: "none"`), with ink density rising through an opacity layer. When the scrub completes (`onLeave`/`onScrubComplete`, once), 14 small stickers burst from behind the CTA button with Physics2DPlugin (`physics2D: { velocity: "random(300,600)", angle: "random(200,340)", gravity: 900 }`) and settle on the page edge.
- Touch: same, with 8 stickers. Reduced motion: static.

### S10. Footer: "Curtain + loose stickers"
Content: product, material and help links (artwork guidelines, shipping, FAQ), company info, a newsletter field, socials, legal, and the "Reduce motion" toggle.
Motion: a curtain reveal. The footer is `position: sticky; bottom: 0` under the last section, and the CTA section's bottom edge is a die-cut wavy edge drawn in SVG. Three brand stickers in the footer are Draggable (`bounds: footer`, `inertia: true`). This is a reward rather than a signature moment.
</sections_and_scroll_choreography>

<components>
## Components (vetted picks; install, then restyle to the tokens)

Add the React Bits registry to `components.json` first: `"registries": { "@react-bits": "https://reactbits.dev/r/{name}.json" }`. React Bits is free (MIT + Commons Clause). Use the `-TS-TW` variants.

| Use in | Component | Install |
|---|---|---|
| S8 low-tier peel fallback, footer stickers | React Bits **Sticker Peel** | `npx shadcn@latest add @react-bits/StickerPeel-TS-TW` |
| S5 holo and chrome material names | React Bits **Shiny Text** | `npx shadcn@latest add @react-bits/ShinyText-TS-TW` |
| S7 logo rows (velocity-skewed) | React Bits **Scroll Velocity** | `npx shadcn@latest add @react-bits/ScrollVelocity-TS-TW` |
| Header and all primary CTAs | React Bits **Magnet** | `npx shadcn@latest add @react-bits/Magnet-TS-TW` |
| S4 product cards (hover gloss) | React Bits **Glare Hover** | `npx shadcn@latest add @react-bits/GlareHover-TS-TW` |
| S6 configurator base | 21st.dev **Pricing Interaction** (ln-dev7) | `npx shadcn@latest add "https://21st.dev/r/ln-dev7/pricing-interaction?api_key=$API_KEY_21ST"` |
| S10 footer base (GSAP curtain + magnetic pill) | 21st.dev **Motion Footer** (jahed) | `npx shadcn@latest add "https://21st.dev/r/jahed/motion-footer?api_key=$API_KEY_21ST"` |
| Optional divider: text running along a curving "label liner" | 21st.dev **Marquee Along SVG Path** (danielpetho) | `npx shadcn@latest add "https://21st.dev/r/danielpetho/marquee-along-svg-path?api_key=$API_KEY_21ST"` |

Rules:
- Read each component's source after install and remove what we don't use. Replace hard-coded colors and fonts with the tokens, add reduced-motion handling, and keep all GSAP code inside `useGSAP`.
- Don't add components that create their own WebGL context (Liquid Chrome, Circular Gallery and similar). The page has exactly one `<Canvas>`.
- If a component pulls in `motion`/framer-motion, keep it only if it is small and isolated. All scroll choreography is GSAP.
- 21st.dev's free tier allows 2 component copies a day, and install URLs need `API_KEY_21ST`. Don't call the 21st MCP's paid `generate` tool without asking.
</components>

<references>
## Award-level references (verified Nov 2026). Study the technique; don't copy the look.

1. **Tabasco: The Root of a Legacy**, Awwwards Honorable Mention (26 Jul 2026). R3F + GSAP ScrollTrigger + Lenis: scroll is the timeline, a pepper ripens with scroll, and the product lineup is revealed in 3D, with a complete mobile version. https://www.awwwards.com/sites/tabasco-the-root-of-a-legacy · case study: https://hilostudiolab.com/en/projects/tabasco
2. **La Revoltosa**, Awwwards SOTD. Three.js bottle with GSAP + Lenis scrollytelling. It swaps labels and colors on shared geometry for mobile performance (our S3 jar pipeline). https://www.awwwards.com/sites/la-revoltosa
3. **Noho**, Awwwards SOTD (18 Sep 2026). Warm off-white palette (#F1EEE9), 3D product interaction, playful footer reveal, GSAP. Proof that a paper-colored, clean site can still feel rich. https://www.awwwards.com/sites/noho
4. **GSAP.com by ToyFight**, Awwwards SOTD. Playful hero animations, smooth scrolling and type, and logo interactions: the bar for cheeky-but-polished motion. https://www.awwwards.com/sites/gsap
5. **Tiger Tells About Voodoo**, Awwwards SOTD. Oversized typography plus animated stickers and horizontal scroll scenes, the closest award winner to the pin's sticker-on-type language. https://sherriuble.com/tigertells.html
6. **Codrops: Consecutive Scroll Animations with One Element**. `Flip.fit` waypoints inside a scrubbed ScrollTrigger timeline (our S1→S2 phone travel). https://tympanus.net/codrops/2024/11/20/consecutive-scroll-animations-with-one-element/
7. **Codrops: Building a Scroll-Revealed WebGL Gallery with GSAP, Three.js, Astro and Barba.js** (Feb 2026). Syncing WebGL planes with the DOM and driving shader uniforms from ScrollTrigger. https://tympanus.net/codrops/2026/02/02/building-a-scroll-revealed-webgl-gallery-with-gsap-three-js-astro-and-barba-js/
8. **Codrops: Animating Responsive Grid Layout Transitions with GSAP Flip** (Jan 2026). Flip.getState → layout change → Flip.from (our S6 sheet assembly). https://tympanus.net/codrops/2026/01/20/animating-responsive-grid-layout-transitions-with-gsap-flip/
9. **Sticker peel shader references.** Foil sticker shader with peel uniforms and Rodrigues rotation: https://www.4rknova.com/blog/2025/08/30/foil-sticker · interactive peel walkthrough: https://fablegrounds.com/labs/sticker-peel/ · die-cut WebGL sticker with real curl and satin back: https://github.com/CatsJuice/sticker-forge (technique reference only; check its license before reusing code).
10. **GSAP Showcase**, the motion quality bar. https://gsap.com/showcase/
Client category reference: https://www.stickerbros.com/ (clear product grid, price anchors, proof-first flow, 12 materials).
</references>

<tech_stack>
- Next.js 16 (App Router) + React 19 + TypeScript strict; static rendering for `/`. pnpm.
- Tailwind CSS v4, with tokens in `@theme`. shadcn/ui initialised (for the registries).
- `gsap` 3.15 + `@gsap/react` from public npm. Every plugin is free; don't add `.npmrc` tokens or private registries.
- `lenis` 1.3 (no `@studio-freight/*`).
- `three` r187 + `@react-three/fiber` 9 + `@react-three/drei` 10. One shared `<Canvas>` loaded with `next/dynamic` (`ssr: false`) after first paint. Models are compressed GLB (meshopt or Draco, KTX2 textures), with a total 3D payload under 1.5 MB. Build the jar procedurally with `LatheGeometry` if no model is supplied [[PRODUCT_MODEL_GLB]].
- No other animation libraries unless a vetted component already depends on one.
</tech_stack>

<file_structure>
src/app/{layout.tsx,page.tsx,globals.css}
src/components/layout/{Header,Footer}.tsx
src/components/sections/{Hero,HowItWorks,Wrap,Products,Materials,Quote,Reviews,SamplePack,FinalCta}.tsx
src/components/three/{Scene.tsx,Stickers.tsx,Jar.tsx,FinishSticker.tsx}, src/components/three/shaders/{peel,wrap,finish}.{vert,frag}.glsl (or .ts)
src/components/stickers/ (flat SVG sticker set: Nº1 badge, flame, HELLO oval, QUALITY tag, striped ball, LO/VE bubble, re-themed for Label Bros)
src/components/ui/ (shadcn, React Bits, 21st installs)
src/lib/{gsap.ts,lenis.ts,scrollStore.ts,motion.ts (matchMedia conditions, device tier)}
src/data/{products,materials,pricing,reviews,copy}.ts (placeholders)
public/models/, public/posters/ (AVIF/WebP fallbacks for every 3D moment)
</file_structure>

<placeholders>
Keep these visible as `[[NAME]]` strings in `src/data/*.ts` until I supply them: LOGO_SVG, HERO_HEADLINE, ONE_LINE_DESCRIPTION, PROOF_TIME, TURNAROUND, RATING, REVIEW_COUNT, STEP_COPY, WRAP_HEADLINE, CLAIM, PRODUCTS, PRICE (per product), MATERIALS, REAL_PRICING, REVIEWS, LOGOS, SAMPLE_PRICE, CODE, CTA_HEADLINE, EMAIL, HOURS, PRODUCT_MODEL_GLB, BRAND_COLORS_OVERRIDE (if the client has brand colors, map them onto the token names, keeping the reference's ink/paper/accent structure).
Where copy is missing, write strong placeholder copy in the reference's voice (short, cheeky, confident, all-caps display lines) and mark it `// COPY:`. Never invent real-looking statistics or claims.
</placeholders>

<quality_bar>
- The bar is **Awwwards Site of the Day**, executed like the reference: a calm grid, enormous condensed type, flat die-cut stickers, five confident accents on warm paper. On top of that comes depth and motion that make printing tangible.
- Every section has **one signature moment** (specified below) that reads clearly. No generic fade-ups, no scattered micro-effects, no animation without a job.
- Be ambitious. Build the full version: the real shaders (peel, wrap, finish), the Flip travel, the pinned timelines with snapping, the touch variants, the reduced-motion variants, low-tier posters, keyboard access to every interactive 3D control, and empty, loading and error states in the quote widget. Don't stop at a layout with "animation hooks".
- Performance: Lighthouse mobile Perf ≥ 90, A11y 100, BP ≥ 95, SEO 100. LCP < 2.5s (the H1 or a poster, never the canvas), CLS < 0.05, INP < 200ms, a steady 60fps on a recent laptop during every pinned moment, and no long tasks over 50ms while scrolling.
- Accessibility: WCAG 2.2 AA. One H1, semantic landmarks, real buttons and links, visible focus rings, `aria-label` on split text, `role="img"` plus a description on the canvas, aria-live for the peel code, contrast ≥ 4.5:1, touch targets ≥ 44px.
</quality_bar>

<constraints>
- Animate only transform and opacity, plus the listed exceptions. Clean up every ScrollTrigger, SplitText, Draggable, Lenis instance and three.js resource (geometry, material and texture `dispose()`) on unmount.
- Exactly one WebGL context on the page. Pause rendering when no 3D section is in view or the tab is hidden. Cap DPR at 2 (1.5 on touch).
- Lazy-load three and the models after first paint. Self-host fonts with `next/font` (`display: swap`, preload Anton) to avoid layout shift. Call `ScrollTrigger.refresh()` after fonts and models load.
- Responsive and verified at 390, 768, 1280, 1440 and 1920. Touch gets the simplified variants in the spec.
- Keep code minimal and readable. Don't add abstractions, config systems or features beyond this brief. Delete temporary scripts and test files you create.
- Don't push, deploy, or delete anything outside this folder without asking. Never read `.env*`.
</constraints>

<frontend_aesthetics>
You tend to drift toward a few default looks. For this project, the reference decides the look, so match it rather than "improving" it toward your defaults.
- **Keep, because they come from the reference:** the warm off-white paper canvas with a faint 24px grid inside a grey frame, the ultra-condensed black all-caps display type (Anton), the 01/02/03 numbered step row, pill-shaped chips and buttons, flat illustrated stickers with white die-cut borders, and the orange / marigold / forest / bubblegum / periwinkle accents.
- **Don't use:** Inter, Roboto, Arial, Space Grotesk or system UI fonts for visible text; gradient fills on UI; glassmorphism or blur cards; drop shadows on 2D stickers; italic or serif accent words inside headlines; monospace labels; purple-to-blue SaaS gradients; bento-grid feature blocks; emoji in place of drawn stickers; stock-photo heroes; generic fade-up-on-scroll for every element.
- Stickers are drawn as real SVG illustrations (bold shapes, curved text on paths, thick white offset outlines), never as rounded divs with text.
- The 3D carries the same flat vocabulary: toon-flat or softly lit stickers with crisp silhouettes and a white die-cut rim, on paper. Avoid shiny "tech demo" renders, except where a finish (chrome, holo) is the point.
After the first full pass, list the default styles you notice you used anyway, and remove them.
</frontend_aesthetics>

<workflow>
Work through these phases in order. Keep `PLAN.md` (the plan plus a checklist for every section and phase) and `PROGRESS.md` (a dated log of what's done, what was verified, and what's next) updated in the repo, so any fresh session can resume from them.

1. **Scaffold the stack in this directory (the current working directory).** `create-next-app` refuses a non-empty folder, so scaffold into a temporary subfolder and move it up without touching our files:
   `pnpm create next-app@latest labelbros-scaffold --ts --tailwind --eslint --app --src-dir --import-alias "@/*" --use-pnpm --yes`
   Then move everything from `labelbros-scaffold/` (dotfiles included) into `./`, except its `.git`, and set `"name": "labelbros"` in `package.json`. Merge its `.gitignore` into ours. Never overwrite `CLAUDE.md`, `.claude/`, `.mcp.json`, `reference/` or `claude-prompt.md`. Delete `labelbros-scaffold/`. Then run `git init` if needed, `pnpm dlx shadcn@latest init`, `pnpm add gsap @gsap/react lenis three @react-three/fiber @react-three/drei` and `pnpm add -D @types/three`, add the React Bits registry to `components.json`, and install the components in <components>. Confirm that `pnpm dev`, `pnpm tsc --noEmit` and `pnpm build` all pass.
2. **Plan (Plan Mode).** Study the reference image and this brief, then write `PLAN.md` with:
   (a) a 5-line restatement of the goal;
   (b) the design direction as you will implement it (tokens, type, sticker set, 3D style);
   (c) for each section S0–S10, its layout, signature moment, Three.js store keys, and touch and reduced-motion variants;
   (d) risks, such as shader complexity or pin stacking, with a mitigation for each;
   (e) open questions for me.
   Stop and wait for my OK.
3. **Foundation.** Tokens in `globals.css`, fonts, the paper-grid frame, `lib/gsap.ts` (register plugins, CustomEase `slap`), `lib/lenis.ts`, `lib/scrollStore.ts`, `lib/motion.ts`, the shared `<Canvas>` shell, header and footer, and the flat SVG sticker set. Screenshot the hero area next to the reference and match composition, scale and color closely before moving on.
4. **Static pass.** All sections at full fidelity with no motion, fully responsive, with placeholder data. Use Playwright to screenshot 1440 and 390 for every section. Checkpoint: show me the screenshots.
5. **Signature moments, one section at a time, in page order.** For each section: load `labelbros-motion` plus the relevant GSAP and three skills, build the moment exactly as specified, then the touch, reduced-motion and low-tier variants, then verify. Verifying means: screenshots at 1440×900 and 390×844, plus scroll positions at 0/50/100% of every pin; a check of the console for errors and leftover markers; a quick FPS check with a Playwright trace or `performance.now()` frame sampling during the scrub; and a `design-reviewer` subagent pass on the screenshots. Then fix the findings.
   **Self-critique gate:** score the section 1–10 on (1) fidelity to the reference, (2) clarity and wow of the signature moment, (3) craft (easing, timing, spacing), (4) performance, (5) accessibility. Anything under 8 gets another iteration before you move on. Record the scores in `PROGRESS.md`.
6. **Quote widget logic** with `data/pricing.ts`.
7. **QA.** Lighthouse mobile and desktop, an axe scan (via Playwright), a keyboard-only walkthrough, a reduced-motion walkthrough (emulate `prefers-reduced-motion`), the low-tier path (force it with a `?tier=low` query), and all five breakpoints. Run the `web-design-guidelines` and `vercel-react-best-practices` reviews and fix what affects users.
8. **Handoff.** A README covering how to run it, where to change copy, colors, pricing and models, how the scroll store works, and a list of every `[[PLACEHOLDER]]` still open.
Pause for my review after steps 2, 4 and 5 (after S3, and again after S10).
</workflow>

<output_format>
Before the first tool call of each phase, write one line saying what you're about to do. At each checkpoint, reply with: what you built (short), the screenshot paths, the decisions you made and why (one line each), the self-critique scores, open questions, and the next step. Report evidence (the commands you ran and their key output) rather than claims. At the end, give the run command, the Lighthouse scores, the axe result, the FPS notes, and the open placeholders.
</output_format>
