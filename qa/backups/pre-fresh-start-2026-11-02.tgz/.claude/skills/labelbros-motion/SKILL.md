---
name: labelbros-motion
description: Label Bros homepage design system and scroll choreography. Covers design tokens, the Pinterest reference breakdown, the section-by-section spec, and the exact GSAP/Three.js signature scroll moment for every section. Use whenever building, animating, reviewing or fixing any homepage section, design token, ScrollTrigger, shader uniform or 3D sticker/jar effect in this project.
---

# Label Bros: design system and motion spec

**Direction changed on 2026-11-01.** The look is now `reference/DESIGN-DIRECTION.md` ("Production spec": industrial B2B, Mona Sans, paper/graphite, International Orange, print marks). `reference.md` and the sticker parts of `choreography.md` are history. Keep using `choreography.md` for its global motion engineering rules, but read `slap` as `press` (no overshoot) and take the section list from the direction doc.

Before building or changing a section, read the files you need:
- `reference/DESIGN-DIRECTION.md` (repo root): the current look, page order and signatures. Read this first.
- [reference.md](reference.md): the retired Pinterest reference (history only).
- [tokens.md](tokens.md): colors, fonts, scales and radii. Use only these.
- [choreography.md](choreography.md): global motion rules plus the S0–S10 spec, including each section's signature scroll moment with trigger/start/end/pin/scrub/ease/plugins, Three.js sync, and touch and reduced-motion fallbacks.

Working loop for each section:
1. Re-read that section in choreography.md.
2. Build the static layout first, then the signature moment, then the touch and reduced-motion variants.
3. Screenshot it with the Playwright MCP at 1440×900 and 390×844. For a scroll moment, also capture scroll positions at 0%, 50% and 100% of the pin. Compare against the reference and the spec, fix the gaps, and repeat.
4. Check the console for errors and ScrollTrigger markers left on. Remove `markers: true` before you finish.
