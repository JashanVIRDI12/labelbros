## Design tokens: "Production spec" (current)

The full direction lives in `reference/DESIGN-DIRECTION.md`. The tokens are defined in `src/app/globals.css` `@theme`, and only these values exist.

```css
@theme {
  --color-paper: #f1f0ec;       /* proof paper: page canvas */
  --color-sheet: #fafaf7;       /* raised surfaces on paper */
  --color-white: #ffffff;
  --color-line: #d9d7d1;        /* hairlines on paper */
  --color-guide: rgb(14 15 16 / 0.055); /* column guides */
  --color-ink: #0e0f10;         /* type, 17:1 on paper */
  --color-ink-soft: #5b5d61;    /* secondary text, 5.8:1 on paper */
  --color-graphite: #141516;    /* dark bands */
  --color-graphite-2: #1f2123;  /* raised on dark */
  --color-steel: #9a9da2;       /* secondary text on graphite, 6.7:1 */
  --color-signal: #ff4f00;      /* International Orange: fills, rules, large type, focus. Ink on it 5.8:1 */
  --color-signal-text: #b83700; /* orange for small text on paper, 5.1:1 */
  --color-cyan: #00a3e0; --color-magenta: #e4007c; --color-yellow: #ffe500; /* print marks only */
  --radius-xs: 2px; --radius-sm: 4px; --radius-md: 6px; --radius-lg: 10px; --radius-full: 999px;
  --ease-out: cubic-bezier(.16,1,.3,1);   /* expo.out */
  --ease-press: cubic-bezier(.7,0,.2,1);  /* CSS mirror of the GSAP "press" CustomEase */
}
```

**Font:** Mona Sans only (next/font, variable wdth 75–125, wght 200–900) as `--font-sans`.
**Type utilities:** `type-hero` (H1), `type-h2`, `type-h3`, `type-display` (big lines, size set per use), `type-lede`, `type-label` (UI, sentence case), `type-meta` (12px uppercase, tracking .09em, tabular numerals), `wordmark` (800 at 125% width).
**Type scale (rem):** .75 · .8125 · .875 · .9375 · 1 · 1.125 · 1.25 · 1.5 · 2 · 2.5 · 3 · 4 · 4.5 · 6, plus the fluid `--text-hero` and `--text-h2`.
**Layout:** side margin `clamp(20px, 4.4vw, 80px)`, header 68/76px, no artboard frame. Column guides: 4 on desktop, 2 on mobile (`PaperGuides`).
**Print marks:** `CropMarks`, `RegMark`, `ColorBar` (`src/components/ui/PrintMarks.tsx`).
**Label artwork:** customers' labels may use their own brand and safety colours (`C` in `src/lib/palette.ts`) and the embedded Anton face (`Anton Label`), which the WebGL textures share.
**Iconography:** 1.5px square-cap line icons.
