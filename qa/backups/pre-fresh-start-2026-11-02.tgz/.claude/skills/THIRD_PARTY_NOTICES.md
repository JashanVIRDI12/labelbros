# Third-party skills bundled in .claude/skills

Fetched on 2026-11-01 from the upstream GitHub repositories. Each folder is unmodified. The license text ships inside each folder (LICENSE / LICENSE.txt).

| Skill folders | Source (commit) | License |
|---|---|---|
| frontend-design, webapp-testing | github.com/anthropics/skills @ ca45fc4 | Apache-2.0 (LICENSE.txt in each folder) |
| gsap-core, gsap-timeline, gsap-scrolltrigger, gsap-plugins, gsap-react, gsap-frameworks, gsap-performance, gsap-utils | github.com/greensock/gsap-skills @ aed9cfd | MIT © 2026 GreenSock (LICENSE copied into each folder) |
| threejs-fundamentals, threejs-geometry, threejs-materials, threejs-lighting, threejs-textures, threejs-animation, threejs-loaders, threejs-shaders, threejs-postprocessing, threejs-interaction, threejs-performance, threejs-react-three-fiber, threejs-asset-pipeline | github.com/cloudai-x/threejs-skills @ 0e18186 | MIT © 2026 CloudAI-X (LICENSE copied into each folder) |
| web-design-guidelines, vercel-react-best-practices (upstream folder: skills/react-best-practices) | github.com/vercel-labs/agent-skills @ 1a2c79d | MIT (per repository README; vercel-react-best-practices also declares `license: MIT` in its frontmatter) |
| labelbros-motion | written for this project | Project-owned |

To update, run `bash setup.sh <project-dir> --update` (it re-fetches with `npx skills add … --copy`).
