# Label Bros homepage: build plan

Status: implementation and QA complete 2026-11-01. Phases 1–8 done. Final results and known content/integration limits: `QA.md` and `README.md`. No commits or deployment requested. Source of truth: `reference/pinterest-reference.jpg` and `.claude/skills/labelbros-motion/`.

## (a) Goal in five lines
1. Build the Label Bros homepage in this repo (Next.js 16, React 19, Tailwind v4, GSAP 3.15, Lenis, R3F) as a static `/`.
2. Match the Pinterest reference: warm paper with a 24px grid inside a grey frame, huge Anton caps with stickers inside the type, flat die-cut stickers, five accents, pill chips, cheeky voice.
3. Add depth and motion that make printing tangible: stickers peel, the label gets designed, proofed, printed, cut, wrapped onto a jar, and changes finish, one signature moment per section.
4. Convert: within two scrolls a visitor trusts the quality and clicks "Get instant pricing" (primary) or "Order a sample pack" (secondary).
5. Ship at Awwwards SOTD craft with Lighthouse mobile Perf ≥ 90 / A11y 100, WCAG 2.2 AA, and full touch, reduced-motion and low-tier variants.

## (b) Design direction as I will implement it

**Canvas.** `body` is `--color-frame`. On desktop a fixed, pointer-events-none frame (20px border in `--color-frame`) sits above everything, so the whole site reads as one artboard like the reference, including pinned sections. Inside it the paper (`--color-paper`) carries a 24px graph grid drawn with two `linear-gradient`s in `--color-grid`. Below 1024px the frame shrinks to 8px.

**Tokens.** Exactly the `@theme` block from the brief, replacing shadcn's generated oklch theme. Small text uses `--color-ink-soft` / `--color-orange-text`; `#A1A09E` is decoration only.

**Type.** Anton 400 via `next/font/google` (preloaded, `display: swap`, with an `Arial Narrow` fallback using `adjustFontFallback` to keep CLS near zero). Archivo variable with the `wdth` axis (62–125) for UI and body: labels at `font-stretch: 75%` / 600 / caps, body at 100% / 400. Hero: Anton caps, `line-height: .86`, `letter-spacing: -0.01em`. Our headline lines ("LABEL IT", "LIKE YOU") are longer than the reference's ("STICK", "IT LIKE"), so the hero clamp will likely settle near `clamp(4rem, 10.5vw, 11.5rem)` so the longest line plus its sticker fits 7 columns. I'll tune it against the reference screenshot in Phase 3.

**Sticker set** (one SVG source per sticker, used by both DOM and WebGL):

| Reference | Label Bros version | Fills |
|---|---|---|
| Yellow "THE BEST QUALITY Nº1" badge | Round "PRINTED IN-HOUSE · Nº1" badge, inline after LABEL IT | marigold ring, orange curved text, white center, periwinkle Nº1 |
| Flame | Flame, inline at the start of line 2 | orange outer, marigold core |
| Green "HELLO HELLO" oval with smiley | "FRESH BATCH · FRESH BATCH" oval with smiley | forest, marigold smiley, white curved text |
| Pink "QUALITY PRODUCT" tag | "SMALL BRAND, BIG SHELF" tag over orange blobs | bubblegum, orange, ink |
| Periwinkle striped sphere | Same striped ball | periwinkle, white stripes |
| "LO / VE" bubble letters | "BR / OS" bubble letters | forest on bubblegum |
| Yellow crown on the phone canvas | The hero jar label: a fictional "GOOD HONEY CO." wildflower label (`// COPY:`) | marigold, ink, orange |

All stickers get a 6–8px white die-cut outline and no shadows in 2D. Each sticker is one SVG string used in the DOM and as a WebGL texture. Text stays as editable `<text>`: in the DOM a CSS rule maps it to the next/font Anton face, and for textures `/fonts/anton-latin.woff2` (12 KB) is embedded as a data URI (SVG-as-image can't see document fonts). *(Changed from the outline-script idea: same result, copy stays editable.)*

**One label, one story.** The GOOD HONEY CO. label is designed on the phone (S1), proofed, printed and kiss-cut (S2), wrapped onto the jar (S3), and appears in other finishes (S5). That continuity is what makes the page feel like one object instead of eleven effects.

**3D style.** Flat vocabulary in depth: stickers are thin subdivided planes with the SVG texture (white rim included), satin shading, white liner back face, and a soft blurred shadow quad on the paper plane (no shadow maps). Lighting is one soft key, a hemisphere fill and a drei `<Environment>` built from Lightformers only (no HDR download). Tone mapping is `NeutralToneMapping` so brand colors stay true; at the DOM→WebGL handoff frame the peel shader outputs unlit color so the swap is invisible. Chrome and holo are the only "shiny" moments, because the finish is the point there.

**Components.** React Bits Magnet (CTAs), ShinyText (holo/chrome names), GlareHover (product cards) restyled to tokens. ScrollVelocity is rewritten on GSAP (`quickTo` skewX as specified), so `motion` gets uninstalled. StickerPeel creates its own WebGL2 context, so it is used only on the low-tier S8 path where the main canvas never loads.

## (c) Section by section

Global: one fixed full-viewport `<Canvas frameloop="demand">` above content (pointer-events none, `role="img"` + description), loaded with `next/dynamic({ ssr:false })` inside a client component after first paint. ScrollTriggers write to `lib/scrollStore.ts` and call `invalidate()`; `useFrame` damps toward the store and keeps invalidating until settled. `store.scene` (which 3D moment is in view) hides the canvas and stops rendering when null. On touch the canvas chunk loads only when the visitor scrolls near S3 (IntersectionObserver), so mobile Lighthouse never pays for three. Shaders live as TS template strings (Turbopack is the Next 16 default, so no GLSL loader).

| | Layout | Signature moment | Store keys | Touch | Reduced motion |
|---|---|---|---|---|---|
| **S0 Header** | Anton "LABEL BROS" wordmark, PRODUCTS · MATERIALS · HOW IT WORKS · SAMPLES · DEALS, CART (0), SIGN IN (orange-text), ink pill GET A QUOTE (Magnet). Mobile: wordmark, CART, menu button opening a full-screen paper sheet | none (hide on down / show on up, 0.35s `expo.out`) | none | Same, no Magnet | Always visible |
| **S1 Hero** | Left 7 cols: 3-line H1 with Nº1 badge + flame inline; step row 01 DESIGN / 02 PROOF / 03 STICK; primary + secondary CTA; trust line. Right 5 cols: DOM "Label Studio" phone (orange header UNTITLED / CUSTOM LABEL, dotted canvas with the honey label, chips COLOR · SHAPE · FINISH · SIZE, tab bar TEMPLATES · TEXT · SHAPES · UPLOAD) with 4 stickers breaking its edges | Load: SplitText line masks, inline stickers slap in with squash, phone rises, DrawSVG die-cut line traces the label, 3D stickers drop in. Scroll (pin +100%): inline stickers hand off to WebGL copies and peel (`uPeel` curl around a diagonal hinge), lift and orbit right along a CatmullRom curve; lines slide out sideways through masks; phone eases to center at `scale .92`; camera dollies in 6% | `hero` | No pin, load timeline only, 2D SVG stickers with CSS wobble, tap-to-peel on Nº1 | Static reference composition |
| **S2 How it works** | Pinned stage: left rail 01–04 (active fills ink), step copy (Anton title + line + grey caps caption), phone docked right, a "sticker sheet" of loose artwork pieces left of it | Phone travels in via consecutive scrubbed `Flip.fit` (hero slot → S2 slot); then pin +250% with labels DESIGN (pieces Flip into the label), PROOF ("APPROVED ✓" stamp slaps), PRINT (CMYK/halftone `clip-path: inset()` wipe, clip moment 1/2), STICK (DrawSVG die line, label kiss-cut peels off its liner in 3D and flies down toward S3). Snap to labels | `cut` (0–1), `bridge` (S2 end → S3 pin, keeps the flying label in view while S3 rises under it) | 4 stacked cards, each mini-animation plays once at `top 70%` | 4 static cards in final state |
| **S3 The wrap** | Pinned: left H2 "FLAT ART. / FULL WRAP. / ZERO BUBBLES." (lines at 0.15 / 0.45 / 0.75), 3 proof points, finish chips (radio group); right: 3D jar (procedural `LatheGeometry`, glass-look without transmission + marigold lid) | Pin +200%: the S2 label arrives flat in front of the jar; `uWrap` 0→0.6 bends it around the jar (bend radius lerps from ∞ to jar radius, damp target overshoots with `slap`); 0.6→1 jar turns 300°, key light sweeps, camera pulls back onto a paper-grid shelf. Chips tween material uniforms over 0.6s `expo.out`, arrow-key navigable | `wrap`, `finishWrap` (chip index) | Pin +120%, half segments, no light sweep. Low tier: 3-frame poster crossfade | Wrapped-jar poster, chips swap posters |
| **S4 Products** | Header "PICK YOUR STICK" + Anton counter "01 / 08"; roll core at left edge (SVG, plus 3D cylinder on desktop); long liner strip with die-cut label cards (SVG product illustration, name, one-liner, Anton "FROM [[PRICE]]", arrow link, GlareHover) | Pinned horizontal: track `x` scrubbed over `scrollWidth`; roll rotates `progress * 1440`; each card peels up off the liner via `containerAnimation` (`rotationX -12→0`, `y 24→0`, `slap`, played); the liner shows the die-cut gap underneath | `roll` | Native scroll-snap carousel, same peel on enter via IntersectionObserver | 2/4-column grid |
| **S5 Materials** | Pinned: big 3D die-cut Label Bros sticker left, vertical list of 8 materials right (Anton name, "best for" line, 2px durability icons) | Pin `n × 60%`, snap per material: `finish` 0→7 cross-blends MeshPhysicalMaterial params (roughness, metalness, iridescence, clearcoat), plus injected glitter sparkle and kraft fibre normal. "Clear" is faked by fading the film layer under opaque ink (no transmission pass). Quarter turn per material, damped cursor tilt, `--stage-tint` background layer, ShinyText on holo/chrome | `finish`, `finishIndex`, `pointer` | Pin `n × 35%`, no tilt. Low tier / no WebGL: CSS-gradient 2D sticker swapped with a `clip-path` circle wipe (clip moment 2/2) | Static swatch grid, click swaps poster |
| **S6 Instant quote** | Card: product type chips, size chips + custom W×H, quantity slider with price-break ticks, material chips; summary with big Anton total, per-unit, break hint, sheet-stack illustration, CONTINUE TO UPLOAD. Empty, loading and error states | Play once at `top 65%`: controls start scattered like loose stickers (seeded layout), `Flip.from` snaps them into the grid with `slap`; price counts up; sheet stack scales with quantity | none | Same, shorter stagger | Form simply present |
| **S7 Reviews** | Rating summary, 9–12 review stickers on a "laptop lid" wall, 2 logo marquee rows, 2 mini case studies (illustrated panels until photos arrive) | `ScrollTrigger.batch` slaps review stickers on (`scale 1.5`, random rotation, `slap`); marquee rows skew with velocity (±8°) and reverse with direction | none | Slaps kept, no skew, slower marquees | Static grid, paused marquees |
| **S8 Sample pack** | "FEEL IT BEFORE YOU ORDER", [[SAMPLE_PRICE]], reprint guarantee, free proof; a big sticker over a code card; keyboard PEEL button | Teaser corner lift once at `top 70%`; drag the corner (Draggable + Inertia on a DOM proxy) to drive the 3D `uPeel`; past 55% it releases, reveals and copies [[CODE]] with an aria-live message | `peel` | Same drag via touch | Code visible behind a PEEL button |
| **S9 Final CTA** | Giant "STICK WITH US.", GET INSTANT PRICING, TALK TO A HUMAN ([[EMAIL]] · [[HOURS]]), wavy die-cut bottom edge | Scrub `top 80%`→`center center`: chars press in like a rubber stamp; on completion 14 stickers burst from behind the CTA with Physics2D and settle | none | 8 stickers | Static |
| **S10 Footer** | Ink curtain under the CTA (`position: sticky; bottom: 0`): link columns, newsletter, socials, legal, Reduce motion toggle (persists per visitor) | Reward, not signature: curtain reveal + 3 Draggable stickers with inertia | none | Same | Static, toggle visible |

Device tier: `hardwareConcurrency <= 4`, no WebGL2, `saveData`, or `?tier=low` puts the visitor on posters + 2D fallbacks. Posters are rendered from our own 3D scenes with Playwright and served through `next/image` as AVIF/WebP.

## (d) Risks and mitigations
1. **DOM→WebGL sticker handoff misaligns** (S1, S8). One SVG source for both; pixel→world mapping at z=0 from camera fov/distance, measured on every `refresh`; unlit output at `uPeel = 0`; verify with a screenshot at progress 0 vs 0.01.
2. **Phone travel across two pins** (S1 → S2). A single element can't stay docked when S2 pins, because its parent (the hero) scrolls away. Use the Flip.fit travel for the unpinned stretch, then an invisible handoff to an identical docked phone inside S2's pin on `onEnter` / `onLeaveBack`.
3. **Pin stacking and order** (5 pinned sections). Create triggers in page order, give each section a descending `refreshPriority`, call `ScrollTrigger.sort()` + `refresh()` after fonts, the canvas and posters load. Never pin inside S4's `containerAnimation`.
4. **Scroll length.** Pins total about 13 viewports (S5 alone is 4.8 at 8 materials). Snapping on S2 and S5 keeps it purposeful; if it feels long I'll propose `n × 45%` for S5 (see questions).
5. **Shader complexity** (peel, wrap, finish). Build each in a temporary dev-only `/lab` route with sliders, tune, then wire to the store. `/lab` is deleted before handoff.
6. **Mobile Lighthouse with three on the page.** H1 is the LCP; three loads after first paint on desktop and only on approach to S3 on touch; drei imported per-module; DPR capped; 3D payload < 1.5 MB (everything procedural, no GLB unless supplied).
7. **Transmission cost** for clear/glass. No transmission pass anywhere: glass and clear film are faked with opacity, clearcoat and environment reflections.
8. **SplitText + font swap.** `autoSplit: true` with animations created inside `onSplit()`, and the hero waits for `document.fonts.ready` before the load timeline.
9. **Brand color drift in WebGL.** Neutral tone mapping, sRGB textures, a side-by-side color check at the handoff frame.
10. **Next 16 differences.** Turbopack default (shaders as TS strings), Cache Components on (page stays static, all motion in client islands), `next lint` removed (use `pnpm lint`).

## (e) Open questions
1. **21st.dev components.** `API_KEY_21ST` isn't set, so Pricing Interaction and Motion Footer aren't installed. I recommend building S6 and S10 from scratch against our tokens (less code to strip). Or set the key and I'll install them as bases.
2. **Logo and brand colors.** Use the Anton "LABEL BROS" wordmark until [[LOGO_SVG]] arrives? Any [[BRAND_COLORS_OVERRIDE]]?
3. **Imagery.** No product or case-study photos yet, so S4 cards and S7 case studies use drawn SVG illustrations in the sticker style. OK until real photos arrive?
4. **Pricing.** S6 needs numbers to work. I'll ship a sample price table clearly flagged in the UI as "Sample pricing, not final" until [[REAL_PRICING]] arrives. OK?
5. **Scroll length.** Keep the spec's S5 `n × 60%` (8 materials ≈ 4.8 screens) or trim to `n × 45%`?
6. **Headline.** Keep the default "LABEL IT / 🔥 LIKE YOU / MEAN IT" (Nº1 badge after LABEL IT, flame starting line 2)? It is longer than the reference's lines, so the type will be slightly smaller than the reference's scale.
7. **Domain** for metadata, canonical and OG image?
8. **Git.** Commit at each checkpoint, or leave committing to you?

## Implementation notes (added during phases 3–4)
- **Layout variants** in `globals.css`: `stage:` (desktop, fine pointer, motion allowed) for pinned layouts, `calm:` (OS reduced motion or the footer toggle) for static final states, default = touch. One DOM per section, no layout swap in JS.
- **Paper and curtain:** `<main>` is opaque (fixed 24px grid clipped to it with `clip-path: inset(0)`, plus `overflow-x: clip`); the footer sits behind it (`curtain:sticky bottom-0`) and is revealed through S9's scalloped die-cut edge. Curtain only on lg+ and ≥700px tall, where the footer fits the viewport.
- **3D hand-off hook:** sections hide their 2D stand-in with `[:root[data-three~=wrap]_&]:invisible` (keys: `hero`, `wrap`, `finish`, `sample`) once the canvas has taken over that moment.
- **Display leading 0.9** (spec said .86): Anton's caps are 0.86em tall, so .86 makes lines touch; .9 matches the reference's hairline gap.
- **Dev gotcha:** Tailwind's Turbopack loader sometimes misses edits to `globals.css` in dev; restart `pnpm dev` after CSS changes.

## Checklist

### Phases
- [x] 1. Scaffold (Next 16.4.3, React 19.3, Tailwind 4.3, shadcn, GSAP 3.15, Lenis 1.3, three r187, R3F 9, drei 10, React Bits ×5; dev/tsc/build pass)
- [x] 2. Plan approved
- [x] 3. Foundation: tokens, fonts, frame + grid, `lib/{gsap,lenis,scrollStore,motion}.ts`, canvas shell, header, footer, sticker set; hero vs reference screenshot
- [x] 4. Static pass: all sections, responsive, placeholder data; 1440 + 390 screenshots in `qa/phase4/` (checkpoint captures retained)
- [x] 5. Signature moments S0 → S10, independent reviews, touch / reduced / low-tier variants and recorded self-critique ≥ 8
- [x] 6. Quote widget logic with `data/pricing.ts` and pricing regression tests
- [x] 7. QA: Lighthouse, axe, keyboard, reduced motion, `?tier=low`, 5 breakpoints, Vercel reviews (see QA.md)
- [x] 8. Handoff README + open placeholders

### Per section (static / signature / touch / reduced / low tier / verified / score ≥ 8)
- [x] S0 Header
- [x] S1 Hero
- [x] S2 How it works
- [x] S3 The wrap
- [x] S4 Products
- [x] S5 Materials
- [x] S6 Instant quote
- [x] S7 Reviews
- [x] S8 Sample pack
- [x] S9 Final CTA
- [x] S10 Footer

### Final implementation decisions
- User's request to continue the entire prompt superseded intermediate review pauses; independent design review and the verification loop were retained.
- Below-fold setup is deferred with IntersectionObserver. All static content stays server rendered.
- A ready 3D texture hides a DOM fallback only while its scene owns the viewport. The camera dolly is scoped to the hero; the S2 label bridges into S3.
- Physical finish features remain compiled so entering holo/gloss does not stall the scroll. White die-cut rims and opaque printed ink are separate from the finish film.
- Low-tier sample peel uses a DOM fallback, avoiding a second renderer and supporting devices without WebGL.
- Poster frames are aligned AVIF renders of our own scenes. Quarter-turn finish excursions return face-on at the stops for legibility.
- Quote totals and per-unit calculations respect minimum orders; real pricing and commerce endpoints remain client inputs.
