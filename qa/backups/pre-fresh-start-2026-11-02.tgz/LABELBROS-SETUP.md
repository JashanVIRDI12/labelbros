# Label Bros: Claude Code setup kit

This is a drop-in kit for an empty project folder. It contains no app code; Claude scaffolds the app from `claude-prompt.md`.

```
.claude/skills/        26 project skills (25 third-party + labelbros-motion), see .claude/skills/THIRD_PARTY_NOTICES.md
.claude/agents/        design-reviewer (read-only visual QA subagent)
.claude/settings.json  deny reading .env*, ask before git push, Stop hook runs tsc once the app exists
.mcp.json              Playwright MCP + shadcn MCP
.mcp.21st.optional.json  21st MCP (needs API_KEY_21ST)
CLAUDE.md              project rules: stack, tokens, motion rules, quality bar, verify loop
reference/             pinterest-reference.jpg + DESIGN-REFERENCE.md
claude-prompt.md       the build prompt (paste from <role> down)
setup.sh               installs or refreshes all of the above into any folder
```

Install into the project:
```bash
bash setup.sh /Users/mac/DigiClicks-projects/labelbros            # copies the kit, fetches any missing skills, writes .mcp.json
bash setup.sh /Users/mac/DigiClicks-projects/labelbros --update   # re-fetch the latest skills from GitHub
API_KEY_21ST=... bash setup.sh /Users/mac/DigiClicks-projects/labelbros --with-21st
```
Or just copy the contents of this folder (dotfiles included) into the project root.
