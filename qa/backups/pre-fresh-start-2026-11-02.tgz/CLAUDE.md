# Label Bros homepage

Marketing homepage for Label Bros, a custom label printer for B2B buyers in food & beverage, defense, automotive and industrial. Goal: a modern, premium, Awwwards-level interactive homepage that gets visitors to "Get instant pricing" or "Order a sample kit", and makes clear that customers can send their own artwork or have Label Bros design it. **The current design direction is `reference/DESIGN-DIRECTION.md` ("Production spec", 2026-11-01).** The old Pinterest sticker reference (`reference/pinterest-reference.jpg`, `reference/DESIGN-REFERENCE.md`) is retired and kept as history only.

## Stack (scaffold if missing)
- Next.js 16 App Router, React 19, TypeScript strict, Tailwind CSS v4 (tokens in `src/app/globals.css` `@theme`), shadcn/ui initialised (needed for the React Bits / 21st registries).
- GSAP 3.15 + `@gsap/react` from public npm. Every plugin is free; no `.npmrc` token or private registry. Register plugins once in `lib/gsap.ts`.
- Lenis 1.3 driven by `gsap.ticker`. three r187 + @react-three/fiber 9 + @react-three/drei 10.
- Package manager: pnpm.

## Commands
- Dev: `pnpm dev` (http://localhost:3000)
- Typecheck: `pnpm tsc --noEmit` (a Stop hook also runs it)
- Lint: `pnpm lint` · Build: `pnpm build`
- Lighthouse: `npx lighthouse http://localhost:3000 --preset=desktop --view` (and without the preset for mobile)

## Design and motion source of truth
- `reference/DESIGN-DIRECTION.md` holds the look: tokens, type, page order and each section's signature moment. Read it before touching any section. The `labelbros-motion` skill still holds the motion engineering rules (matchMedia, store, canvas, reduced motion); where its old sticker spec conflicts with the direction doc, the direction doc wins.
- Look: proof paper (#F1F0EC) with column guides, graphite bands, ink type, one signal colour (International Orange #FF4F00), CMY only in print marks (crop marks, registration targets, colour bar). Mona Sans is the only UI font. Controls have 2px corners and buttons carry an orange arrow tab. Sections open with a numbered index rule.
- Customer label artwork (`src/components/labels/labelArt.ts`, `stickers/art.ts`, `stickers/productArt.ts`) may use real brand and safety colours and the embedded Anton face; the site UI may not.
- Avoid: playful stickers, candy palettes and pills; Inter, Roboto, Space Grotesk and system fonts; gradients on UI; glassmorphism; drop shadows; italic accent words in headlines; monospace labels; purple/blue SaaS gradients; bento-grid feature blocks; generic fade-up-on-scroll.

## Motion rules (summary; full rules in the skill)
- One easing language: CustomEase `press` for anything that seats or registers (no overshoot), `expo.out` for reveals, `power2.inOut` for travels, `none` on scrubbed tweens.
- Animate transform and opacity only, plus the listed exceptions (DrawSVG strokes, shader uniforms, clip-path wipes on the hero bench and the low-tier finish plate).
- `gsap.matchMedia()` inside `useGSAP({ scope })` with isDesktop / isTouch / reduceMotion conditions. Clean up everything.
- One shared fixed `<Canvas frameloop="demand">`. ScrollTriggers write progress to `lib/scrollStore.ts` and call `invalidate()`; `useFrame` damps toward it.
- `ScrollTrigger.refresh()` after fonts, the GLB and images load. No `markers: true` in committed code.
- Each section has exactly one signature moment. Reduced motion means a static final state.

## Quality bar
- Awwwards SOTD level, but conversion-first: every animation explains the product or leads to the CTA.
- Lighthouse mobile: Perf ≥ 90, A11y 100, Best Practices ≥ 95, SEO 100. LCP < 2.5s (the LCP is the H1 or a poster, never the canvas), CLS < 0.05, INP < 200ms. 60fps on a recent laptop.
- WCAG 2.2 AA: one H1, real buttons and links, visible focus, keyboard-operable 3D controls, SplitText keeps an `aria-label`, contrast ≥ 4.5:1 (small text: `--color-ink-soft`/`--color-signal-text` on paper, `--color-steel` on graphite). Auto-cycling content (the hero bench) has a pause control.
- Breakpoints to check: 390, 768, 1280, 1440, 1920.

## Verify loop (do this for every section)
1. Run the dev server, then use the Playwright MCP to screenshot 1440×900 and 390×844. For pinned moments, also screenshot at 0/50/100% of the pin.
2. Compare against `reference/DESIGN-DIRECTION.md`, then ask the `design-reviewer` subagent for an independent pass.
3. Fix, re-screenshot, and only then move on. Report what you ran and show the screenshots.

## Content
Real copy, pricing, reviews and the logo are placeholders marked `[[LIKE_THIS]]` in `data/*.ts`. Never invent real-looking numbers or claims; keep them as visible placeholders.

## Safety
Don't push, deploy, or delete files outside this folder without asking. Never read `.env*`.
