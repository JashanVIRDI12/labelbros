# Label Bros

Interactive printing homepage based on `reference/pinterest-reference.jpg`. Next.js 16.4, React 19, Tailwind 4, GSAP, Lenis and a single React Three Fiber canvas. The homepage and icon are statically rendered; all pricing is explicitly sample data.

## Run

Use Node 22.18+ and pnpm (the pinned package manager is in `package.json`).

```sh
pnpm install
pnpm dev
```

Open http://localhost:3000. For production: `pnpm build && pnpm start`. Validate with `pnpm lint`, `pnpm tsc --noEmit` and `pnpm test`.

Before changing Next.js APIs, read the corresponding local guide in `node_modules/next/dist/docs/`, as required by `AGENTS.md`.

## Edit content and appearance

| Change | Location |
| --- | --- |
| Headlines, calls to action, process, sample pack, contact | `src/data/copy.ts` |
| Products, descriptions, destination links | `src/data/products.ts` |
| Finish names, sample durability specs, PBR parameters and CSS swatches | `src/data/materials.ts` |
| Sample price rates, minimum order, quantity breaks and sizes | `src/data/pricing.ts` |
| Placeholder reviews, logos and case studies | `src/data/reviews.ts` |
| Footer links, social URLs and company details | `src/data/footer.ts` |
| Palette, typography, layout and motion variants | `src/app/globals.css` |
| Flat SVG stickers shared with WebGL textures | `src/components/stickers/{art,productArt}.ts` |
| Metadata and self-hosted Anton/Archivo configuration | `src/app/layout.tsx` |

Copy marked `// COPY:` is editorial placeholder copy. Bracketed facts remain visible until confirmed. Leave `SAMPLE_PRICING` enabled until real rates and currency are approved. `quote()` validates sizes/quantities, rounds totals to cents, includes the minimum-order floor in its per-unit price, and calculates savings against the next actual order. Its regression tests cover minimum orders, price breaks, dimensions and invalid inputs.

## Motion and 3D

`src/lib/gsap.ts` registers plugins and the `slap` easing once. Motion components use scoped `useGSAP` and `gsap.matchMedia`; `NearViewport` postpones below-fold setup until the section approaches. This avoids measuring the entire animated page during first-load hydration.

`src/lib/scrollStore.ts` is the bridge between DOM timelines and 3D. ScrollTriggers write progress (`hero`, `cut`, `bridge`, `wrap`, `wrapOut`, `roll`, `finish`, `finishIndex`, `finishWrap`, `peel`) without React renders. `setProgress()` invalidates the demand canvas. `setSceneActive()` tracks active moments and updates `data-scenes`; a DOM fallback only hides when both its texture and scene are ready. R3F frame callbacks damp toward progress and stop requesting frames after settling. Pointer coordinates drive only the material stage.

`CanvasRoot` dynamically imports the one shared scene after first paint on desktop. Touch waits until the visitor approaches Wrap. The canvas stops when the tab is hidden, caps DPR at 2/1.5, and stays absent in low-tier and reduced-motion modes. Texture/geometry/material cleanup and shared texture-cache release run when the scene leaves. Physical finish features stay compiled at negligible zero-effect values to avoid a shader compilation hitch during the first material transition.

Each section has one principal interaction: hero peel, process/phone docking and cut, jar wrap, horizontal product roll, finish morph, quote assembly, review sticker wall, sample peel, CTA stamp/scatter, and footer drag stickers. Finish names and quote fields remain ordinary keyboard controls. Product focus moves its horizontal pin to the focused card. The sample PEEL button duplicates the drag action, announces the result and attempts clipboard copying; a denied clipboard permission leaves the revealed code available to copy manually. Revealed state survives motion toggles.

The footer motion switch persists in localStorage and rebuilds motion scopes. OS reduced motion always wins. Static content remains available without JavaScript. Marquees also have a nearby pause button. Anchor navigation initializes preceding lazy pins before resolving its destination. Footer drag setup waits for a normal-flow marker; keyboard focus reveals the curtain and scrolls it into view.

### Fallbacks and model changes

Use `/?tier=low` to force posters and DOM effects, or `/?tier=high` for QA on a WebGL-capable device. Automatic low tier detects low core count, Save-Data and missing WebGL2. `public/posters/` holds AVIF frames rendered from this project's own jar and material scenes (about 220 KB total). Wrap crossfades aligned flat/half/wrapped frames; materials use a circle wipe and static finish images. Reduced motion shows the final jar and selectable finish posters without pins.

The low-tier sample interaction deliberately uses the same DOM proxy and a 2D peel instead of React Bits' separate WebGL renderer. This keeps it usable on the no-WebGL path. Reviews use GSAP rather than the unused ScrollVelocity/Motion dependency. Finish transitions make a quarter-turn excursion and return face-on at stops so the printed design stays readable.

The jar is procedural `LatheGeometry` in `three/Wrap3D.tsx`. To supply `[[PRODUCT_MODEL_GLB]]`, preserve the DOM anchor and store contract, load compressed geometry in the same shared scene, match the current label radius/proportions, then regenerate posters. No external HDR or model downloads are required today. `shaders/peel.ts` and `shaders/wrap.ts` contain the custom deformation shaders; FinishSticker extends MeshPhysicalMaterial for glitter and kraft fibres. Development-only `?posters` preserves the canvas buffer for poster capture; production does not.

## Scope and open content

This implements the homepage. Commerce, account, upload, legal/help and case-study pages are not part of this route. `/upload`, the `#cart` / `#signin` header destinations, `/artwork-guidelines`, `/shipping`, `/faq`, `/privacy`, `/terms`, social links and case-study destinations need real integrations before launch. The sample CTA currently scrolls to the sample section. Newsletter signup explicitly reports that it is not connected. No payment, signup or upload is simulated.

Open facts and integrations:

- Brand: `[[LOGO_SVG]]`, `[[ONE_LINE_DESCRIPTION]]`, `[[BRAND_COLORS_OVERRIDE]]`, `[[DOMAIN]]`, `[[PRODUCT_MODEL_GLB]]`.
- Copy/defaults: `[[HERO_HEADLINE]]`, `[[STEP_COPY]]`, `[[WRAP_HEADLINE]]`, `[[CTA_HEADLINE]]`. Current defaults were approved in the plan.
- Printing: `[[PROOF_TIME]]`, `[[TURNAROUND]]`, `[[PRINT_SPEC]]`, `[[CLAIM]]`, `[[GUARANTEE_TERMS]]`.
- Catalog: `[[PRODUCTS]]`, `[[PRICE]]`, `[[MATERIALS]]`, `[[MATERIAL_SPECS]]`, `[[REAL_PRICING]]`. Confirm material durability claims before launch.
- Social proof: `[[RATING]]`, `[[REVIEW_COUNT]]`, `[[REVIEWS]]`, `[[LOGOS]]`, `[[NAME]]`, `[[BRAND]]`, `[[CASE_STUDY_1]]`, `[[CASE_STUDY_2]]`, `[[CASE_STUDY_URL]]`.
- Conversion/contact: `[[SAMPLE_PRICE]]`, `[[CODE]]`, `[[EMAIL]]`, `[[HOURS]]`, `[[COMPANY_ADDRESS]]`, `[[NEWSLETTER_ENDPOINT]]`, `[[LINKS]]`, `[[INSTAGRAM_URL]]`, `[[TIKTOK_URL]]`, `[[LINKEDIN_URL]]`.

`[[DOUBLE_BRACKETS]]` in a source comment describes the placeholder syntax, not an additional fact to supply. Add the canonical/domain and final share image when branding is supplied; the current icon is a temporary vector LB monogram.

## Verification

See `QA.md` for final audit scores, frame sampling, keyboard checks and review decisions. Raw reports and desktop/touch/low-tier/reduced-motion screenshots are in ignored `qa/final/`. `PLAN.md` and `PROGRESS.md` preserve the implementation state. No deployment or Git commit was performed.
