# Label Bros homepage

Marketing homepage for Label Bros, a custom label and sticker printer. Goal: a clean, premium, Awwwards-level interactive homepage that gets visitors to "Get instant pricing" or "Order a sample pack". The design follows the client's Pinterest reference (`reference/pinterest-reference.jpg`, described in `reference/DESIGN-REFERENCE.md`).

## Stack (scaffold if missing)
- Next.js 16 App Router, React 19, TypeScript strict, Tailwind CSS v4 (tokens in `app/globals.css` `@theme`), shadcn/ui initialised (needed for the React Bits / 21st registries).
- GSAP 3.15 + `@gsap/react` from public npm. Every plugin is free; no `.npmrc` token or private registry. Register plugins once in `lib/gsap.ts`.
- Lenis 1.3 driven by `gsap.ticker`. three r187 + @react-three/fiber 9 + @react-three/drei 10.
- Package manager: pnpm.

## Commands
- Dev: `pnpm dev` (http://localhost:3000)
- Typecheck: `pnpm tsc --noEmit` (a Stop hook also runs it)
- Lint: `pnpm lint` · Build: `pnpm build`
- Lighthouse: `npx lighthouse http://localhost:3000 --preset=desktop --view` (and without the preset for mobile)

## Design and motion source of truth
- The `labelbros-motion` skill holds the tokens, the reference breakdown, and the S0–S10 section and scroll spec. Load it before touching any section.
- The colors, fonts (Anton display, Archivo variable UI/body) and radii come from the reference. The warm paper background, 01/02/03 step numbers and pill chips are deliberate because they come from the reference, so keep them.
- Avoid: Inter, Roboto, Space Grotesk and system fonts; gradients on UI; glassmorphism; drop shadows on 2D stickers; italic accent words in headlines; monospace labels; purple/blue SaaS gradients; bento-grid feature blocks; generic fade-up-on-scroll.

## Motion rules (summary; full rules in the skill)
- One easing language: CustomEase `slap` for anything that sticks or lands, `expo.out` for reveals, `power2.inOut` for travels, `none` on scrubbed tweens.
- Animate transform and opacity only, plus the listed exceptions (DrawSVG strokes, shader uniforms, two clip-path wipes).
- `gsap.matchMedia()` inside `useGSAP({ scope })` with isDesktop / isTouch / reduceMotion conditions. Clean up everything.
- One shared fixed `<Canvas frameloop="demand">`. ScrollTriggers write progress to `lib/scrollStore.ts` and call `invalidate()`; `useFrame` damps toward it.
- `ScrollTrigger.refresh()` after fonts, the GLB and images load. No `markers: true` in committed code.
- Each section has exactly one signature moment. Reduced motion means a static final state.

## Quality bar
- Awwwards SOTD level, but conversion-first: every animation explains the product or leads to the CTA.
- Lighthouse mobile: Perf ≥ 90, A11y 100, Best Practices ≥ 95, SEO 100. LCP < 2.5s (the LCP is the H1 or a poster, never the canvas), CLS < 0.05, INP < 200ms. 60fps on a recent laptop.
- WCAG 2.2 AA: one H1, real buttons and links, visible focus, keyboard-operable 3D controls, SplitText keeps an `aria-label`, contrast ≥ 4.5:1 (use `--color-ink-soft`/`--color-orange-text` for small text).
- Breakpoints to check: 390, 768, 1280, 1440, 1920.

## Verify loop (do this for every section)
1. Run the dev server, then use the Playwright MCP to screenshot 1440×900 and 390×844. For pinned moments, also screenshot at 0/50/100% of the pin.
2. Compare against `reference/pinterest-reference.jpg` and the spec, then ask the `design-reviewer` subagent for an independent pass.
3. Fix, re-screenshot, and only then move on. Report what you ran and show the screenshots.

## Content
Real copy, pricing, reviews and the logo are placeholders marked `[[LIKE_THIS]]` in `data/*.ts`. Never invent real-looking numbers or claims; keep them as visible placeholders.

## Safety
Don't push, deploy, or delete files outside this folder without asking. Never read `.env*`.
