## The reference (Pinterest pin 1145040274100092660, "Sticker app website: visual exploration" by Екатерина М)

File: `reference/pinterest-reference.jpg` (1200x900). Open it and look at it before you design anything.

**Layout.** A single landing-page artboard sits inside a warm grey frame (#E2E1DD) with about 5% padding. The artboard is warm off-white paper (#F5F4F2) with a faint square graph-paper grid, roughly 24px cells drawn at about 4-5% ink. The page is a two-column split. The left ~55% holds a giant three-line headline with a 3-step row under it. The right ~45% holds a phone mockup of a sticker editor, with flat stickers overlapping its edges. The nav runs across the top: PRODUCTS · TOOLS · SAMPLES · DEALS on the left, CART on the right, and SIGN IN in orange.

**Typography.** The headline "STICK IT 🔥 LIKE IT'S HOT" is set in an ultra-condensed, heavy grotesk (Druk/Tusker style) in all caps, pure black. Leading is about 0.86, tracking is tight, and the cap height is about 12vw. Illustrated stickers sit inline inside the type: a yellow round "THE BEST QUALITY / Nº1" badge tucked after STICK, and an orange-and-yellow flame standing in for a word gap between IT and LIKE. Nav and UI labels use a condensed grotesk at medium weight in caps, about 15-16px. The step row reads 01 DESIGN / 02 ORDER / 03 STICK: tiny step numbers, condensed bold titles at about 22-24px, and small grey caps captions ("CHOOSE FROM OVER 40 STYLES", "WITH 7-DAYS DELIVERY GUARANTEE", "LIKE YOU F*CKIN' MEAN IT").

**Color (sampled from the image).** Ink #0A0A0A · paper #F5F4F2 · frame #E2E1DD · orange #E8641F · marigold #F5BA18 · forest green #0A5E46 · bubblegum pink #F89ABC · periwinkle #565DC5 · caption grey #A1A09E · white #FFFFFF.

**Imagery and illustration.** Everything is flat vector with no gradients and no drop shadows. The stickers are chunky and playful, and most have a white die-cut border. They include: a green oval with "HELLO HELLO" running around a yellow smiley; the yellow Nº1 badge with orange curved text and a periwinkle "Nº1"; a pink rounded tag reading "QUALITY PRODUCT" over orange blobs; a periwinkle striped sphere; bubble letters "LO / VE" in green on pink; and a yellow hand-drawn crown die-cut sticker on the phone canvas with a thick white offset outline.

**UI elements.** The phone has about 36px corners, an orange header bar with a back arrow, "UNTITLED / DIE CUT STICKER" and a save icon, a dotted canvas, a row of pill chips (COLOR · THICKNESS · FILL · ERASER), and an icon tab bar (TEMPLATES · TEXT · SHAPES · DRAW, with DRAW active in orange). The pill chips have thin grey borders.

**Spacing and composition.** Margins are generous, and the headline block nearly touches the left margin. The stickers break the phone's bounding box, giving controlled chaos on a calm grid. The page has very few elements, and the contrast between black and paper is very strong.

**Mood.** Streetwear and zine attitude with clean execution. Confident, cheeky, tactile and fun, but premium and uncluttered. The brand speaks in a casual voice.

**Translating it to Label Bros.** Keep: the paper-and-grid canvas, the ultra-condensed black display type with inline illustrated stickers, the flat sticker vocabulary with white die-cut borders, the five-accent palette, the numbered step row, the pill chips, and the cheeky copy voice. Add: depth and motion. The flat stickers become real 3D die-cut objects that peel, fly, wrap onto products and change finish as you scroll, and the phone "editor" becomes a live label-designer moment.
