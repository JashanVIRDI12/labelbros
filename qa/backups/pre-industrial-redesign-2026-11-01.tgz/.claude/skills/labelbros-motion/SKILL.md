---
name: labelbros-motion
description: Label Bros homepage design system and scroll choreography. Covers design tokens, the Pinterest reference breakdown, the section-by-section spec, and the exact GSAP/Three.js signature scroll moment for every section. Use whenever building, animating, reviewing or fixing any homepage section, design token, ScrollTrigger, shader uniform or 3D sticker/jar effect in this project.
---

# Label Bros: design system and motion spec

Before building or changing a section, read the files you need:
- [reference.md](reference.md): what the client's Pinterest reference looks like and what to keep. The image itself is at `reference/pinterest-reference.jpg`, so open it too.
- [tokens.md](tokens.md): colors, fonts, scales and radii. Use only these.
- [choreography.md](choreography.md): global motion rules plus the S0–S10 spec, including each section's signature scroll moment with trigger/start/end/pin/scrub/ease/plugins, Three.js sync, and touch and reduced-motion fallbacks.

Working loop for each section:
1. Re-read that section in choreography.md.
2. Build the static layout first, then the signature moment, then the touch and reduced-motion variants.
3. Screenshot it with the Playwright MCP at 1440×900 and 390×844. For a scroll moment, also capture scroll positions at 0%, 50% and 100% of the pin. Compare against the reference and the spec, fix the gaps, and repeat.
4. Check the console for errors and ScrollTrigger markers left on. Remove `markers: true` before you finish.
