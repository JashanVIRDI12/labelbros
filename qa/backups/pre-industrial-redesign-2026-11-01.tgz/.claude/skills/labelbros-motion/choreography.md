## Global motion system (applies to every section)

**Stack.** GSAP 3.15 from the public `gsap` package. All plugins are free, with no token or private registry: ScrollTrigger, SplitText, Flip, DrawSVGPlugin, CustomEase, Draggable, InertiaPlugin, Physics2DPlugin, Observer. Use `@gsap/react` `useGSAP()` for every animation scope. Lenis 1.3 handles smooth scroll. three r187 + @react-three/fiber 9 + @react-three/drei 10 render the 3D.

**One easing language.** Use only these, and register them once in `lib/gsap.ts`:
- `CustomEase.create("slap", "M0,0 C0.2,0 0.1,1.12 0.5,1.04 0.75,1 1,1")` is the sticker-landing overshoot. Use it for anything that sticks, lands or snaps.
- `expo.out` for type reveals and UI entrances.
- `power2.inOut` for camera moves and Flip travels.
- `ease: "none"` on every scrubbed tween. The scrub smoothing (`scrub: 1`) supplies the feel.
- Durations: 0.35 (UI), 0.6 (reveals), 0.9 (slaps), 1.2 (hero load). Staggers: 0.04 chars, 0.08 lines, 0.06 cards.

**Rules.**
1. Animate only `transform` and `opacity`. The exceptions are `clip-path` (two moments, marked below), SVG stroke (DrawSVG) and shader uniforms.
2. Wrap every setup in `gsap.matchMedia()` with conditions `{ isDesktop: "(min-width: 1024px) and (pointer: fine)", isTouch: "(max-width: 1023px), (pointer: coarse)", reduceMotion: "(prefers-reduced-motion: reduce)" }`, inside `useGSAP({ scope })`. Never nest `gsap.context()` inside matchMedia. A footer "Reduce motion" toggle sets a `data-reduce-motion` attribute and calls `gsap.matchMediaRefresh()`.
3. Lenis: `new Lenis({ autoRaf: false })`, `lenis.on("scroll", ScrollTrigger.update)`, `gsap.ticker.add(t => lenis.raf(t * 1000))`, `gsap.ticker.lagSmoothing(0)`. Don't create Lenis when `reduceMotion` is true.
4. Call `ScrollTrigger.refresh()` after `document.fonts.ready`, after the GLB and textures load, and after any image-driven layout change. Use SplitText with `autoSplit: true`, create the animation inside `onSplit()` and return it.
5. Create ScrollTriggers top-to-bottom in page order, or set `refreshPriority`. Pinned sections use `pinSpacing: true` and `anticipatePin: 1`. Never pin inside a `containerAnimation`.
6. **Three.js sync.** Use one fixed, full-viewport `<Canvas>` (pointer-events: none, `frameloop="demand"`, `dpr={[1, 2]}`, 1.5 max on touch) shared by every 3D moment. ScrollTriggers write progress into a plain mutable store (`lib/scrollStore.ts`: `{ hero, cut, wrap, finish, finishIndex }`) in `onUpdate` and call `invalidate()`. `useFrame` reads the store and eases toward it with `THREE.MathUtils.damp(current, target, 6, delta)`. GSAP never tweens three objects directly from the DOM tree, which keeps React out of the hot path. Pause rendering when the tab is hidden or no 3D section is in view.
7. No generic fade-ups. Every section gets exactly one signature moment from the list below. Everything else in that section stays still or uses a small `expo.out` reveal, so the signature reads clearly.
8. Device tier: `navigator.hardwareConcurrency <= 4`, no WebGL2, or `saveData` puts the visitor in the low tier. The low tier uses posters (AVIF) plus the 2D fallbacks listed per section.
9. Reduced motion: no Lenis, no pin, no scrub, no parallax and no marquees. Every section renders its final state, with at most a 200ms opacity fade. Information never depends on motion.

## Section-by-section spec with signature scroll moments

### S0. Header
Content: wordmark (logo [[LOGO_SVG]] or Anton wordmark "LABEL BROS"), PRODUCTS · MATERIALS · HOW IT WORKS · SAMPLES · DEALS, CART (count), SIGN IN in `--color-orange-text`, and a pill "GET A QUOTE" in ink.
Motion: the header hides on scroll-down and shows on scroll-up (one ScrollTrigger `onUpdate` with `self.direction`, `yPercent` tween of 0.35s `expo.out`). The CTA pill is magnetic (React Bits Magnet). This is not a signature moment.

### S1. Hero: "Slap-in" on load, "Peel-off" on scroll
Layout: matches the reference. The left 7 columns hold a three-line Anton headline [[HERO_HEADLINE, default: "LABEL IT / 🔥 LIKE YOU / MEAN IT"]]. Two illustrated stickers sit inline in the type: a marigold round "Nº1 / PRINTED IN-HOUSE" badge, and an orange flame (or a custom Label Bros mascot sticker) replacing a word gap. Under it sits the step row: 01 DESIGN "Upload or build your label", 02 PROOF "Free proof in [[PROOF_TIME]]", 03 STICK "Ships in [[TURNAROUND]]". A primary CTA reads "GET INSTANT PRICING", a secondary reads "ORDER A SAMPLE PACK", and a trust line shows [[RATING]] ★ · [[REVIEW_COUNT]] reviews. The right 5 columns hold the "Label Studio" phone (DOM, crisp UI cloned from the reference: orange header "UNTITLED / CUSTOM LABEL", dotted canvas, chips COLOR · SHAPE · FINISH · SIZE, tab bar TEMPLATES · TEXT · SHAPES · UPLOAD). The canvas shows a jar label design. Four or five 3D die-cut stickers float around the phone: a green "HELLO" oval, a pink "QUALITY PRODUCT" tag, a periwinkle striped ball and a "LO/VE" bubble, re-themed with Label Bros words such as "FRESH BATCH" and "SMALL BRAND, BIG SHELF".
- **Load (signature, not scroll), timeline about 1.4s:** headline lines rise through SplitText `mask: "lines"` (`yPercent: 110 → 0`, `expo.out`, stagger 0.08). At 0.35s each inline sticker slaps in (`scale 1.6 → 1`, `rotation ±18 → final`, `slap` ease, 0.9s) with a one-frame squash (`scaleY .9`). The phone rises from `y: 60` (`expo.out`), and a DrawSVG die-cut line traces around the label artwork on the phone canvas (`drawSVG: "0% 0%" → "0% 100%"`, 0.9s). The 3D stickers drop in with damped spring rotation.
- **Scroll (signature): "Peel-off".** `trigger: hero, start: "top top", end: "+=100%", pin: true, scrub: 1`. Over 0→0.5 progress the inline headline stickers peel off the type: a WebGL plane copy of each sticker takes over from the DOM and its `uPeel` uniform goes 0→1 (vertex-shader curl around a diagonal hinge, back face rendered as the white liner). They then lift into 3D space and orbit toward the right. At the same time the headline lines slide out sideways through their masks (line 1 `xPercent: -110`, line 2 `+110`, line 3 `-110`, `ease: "none"`). Over 0.5→1 the phone eases toward the horizontal centre (`xPercent`, `scale .92`). Its full Flip travel into S2 starts once the pin releases (see S2).
- Three sync: `store.hero = self.progress` drives the sticker peel uniforms, their positions along a CatmullRom curve, and a 6% camera dolly-in.
- Touch: no pin. Load timeline only. Stickers in 2D (SVG) with a CSS hover wobble, and a single tap-to-peel on the Nº1 badge.
- Reduced motion: static composition as in the reference, with no 3D motion.

### S2. How it works: "The die-cut" (phone travels in, cut line draws)
Content: 01 DESIGN → 02 PROOF → 03 PRINT → 04 STICK, each with a one-line benefit and a tiny caption in the reference's grey caps style ([[STEP_COPY]]).
- **Scroll (signature):** the hero phone travels into this section with consecutive scrubbed Flips. `Flip.fit(phone, slotEl, { ease: "power2.inOut" })` sits inside a ScrollTrigger timeline: `trigger: "#how", start: "clamp(top bottom)", end: "clamp(top top)", scrub: 1, immediateRender: false`. This is the GSAP "Consecutive Scrub Flips" pattern. Once docked, the section pins (`start: "top top", end: "+=250%", pin: true, scrub: 1`) and one master timeline plays four labelled steps:
  1. DESIGN: artwork elements Flip from a scattered sticker-sheet layout into the label layout on the phone canvas.
  2. PROOF: a proof stamp "APPROVED ✓" slaps on (`slap` ease), the only non-`none` ease inside the scrub, wrapped in its own short sub-tween.
  3. PRINT: the canvas becomes a printed sheet. A halftone/CMYK registration sweep runs as a `clip-path: inset()` wipe (clip-path moment 1 of 2).
  4. STICK: a die-cut path draws around the label (`drawSVG: "0% 100%"`), the kiss-cut label lifts off its liner (3D peel `store.cut`), and it flies out of frame toward S3.
  A left rail shows 01-04 with the active number filling ink, and step copy changes through SplitText line masks. `snap: { snapTo: "labels", duration: { min: .2, max: .6 }, ease: "power1.inOut" }`.
- Touch: no pin. Four stacked cards. Each card's mini-animation (Flip / stamp / wipe / draw) plays once with `toggleActions: "play none none reverse"`, `start: "top 70%"`.
- Reduced motion: four static cards with final-state illustrations.

### S3. "The wrap": a label wraps a 3D jar on scroll
Content: H2 [[WRAP_HEADLINE, default: "FLAT ART. FULL WRAP. ZERO BUBBLES."]], three short proof points (waterproof · scuff-proof · [[CLAIM]]), and finish chips (MATTE · GLOSS · HOLO · CHROME · CLEAR).
- **Scroll (signature):** `trigger: "#wrap", start: "top top", end: "+=200%", pin: true, scrub: 1`. The label that flew out of S2 arrives as a flat plane in front of a 3D jar (default jar; `PRODUCT_MODEL` can be jar | bottle | can, sharing one geometry pipeline). `store.wrap` 0→0.6 drives a `uWrap` vertex uniform that bends the plane around the jar's radius (cylindrical mapping: `angle = (x / width) * uWrap * 2π`, lerped from flat to wrapped, with a tiny overshoot settle using `slap` in the damp target). From 0.6→1 the jar turns 300°, the key light sweeps across the label to show the finish, and the camera pulls back to reveal the jar standing on a paper-grid "shelf". Copy lines enter through SplitText masks at 0.15, 0.45 and 0.75 (labels on the same timeline).
- Finish chips are interactive (not scroll). Clicking tweens material uniforms (roughness, metalness, clearcoat, iridescence, transmission) over 0.6s `expo.out`, with keyboard arrow navigation.
- Touch: pin reduced to `+=120%`, half the geometry segments, no light sweep. Low tier gets a 3-frame AVIF crossfade (flat → half → wrapped).
- Reduced motion: the wrapped jar poster with chips that swap poster images.

### S4. Products: "Label roll unspool" (pinned horizontal)
Content: 6-8 product types [[PRODUCTS: roll labels, product labels, die-cut stickers, sticker sheets, clear labels, holographic, embossed, custom packaging]], each with an image, a one-liner, "FROM [[PRICE]]" set in Anton, and an arrow link.
- **Scroll (signature):** a label roll (SVG roll core at the left edge, plus a 3D cylinder on desktop) unspools a long liner strip across the screen. The product cards are the labels on that liner. `const track = gsap.to(".roll-track", { x: () => -(track.scrollWidth - innerWidth), ease: "none", scrollTrigger: { trigger: "#products", start: "top top", end: () => "+=" + track.scrollWidth, pin: true, scrub: 1, invalidateOnRefresh: true } })`. The roll core rotates in sync (`rotation: progress * 1440`). Each card gets its own ScrollTrigger with `containerAnimation: track, start: "left 60%"`: it peels up off the liner (`rotationX: -12 → 0`, `y: 24 → 0`, `transformOrigin: "50% 100%"`, `slap`, played rather than scrubbed). The liner's backing-paper texture reveals the die-cut gap where each card sat. A progress counter "03 / 08" in Anton follows.
- Touch: native horizontal scroll-snap carousel (`scroll-snap-type: x mandatory`) with the same peel on card enter via IntersectionObserver-driven `gsap.from`. No pin.
- Reduced motion: a regular 2- or 4-column grid.

### S5. Materials and finishes: "Finish morph" (one sticker, every finish)
Content: 6-8 materials [[MATERIALS: matte white, gloss white, clear, holographic, chrome/metallic, kraft, glitter, removable]], each with a name, a "best for" line, and durability icons.
- **Scroll (signature):** a sticky stage. On the left is a big 3D Label Bros sticker (rounded die-cut). On the right is a vertical list of materials. `trigger: "#materials", start: "top top", end: "+=" + (n * 60) + "%", pin: true, scrub: 1, snap: 1 / (n - 1)`. `store.finish` (0→n-1) cross-blends shader parameters between adjacent materials: roughness, metalness, an iridescence thin-film term for holo, transmission for clear, a sparkle-noise layer for glitter, and a paper-fibre normal map for kraft. The sticker tilts toward the cursor (damped) and does a quarter turn per material so the light catches the new finish. The page background tints toward each material's accent (a `--stage-tint` CSS var tween, opacity layer only). The active material name gets React Bits ShinyText for holo and chrome.
- Touch: shorter pin (`n * 35%`), no cursor tilt. Low tier and no-WebGL: a 2D sticker with layered CSS gradients per finish, swapped with a `clip-path` circle wipe (clip-path moment 2 of 2).
- Reduced motion: a static swatch grid. Click a swatch to swap the poster.

### S6. Instant quote: "Sheet assembly"
Content: a mini configurator for product type, size (preset chips + custom W×H), quantity (slider with price-break ticks) and material. It shows a live total, a per-unit price, a break hint ("ADD 250 MORE, SAVE 18%"), and a "CONTINUE TO UPLOAD" CTA. Pricing comes from `data/pricing.ts` [[REAL_PRICING]].
- **Scroll (signature, play once):** on `start: "top 65%"` the configurator's controls start out scattered like loose stickers on a sheet (random x/y/rotation set from a seeded layout). `Flip.from(state, { absolute: true, ease: "slap", duration: .9, stagger: .05 })` snaps them into the form grid. The price counts up from 0 (`textContent` tween with `snap: { textContent: 1 }`, `expo.out`). On quantity change, a tiny stack of sticker sheets beside the price grows or shrinks (`scaleY`, `slap`).
- Touch: same, with a shorter stagger. Reduced motion: the form is simply present.

### S7. Social proof: "Sticker-bomb wall"
Content: rating summary, 9-12 reviews [[REVIEWS]], client logos [[LOGOS]], and 2 mini case studies with photos.
- **Scroll (signature):** reviews are rendered as die-cut stickers (palette fills, white border, slight random rotation). `ScrollTrigger.batch(".review-sticker", { start: "top 85%", onEnter: b => gsap.from(b, { scale: 1.5, rotation: "random(-25,25)", opacity: 0, ease: "slap", duration: .8, stagger: .07 }) })` slaps them onto a "laptop lid" / wall. Below that, two logo marquee rows (React Bits ScrollVelocity) skew with scroll velocity (`gsap.quickTo(row, "skewX", { duration: .4, ease: "power3" })`, value clamped to ±8° from `self.getVelocity() / 300`) and reverse direction with `self.direction`.
- Touch: batch slaps kept, velocity skew off, marquees at slower speed. Reduced motion: a static grid with paused marquees.

### S8. Sample pack + guarantee: "Drag to peel"
Content: "FEEL IT BEFORE YOU ORDER". Sample pack price [[SAMPLE_PRICE]], reprint guarantee, free proof.
- **Signature (interaction, scroll-armed):** a large sticker lies over a discount code [[CODE]]. ScrollTrigger (`start: "top 70%"`) plays a teaser corner lift (`uPeel 0 → .15 → 0`, `slap`) once. The visitor drags the corner (Draggable + InertiaPlugin, `type: "x,y"`, bounded) to peel it, using the 3D peel shader (or React Bits StickerPeel on low tier). Past 55% it releases and the code is revealed and copied with an aria-live confirmation. A keyboard-accessible "PEEL" button does the same.

### S9. Final CTA: "Stamp and scatter"
Content: a giant Anton line [[CTA_HEADLINE, default: "STICK WITH US."]], "GET INSTANT PRICING", and "TALK TO A HUMAN" ([[EMAIL]] · [[HOURS]]).
- **Scroll (signature):** `trigger: "#cta", start: "top 80%", end: "center center", scrub: 1`. The headline letters press down like a rubber stamp (SplitText chars, `scale: 1.25 → 1`, `yPercent: -30 → 0`, stagger 0.03, `ease: "none"`), with ink density rising through an opacity layer. When the scrub completes (`onLeave`/`onScrubComplete`, once), 14 small stickers burst from behind the CTA button with Physics2DPlugin (`physics2D: { velocity: "random(300,600)", angle: "random(200,340)", gravity: 900 }`) and settle on the page edge.
- Touch: same, with 8 stickers. Reduced motion: static.

### S10. Footer: "Curtain + loose stickers"
Content: product, material and help links (artwork guidelines, shipping, FAQ), company info, a newsletter field, socials, legal, and the "Reduce motion" toggle.
Motion: a curtain reveal. The footer is `position: sticky; bottom: 0` under the last section, and the CTA section's bottom edge is a die-cut wavy edge drawn in SVG. Three brand stickers in the footer are Draggable (`bounds: footer`, `inertia: true`). This is a reward rather than a signature moment.
