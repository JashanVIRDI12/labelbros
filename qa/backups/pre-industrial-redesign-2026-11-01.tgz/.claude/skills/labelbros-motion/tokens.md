## Design tokens (derived from the reference)

Define these as CSS variables in `app/globals.css` using Tailwind v4's `@theme`, and use only these values.

```css
@theme {
  /* color */
  --color-paper:    #F5F4F2;  /* page canvas */
  --color-frame:    #E2E1DD;  /* outer frame / alt section bg */
  --color-ink:      #0A0A0A;  /* type, 18:1 on paper */
  --color-ink-soft: #6B6A66;  /* captions; 4.9:1 on paper (the ref's #A1A09E fails AA, use only for decoration) */
  --color-orange:   #E8641F;  /* brand accent; on paper only for text >= 24px or as a fill with ink text (5.9:1) */
  --color-orange-text: #C2470F; /* orange for small text on paper, 4.55:1 */
  --color-marigold: #F5BA18;
  --color-forest:   #0A5E46;  /* white text on it 7.8:1 */
  --color-bubblegum:#F89ABC;
  --color-periwinkle:#565DC5; /* white text on it 5.6:1 */
  --color-white:    #FFFFFF;  /* die-cut borders, phone body */
  --color-grid:     rgb(10 10 10 / 0.05); /* 24px graph-paper lines */

  /* type */
  --font-display: "Anton", "Arial Narrow", sans-serif;          /* headlines, step titles, prices */
  --font-sans:    "Archivo", system-ui, sans-serif;             /* variable: wdth 62-125, wght 100-900 */

  /* radii */
  --radius-chip: 999px;   /* pills, round stickers, primary buttons (the reference uses pills) */
  --radius-card: 20px;
  --radius-phone: 36px;
  --radius-tag: 28px;     /* rounded-rect stickers */

  /* motion */
  --ease-slap:  cubic-bezier(.2,1.4,.4,1);   /* CSS mirror of the GSAP "slap" CustomEase */
  --ease-out:   cubic-bezier(.16,1,.3,1);    /* mirror of expo.out */
}
```

**Fonts (all free on Google Fonts, self-hosted with `next/font/google`):**
- Display: **Anton** (400, the only weight; already ultra-condensed and heavy, the closest free match to the reference's Druk/Tusker-style face). Set it uppercase with `line-height: .86`, `letter-spacing: -0.01em`, and size `clamp(4.25rem, 12.5vw, 13.5rem)` for the hero. Alternative if the client wants more weight range: **Big Shoulders Display 800-900**.
- UI and body: **Archivo** variable with the width axis. Nav, chips and labels use `font-stretch: 75%` at weight 600 in uppercase, 15-16px, `letter-spacing: .01em`, which matches the reference's condensed nav. Body copy uses `font-stretch: 100%` at weight 400, 16-18px, line-height 1.5. Captions use 75% width, weight 500, uppercase, 12px, `letter-spacing: .04em`, in `--color-ink-soft`.

**Type scale (rem):** 0.75 · 0.875 · 1 · 1.125 · 1.5 · 2 · 3 · 4.5 · 7 · fluid hero clamp.
**Spacing scale (4px base):** 4 · 8 · 12 · 16 · 24 · 32 · 48 · 64 · 96 · 128 · 192.
**Grid:** 12 columns, 24px gutter, side margin `clamp(20px, 5vw, 96px)`. On desktop the page sits inside a 16-24px `--color-frame` border like the reference artboard, and the paper canvas carries a 24px CSS-gradient graph grid.
**Stickers:** flat fills from the palette with a 6-8px white die-cut border (SVG stroke or an outline mesh in 3D) and no drop shadows in 2D. In 3D, use only a soft contact shadow.
**Iconography:** thick-stroke (2px) line icons, as in the reference's phone tab bar.
