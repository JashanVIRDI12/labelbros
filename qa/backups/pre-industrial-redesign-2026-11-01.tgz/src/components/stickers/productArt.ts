import { C } from "@/lib/palette";
import type { StickerArt } from "./art";

/** Flat product illustrations for the S4 cards (240×180), same vocabulary as the sticker set. */
const W = C.white;
const FONT = `font-family="Anton"`;

const art = (id: string, label: string, svg: string): StickerArt => ({ id, label, w: 240, h: 180, svg });

export const productArt: Record<string, StickerArt> = {
  roll: art(
    "p-roll",
    "Roll of labels",
    `
    <rect x="92" y="104" width="148" height="46" fill="${C.frame}"/>
    <rect x="112" y="111" width="38" height="32" rx="7" fill="${C.marigold}"/>
    <rect x="160" y="111" width="38" height="32" rx="7" fill="${C.bubblegum}"/>
    <rect x="208" y="111" width="38" height="32" rx="7" fill="${C.periwinkle}"/>
    <circle cx="80" cy="96" r="66" fill="${W}"/>
    <circle cx="80" cy="96" r="60" fill="${C.orange}"/>
    <circle cx="80" cy="96" r="46" fill="none" stroke="${W}" stroke-width="3"/>
    <circle cx="80" cy="96" r="34" fill="none" stroke="${W}" stroke-width="3"/>
    <circle cx="80" cy="96" r="22" fill="${C.paper}" stroke="${C.ink}" stroke-width="4"/>`,
  ),
  product: art(
    "p-product",
    "Bottle with a label",
    `
    <path d="M104 18h32v26c0 8 18 14 18 34v86a8 8 0 0 1-8 8h-52a8 8 0 0 1-8-8V78c0-20 18-26 18-34z" fill="${W}"/>
    <path d="M108 24h24v22c0 7 16 13 16 32v82a6 6 0 0 1-6 6h-44a6 6 0 0 1-6-6V78c0-19 16-25 16-32z" fill="${C.forest}"/>
    <rect x="104" y="14" width="32" height="16" rx="4" fill="${C.ink}"/>
    <rect x="86" y="92" width="68" height="54" rx="6" fill="${C.marigold}"/>
    <text ${FONT} x="120" y="118" font-size="17" text-anchor="middle" fill="${C.ink}">GOOD</text>
    <text ${FONT} x="120" y="136" font-size="12" text-anchor="middle" fill="${C.ink}">SODA CO.</text>`,
  ),
  diecut: art(
    "p-diecut",
    "Die-cut star sticker",
    `
    <path d="M120 16l22 40 44-6-26 36 26 36-44-6-22 40-22-40-44 6 26-36-26-36 44 6z" fill="${W}" stroke="${W}" stroke-width="14" stroke-linejoin="round"/>
    <path d="M120 16l22 40 44-6-26 36 26 36-44-6-22 40-22-40-44 6 26-36-26-36 44 6z" fill="${C.bubblegum}"/>
    <text ${FONT} x="120" y="106" font-size="40" text-anchor="middle" fill="${C.ink}">HI!</text>`,
  ),
  sheet: art(
    "p-sheet",
    "Sticker sheet",
    `
    <rect x="58" y="10" width="124" height="160" rx="10" fill="${W}"/>
    <circle cx="90" cy="46" r="20" fill="${C.marigold}"/>
    <rect x="124" y="28" width="38" height="36" rx="8" fill="${C.periwinkle}"/>
    <path d="M90 80l8 14 16 2-12 11 3 16-15-8-15 8 3-16-12-11 16-2z" fill="${C.orange}"/>
    <ellipse cx="143" cy="98" rx="20" ry="16" fill="${C.forest}"/>
    <rect x="72" y="128" width="40" height="28" rx="14" fill="${C.bubblegum}"/>
    <circle cx="143" cy="142" r="15" fill="${C.ink}"/>
    <g fill="none" stroke="${C.frame}" stroke-width="2"><circle cx="90" cy="46" r="24"/><rect x="120" y="24" width="46" height="44" rx="11"/><ellipse cx="143" cy="98" rx="24" ry="20"/><circle cx="143" cy="142" r="19"/></g>`,
  ),
  clear: art(
    "p-clear",
    "Jar with a clear label",
    `
    <rect x="78" y="14" width="84" height="24" rx="6" fill="${C.ink}"/>
    <path d="M72 46h96a10 10 0 0 1 10 10v104a10 10 0 0 1-10 10H72a10 10 0 0 1-10-10V56a10 10 0 0 1 10-10z" fill="${C.orange}"/>
    <path d="M72 46h96a10 10 0 0 1 10 10v20H62V56a10 10 0 0 1 10-10z" fill="${C.paper}" opacity=".55"/>
    <rect x="78" y="88" width="84" height="54" rx="6" fill="none" stroke="${W}" stroke-width="2" stroke-dasharray="5 4"/>
    <text ${FONT} x="120" y="116" font-size="20" text-anchor="middle" fill="${W}">RAW</text>
    <text ${FONT} x="120" y="134" font-size="12" text-anchor="middle" fill="${W}">HONEY · 12 OZ</text>
    <rect x="70" y="56" width="6" height="96" rx="3" fill="${W}" opacity=".6"/>`,
  ),
  holo: art(
    "p-holo",
    "Holographic sticker",
    `
    <defs><clipPath id="holo-c"><rect x="44" y="24" width="152" height="132" rx="30"/></clipPath></defs>
    <rect x="36" y="16" width="168" height="148" rx="38" fill="${W}"/>
    <g clip-path="url(#holo-c)">
      <rect x="0" y="0" width="240" height="180" fill="${C.periwinkle}"/>
      <path d="M-20 70L90-40h34L4 80z" fill="${C.bubblegum}"/>
      <path d="M10 120L150-20h28L28 140z" fill="${W}" opacity=".85"/>
      <path d="M50 190L240 0h30L80 200z" fill="${C.marigold}"/>
      <path d="M110 200L270 40h22L130 210z" fill="${C.bubblegum}"/>
    </g>
    <text ${FONT} x="120" y="104" font-size="34" text-anchor="middle" fill="${C.ink}">HOLO</text>`,
  ),
  emboss: art(
    "p-emboss",
    "Embossed label",
    `
    <rect x="30" y="34" width="180" height="112" rx="16" fill="${W}"/>
    <rect x="38" y="42" width="164" height="96" rx="11" fill="${C.forest}"/>
    <g ${FONT} font-size="44" text-anchor="middle">
      <text x="122" y="111" fill="${C.ink}">RAISED</text>
      <text x="120" y="108" fill="${C.marigold}">RAISED</text>
    </g>`,
  ),
  pack: art(
    "p-pack",
    "Box with a round label",
    `
    <path d="M44 60l76-34 76 34v84l-76 30-76-30z" fill="${C.frame}"/>
    <path d="M44 60l76 32 76-32-76-34z" fill="${W}"/>
    <path d="M120 92v82l76-30V60z" fill="${C.frame}"/>
    <path d="M120 92v82l76-30V60z" fill="${C.ink}" opacity=".08"/>
    <path d="M44 60l76 32v82l-76-30z" fill="${C.frame}"/>
    <circle cx="82" cy="122" r="24" fill="${W}"/>
    <circle cx="82" cy="122" r="20" fill="${C.orange}"/>
    <text ${FONT} x="82" y="128" font-size="15" text-anchor="middle" fill="${W}">LB</text>`,
  ),
};

/** The S5 hero sticker: scalloped die-cut badge. Base shape (takes the finish) + ink layer (stays). */
const scallop = (() => {
  const n = 18;
  const cx = 160;
  const cy = 160;
  const rOut = 150;
  const rIn = 138;
  const pts: string[] = [];
  for (let i = 0; i < n * 2; i++) {
    const a = (Math.PI * i) / n - Math.PI / 2;
    const r = i % 2 === 0 ? rOut : rIn;
    pts.push(`${(cx + r * Math.cos(a)).toFixed(1)} ${(cy + r * Math.sin(a)).toFixed(1)}`);
  }
  return `M${pts.join("L")}Z`;
})();

export const finishSticker = {
  w: 320,
  h: 320,
  shape: scallop,
  ink: `
  <circle cx="160" cy="160" r="100" fill="none" stroke="${C.ink}" stroke-width="3"/>
  <defs><path id="fs-bottom" d="M36 160A124 124 0 0 0 284 160"/></defs>
  <g ${FONT} fill="${C.ink}" text-anchor="middle">
    <text x="160" y="154" font-size="70" letter-spacing="1">LABEL</text>
    <text x="160" y="230" font-size="70" letter-spacing="1">BROS</text>
  </g>
  <text ${FONT} font-size="15" letter-spacing="3" fill="${C.ink}"><textPath href="#fs-bottom" startOffset="50%" text-anchor="middle">PEEL · STICK · REPEAT</textPath></text>`,
};
