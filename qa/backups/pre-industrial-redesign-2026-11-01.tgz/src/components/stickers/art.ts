import { C } from "@/lib/palette";

/**
 * The flat sticker set. Each sticker is one SVG string used twice: inline in the DOM
 * (via <Sticker>) and rasterised as a WebGL texture (three/stickerTexture.ts), so the
 * 2D and 3D versions always match. Text uses font-family="Anton": in the DOM a CSS rule
 * maps it to the next/font face, in textures the font is embedded as a data URI.
 * Every sticker carries a white die-cut border and no shadows.
 */
export type StickerArt = {
  id: string;
  /** accessible name when the sticker carries meaning */
  label: string;
  w: number;
  h: number;
  svg: string;
};

const W = C.white;
const FONT = `font-family="Anton"`;

// COPY: sticker words are placeholder voice copy.

export const no1Badge: StickerArt = {
  id: "no1",
  label: "Printed in-house, number one sticker",
  w: 220,
  h: 220,
  svg: `
  <defs>
    <path id="no1-top" d="M38 110 A72 72 0 0 1 182 110"/>
    <path id="no1-bot" d="M24 110 A86 86 0 0 0 196 110"/>
  </defs>
  <circle cx="110" cy="110" r="107" fill="${W}"/>
  <circle cx="110" cy="110" r="100" fill="${C.marigold}"/>
  <circle cx="110" cy="110" r="52" fill="${W}"/>
  <text ${FONT} font-size="21" letter-spacing="1.6" fill="${C.orange}"><textPath href="#no1-top" startOffset="50%" text-anchor="middle">PRINTED IN-HOUSE</textPath></text>
  <text ${FONT} font-size="15" letter-spacing="2.4" fill="${C.orange}"><textPath href="#no1-bot" startOffset="50%" text-anchor="middle">· LABEL BROS ·</textPath></text>
  <text ${FONT} x="110" y="128" font-size="50" text-anchor="middle" fill="${C.periwinkle}">Nº1</text>`,
};

const flameOuter =
  "M84 10C92 40 124 58 138 92C152 124 150 158 128 178C114 190 98 194 80 194C58 194 34 186 22 164C8 138 14 108 30 88C34 104 42 114 54 116C46 82 58 40 84 10Z";
const flameInner =
  "M84 92C96 116 118 130 118 158C118 176 104 186 84 186C64 186 50 176 50 160C50 142 62 132 68 118C72 130 78 136 88 134C82 122 80 108 84 92Z";

export const flame: StickerArt = {
  id: "flame",
  label: "Flame sticker",
  w: 160,
  h: 204,
  svg: `
  <path d="${flameOuter}" fill="${W}" stroke="${W}" stroke-width="14" stroke-linejoin="round"/>
  <path d="${flameOuter}" fill="${C.orange}"/>
  <path d="${flameInner}" fill="${C.marigold}"/>`,
};

export const freshBatch: StickerArt = {
  id: "fresh",
  label: "Fresh batch smiley sticker",
  w: 200,
  h: 250,
  svg: `
  <defs>
    <path id="fresh-ring" d="M38 125A62 86 0 1 1 162 125A62 86 0 1 1 38 125"/>
  </defs>
  <ellipse cx="100" cy="125" rx="88" ry="112" fill="${W}"/>
  <ellipse cx="100" cy="125" rx="81" ry="105" fill="${C.forest}"/>
  <text ${FONT} font-size="19" fill="${W}"><textPath href="#fresh-ring" textLength="462" lengthAdjust="spacing">FRESH BATCH · FRESH BATCH · FRESH BATCH ·</textPath></text>
  <ellipse cx="86" cy="114" rx="5" ry="8" fill="${C.marigold}"/>
  <ellipse cx="114" cy="114" rx="5" ry="8" fill="${C.marigold}"/>
  <path d="M78 134Q100 156 122 134" fill="none" stroke="${C.marigold}" stroke-width="7" stroke-linecap="round"/>`,
};

export const smallBrandTag: StickerArt = {
  id: "tag",
  label: "Small brand, big shelf sticker",
  w: 260,
  h: 170,
  svg: `
  <rect x="4" y="4" width="252" height="162" rx="32" fill="${W}"/>
  <rect x="12" y="12" width="236" height="146" rx="25" fill="${C.bubblegum}"/>
  <ellipse cx="86" cy="85" rx="31" ry="52" fill="${C.orange}"/>
  <ellipse cx="130" cy="85" rx="31" ry="52" fill="${C.orange}"/>
  <ellipse cx="174" cy="85" rx="31" ry="52" fill="${C.orange}"/>
  <g transform="rotate(-7 130 85)" ${FONT} fill="${C.ink}" text-anchor="middle">
    <text x="130" y="82" font-size="27">SMALL BRAND,</text>
    <text x="130" y="112" font-size="27">BIG SHELF</text>
  </g>`,
};

export const stripedBall: StickerArt = {
  id: "ball",
  label: "Striped ball sticker",
  w: 200,
  h: 200,
  svg: `
  <defs><clipPath id="ball-clip"><circle cx="100" cy="100" r="88"/></clipPath></defs>
  <circle cx="100" cy="100" r="96" fill="${W}"/>
  <circle cx="100" cy="100" r="88" fill="${C.periwinkle}"/>
  <g clip-path="url(#ball-clip)" transform="rotate(24 100 100)" fill="none" stroke="${W}" stroke-width="6">
    <line x1="100" y1="0" x2="100" y2="200"/>
    <ellipse cx="100" cy="100" rx="32" ry="90"/>
    <ellipse cx="100" cy="100" rx="62" ry="90"/>
    <ellipse cx="100" cy="100" rx="86" ry="90"/>
  </g>`,
};

const brosText = (attrs: string) => `
  <g ${FONT} font-size="88" text-anchor="middle" letter-spacing="7" ${attrs}>
    <text x="98" y="98">BR</text>
    <text x="98" y="192">OS</text>
  </g>`;

export const brosBubble: StickerArt = {
  id: "bros",
  label: "Bros bubble letter sticker",
  w: 196,
  h: 222,
  svg:
    brosText(`fill="${W}" stroke="${W}" stroke-width="40" stroke-linejoin="round"`) +
    brosText(`fill="${C.bubblegum}" stroke="${C.bubblegum}" stroke-width="26" stroke-linejoin="round"`) +
    brosText(`fill="${C.forest}" stroke="${C.forest}" stroke-width="3" stroke-linejoin="round"`),
};

const hex = (cx: number, cy: number, r: number) => {
  const pts = Array.from({ length: 6 }, (_, i) => {
    const a = (Math.PI / 3) * i + Math.PI / 6;
    return `${(cx + r * Math.cos(a)).toFixed(1)},${(cy + r * Math.sin(a)).toFixed(1)}`;
  });
  return `<polygon points="${pts.join(" ")}"/>`;
};

/**
 * The one label that travels the page: designed (S1), printed and cut (S2), wrapped (S3).
 * Built from a blank base plus artwork pieces, so S2 can fly the pieces onto the base.
 * Each piece keeps the label's coordinates; `box` is its crop inside the 480×200 label.
 */
export const HONEY = { w: 480, h: 200 };

const honeyBase = `
  <rect x="4" y="4" width="472" height="192" rx="24" fill="${W}"/>
  <rect x="12" y="12" width="456" height="176" rx="17" fill="${C.marigold}"/>
  <rect x="24" y="24" width="432" height="152" rx="10" fill="none" stroke="${C.ink}" stroke-width="3"/>`;

export const honeyPieces = [
  {
    id: "comb",
    box: { x: 58, y: 58, w: 86, h: 82 },
    svg: `<g fill="${C.orange}">${hex(84, 84, 19)}${hex(119, 84, 19)}${hex(101.5, 114, 19)}</g>
  <path d="M101.5 102c5 7 8 11 8 16a8 8 0 0 1-16 0c0-5 3-9 8-16z" fill="${C.ink}"/>`,
  },
  {
    id: "title",
    box: { x: 158, y: 40, w: 296, h: 62 },
    svg: `<text ${FONT} x="164" y="96" font-size="58" letter-spacing="-0.5" fill="${C.ink}">GOOD HONEY</text>`,
  },
  {
    id: "sub",
    box: { x: 158, y: 108, w: 290, h: 34 },
    svg: `<text ${FONT} x="164" y="136" font-size="27" letter-spacing="1.2" fill="${C.forest}">CO. · RAW WILDFLOWER</text>`,
  },
  {
    id: "small",
    box: { x: 158, y: 144, w: 200, h: 22 },
    svg: `<text ${FONT} x="164" y="160" font-size="14" letter-spacing="1.4" fill="${C.ink}">SMALL BATCH · 12 OZ</text>`,
  },
] as const;

export const honeyBlank: StickerArt = {
  id: "honey-blank",
  label: "Blank label template",
  w: HONEY.w,
  h: HONEY.h,
  svg: honeyBase,
};

export const honeyLabel: StickerArt = {
  id: "honey",
  label: "Good Honey Co. wildflower honey label",
  w: HONEY.w,
  h: HONEY.h,
  svg: honeyBase + honeyPieces.map((p) => p.svg).join(""),
};

/** The label's artwork without its base: laid over honeyBlank so the art can fade or swap on its own. */
export const honeyArtOnly: StickerArt = {
  id: "honey-art",
  label: "Good Honey Co. label artwork",
  w: HONEY.w,
  h: HONEY.h,
  svg: honeyPieces.map((p) => p.svg).join(""),
};

/** S2 PROOF stamp. */
export const approvedStamp: StickerArt = {
  id: "approved",
  label: "Approved",
  w: 240,
  h: 96,
  svg: `
  <rect x="6" y="6" width="228" height="84" rx="14" fill="${W}" opacity=".9"/>
  <rect x="10" y="10" width="220" height="76" rx="11" fill="none" stroke="${C.forest}" stroke-width="5"/>
  <text ${FONT} x="26" y="66" font-size="44" letter-spacing="2" fill="${C.forest}">APPROVED</text>
  <path d="M190 48l10 11 20-24" fill="none" stroke="${C.forest}" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>`,
};

/** S8: the big sticker that hides the discount code. */
export const peelMe: StickerArt = {
  id: "peel",
  label: "Peel me sticker",
  w: 300,
  h: 300,
  svg: `
  <defs><path id="peel-ring" d="M44 150A106 106 0 0 1 256 150"/></defs>
  <circle cx="150" cy="150" r="148" fill="${W}"/>
  <circle cx="150" cy="150" r="140" fill="${C.bubblegum}"/>
  <circle cx="150" cy="150" r="140" fill="none" stroke="${C.ink}" stroke-width="3" stroke-dasharray="2 9" stroke-linecap="round"/>
  <text ${FONT} font-size="20" letter-spacing="3" fill="${C.ink}"><textPath href="#peel-ring" startOffset="50%" text-anchor="middle">SECRET CODE INSIDE</textPath></text>
  <g ${FONT} fill="${C.ink}" text-anchor="middle">
    <text x="150" y="176" font-size="92" letter-spacing="1">PEEL</text>
    <text x="150" y="236" font-size="48" letter-spacing="2">ME</text>
  </g>
  <path d="M232 206l18 18m0 0v-16m0 16h-16" fill="none" stroke="${C.ink}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>`,
};

export const heroStickers = { no1Badge, flame, freshBatch, smallBrandTag, stripedBall, brosBubble, honeyLabel };
