import type { StickerArt } from "./art";

type Props = {
  art: StickerArt;
  className?: string;
  style?: React.CSSProperties;
  /** decorative stickers stay hidden from assistive tech */
  decorative?: boolean;
};

/** Inline SVG sticker. Same source string as the WebGL texture. */
export function Sticker({ art, className, style, decorative = true }: Props) {
  return (
    <svg
      data-sticker={art.id}
      viewBox={`0 0 ${art.w} ${art.h}`}
      className={className}
      style={style}
      role={decorative ? undefined : "img"}
      aria-hidden={decorative ? true : undefined}
      aria-label={decorative ? undefined : art.label}
      focusable="false"
      dangerouslySetInnerHTML={{ __html: art.svg }}
    />
  );
}
