/** Fixed grey frame over everything (desktop only, --frame is 0 on mobile), like the reference artboard. */
export function PageFrame() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-50"
      style={{ boxShadow: "inset 0 0 0 var(--frame) var(--color-frame)" }}
    />
  );
}

/**
 * The paper: one fixed 24px grid, clipped to <main> by main's clip-path. Pinned sections
 * never show a seam, and <main> stays opaque so the footer can sit behind it as a curtain.
 */
export function PaperGrid() {
  return <div aria-hidden="true" className="paper-grid fixed inset-0 -z-10" />;
}
