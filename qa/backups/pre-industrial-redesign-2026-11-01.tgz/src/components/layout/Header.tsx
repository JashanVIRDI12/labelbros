"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Magnet from "@/components/ui/Magnet";
import { PillLink } from "@/components/ui/Pill";
import { brand, cta, nav } from "@/data/copy";
import { gsap, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { getLenis, scrollToTarget } from "@/lib/lenis";
import { MQ, motionFlags } from "@/lib/motion";
import { cn } from "@/lib/utils";

const CART_COUNT = 0;

export function Header() {
  const headerRef = useRef<HTMLElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);
  // the magnetic CTA must not tug a hidden header back into view
  const [shown, setShown] = useState(true);
  const openRef = useRef(open);
  useEffect(() => {
    openRef.current = open;
  }, [open]);

  // S0: hide on scroll down, show on scroll up. Not a signature moment.
  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ, (ctx) => {
        if (motionFlags(ctx.conditions).reduceMotion) return;
        let hidden = false;
        const set = (hide: boolean) => {
          if (hide === hidden) return;
          hidden = hide;
          setShown(!hide);
          gsap.to(headerRef.current, { yPercent: hide ? -100 : 0, duration: 0.35, ease: "expo.out", overwrite: true });
        };
        ScrollTrigger.create({
          start: 0,
          end: "max",
          onUpdate: (self) => {
            // stay visible near the top, with the menu open, or while focus is inside the header
            if (openRef.current || self.scroll() < 160 || headerRef.current?.contains(document.activeElement)) return set(false);
            set(self.direction === 1);
          },
        });
        // keyboard users tabbing into a hidden header bring it back
        const reveal = () => set(false);
        headerRef.current?.addEventListener("focusin", reveal);
        return () => {
          headerRef.current?.removeEventListener("focusin", reveal);
          gsap.killTweensOf(headerRef.current);
          gsap.set(headerRef.current, { yPercent: 0 });
          setShown(true);
        };
      });
    },
    { scope: headerRef },
  );

  const close = useCallback(() => {
    setOpen(false);
    menuButtonRef.current?.focus();
  }, []);

  // Menu links: close first (restores scrolling), then scroll on the next frame.
  const go = (href: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    close();
    requestAnimationFrame(() => scrollToTarget(href));
  };

  useEffect(() => {
    if (!open) return;
    const lenis = getLenis();
    lenis?.stop();
    document.documentElement.style.overflow = "hidden";
    // the page behind the open menu can't be reached with Tab
    const behind = [document.getElementById("main"), document.querySelector("footer")].filter(Boolean) as HTMLElement[];
    behind.forEach((el) => (el.inert = true));
    menuRef.current?.querySelector<HTMLElement>("a")?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    return () => {
      lenis?.start();
      document.documentElement.style.overflow = "";
      behind.forEach((el) => (el.inert = false));
      window.removeEventListener("keydown", onKey);
    };
  }, [open, close]);

  return (
    <>
    <header
      ref={headerRef}
      className="paper-grid fixed z-40 flex items-center"
      style={{
        top: "var(--frame)",
        left: "var(--frame)",
        right: "var(--frame)",
        height: "var(--header-h)",
        paddingInline: "var(--margin)",
        backgroundPosition: "0 0",
      }}
    >
      <a href="#top" className="type-display mr-10 whitespace-nowrap text-[1.75rem] leading-none tracking-[0.01em]" aria-label={`${brand.name} home`}>
        {brand.wordmark}
      </a>

      <nav aria-label="Primary" className="hidden lg:block">
        <ul className="flex items-center gap-8">
          {nav.map((item) => (
            <li key={item.label}>
              <a href={item.href} className="type-label inline-flex h-11 items-center text-16 decoration-2 underline-offset-[6px] hover:underline">
                {item.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>

      <div className="ml-auto flex items-center gap-6 lg:gap-8">
        <a href="#quote" className="type-label inline-flex h-11 items-center whitespace-nowrap text-16 decoration-2 underline-offset-[6px] hover:underline">
          Cart ({CART_COUNT})
        </a>
        <a
          href="#signin"
          className="type-label hidden h-11 items-center text-16 text-orange-text decoration-2 underline-offset-[6px] hover:underline lg:inline-flex"
        >
          Sign in
        </a>
        <span className="hidden lg:inline-block">
          <Magnet padding={40} magnetStrength={3} disabled={!shown}>
            <PillLink href={cta.quote.href} size="md">
              {cta.quote.label}
            </PillLink>
          </Magnet>
        </span>
        <button
          ref={menuButtonRef}
          type="button"
          className="type-label inline-flex h-11 items-center gap-2 text-16 lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? "Close" : "Menu"}
          <span aria-hidden="true" className="relative block h-3 w-5">
            <span className={cn("absolute left-0 h-0.5 w-5 bg-ink transition-transform", open ? "top-[5px] rotate-45" : "top-0")} />
            <span className={cn("absolute left-0 h-0.5 w-5 bg-ink transition-transform", open ? "top-[5px] -rotate-45" : "top-2.5")} />
          </span>
        </button>
      </div>

    </header>
    <div
      id="mobile-menu"
      ref={menuRef}
      hidden={!open}
      className="paper-grid fixed inset-x-0 bottom-0 z-40 overflow-y-auto px-[var(--margin)] pb-10 lg:hidden"
      style={{ top: "var(--header-h)", backgroundPosition: "0 0" }}
    >
      <nav aria-label="Mobile">
        <ul className="flex flex-col gap-2 pt-6">
          {nav.map((item) => (
            <li key={item.label}>
              <a href={item.href} onClick={go(item.href)} className="type-display block py-1 text-72">
                {item.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
      <div className="mt-8 flex flex-col gap-3">
        <PillLink href={cta.primary.href} onClick={go(cta.primary.href)} arrow>
          {cta.primary.label}
        </PillLink>
        <PillLink href="#signin" onClick={go("#signin")} variant="outline">
          Sign in
        </PillLink>
      </div>
    </div>
    </>
  );
}
