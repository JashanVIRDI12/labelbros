"use client";

import { useEffect } from "react";
import { ScrollTrigger } from "@/lib/gsap";
import { scrollToTarget, startLenis, stopLenis } from "@/lib/lenis";
import { MQ, REDUCE_EVENT, prefersReducedMotion } from "@/lib/motion";

/** Starts Lenis unless motion is reduced (OS setting or footer toggle), and refreshes after fonts. */
export function SmoothScroll() {
  useEffect(() => {
    const mq = window.matchMedia(MQ.reduceMotion);
    const sync = () => (prefersReducedMotion() ? stopLenis() : startLenis());
    sync();
    mq.addEventListener("change", sync);
    window.addEventListener(REDUCE_EVENT, sync);

    const anchor = (event: MouseEvent) => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const link = (event.target as Element).closest<HTMLAnchorElement>('a[href^="#"]');
      const hash = link?.getAttribute("href");
      if (!hash || hash === "#main" || !document.getElementById(hash.slice(1))) return;
      event.preventDefault();
      void scrollToTarget(hash);
    };
    const hash = () => { if (window.location.hash) void scrollToTarget(window.location.hash); };
    document.addEventListener("click", anchor);
    window.addEventListener("hashchange", hash);
    const initialHash = requestAnimationFrame(hash);
    let alive = true;
    document.fonts.ready.then(() => alive && ScrollTrigger.refresh());

    return () => {
      alive = false;
      cancelAnimationFrame(initialHash);
      document.removeEventListener("click", anchor);
      window.removeEventListener("hashchange", hash);
      mq.removeEventListener("change", sync);
      window.removeEventListener(REDUCE_EVENT, sync);
      stopLenis();
    };
  }, []);

  return null;
}
