"use client";

import { useId, useState, useSyncExternalStore } from "react";
import { FooterMotion } from "@/components/sections/motion/FooterMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { flame, no1Badge, stripedBall } from "@/components/stickers/art";
import { brand } from "@/data/copy";
import { company, footerColumns, socials } from "@/data/footer";
import { gsap } from "@/lib/gsap";
import { REDUCE_EVENT, setUserReducedMotion, userReducedMotion } from "@/lib/motion";
import { cn } from "@/lib/utils";

const subscribeReduce = (cb: () => void) => {
  window.addEventListener(REDUCE_EVENT, cb);
  return () => window.removeEventListener(REDUCE_EVENT, cb);
};

export function Footer() {
  const reduce = useSyncExternalStore(subscribeReduce, userReducedMotion, () => false);
  const [note, setNote] = useState("");
  const emailId = useId();

  const toggleReduce = () => {
    setUserReducedMotion(!reduce);
    gsap.matchMediaRefresh();
  };

  return (
    <footer className="relative z-0 overflow-hidden bg-ink text-paper page-x pt-24 pb-12 curtain:sticky curtain:bottom-0" data-footer>
      <div className="grid grid-cols-12 gap-x-6 gap-y-16">
        <div className="col-span-12 lg:col-span-5">
          <p className="type-display text-72 lg:text-112">{brand.wordmark}</p>
          <form
            className="mt-10 max-w-md"
            onSubmit={(e) => {
              e.preventDefault();
              // [[NEWSLETTER_ENDPOINT]]: not connected yet, so say so instead of faking a signup.
              setNote("Newsletter signup isn't connected yet. Email us instead.");
            }}
          >
            <label htmlFor={emailId} className="type-label block text-16">
              Sticky notes: drops, deals and print tips {/* COPY: */}
            </label>
            <div className="mt-4 flex gap-2">
              <input
                id={emailId}
                type="email"
                name="email"
                spellCheck={false}
                required
                autoComplete="email"
                placeholder="you@brand.com"
                className="h-12 min-w-0 flex-1 rounded-chip border-2 border-paper/40 bg-transparent px-5 text-16 text-paper placeholder:text-paper/60 focus:border-paper"
              />
              <button type="submit" className="type-label h-12 rounded-chip bg-marigold px-6 text-16 text-ink hover:bg-paper">
                Subscribe
              </button>
            </div>
            <p aria-live="polite" className="mt-3 min-h-5 text-14 text-paper/80">
              {note}
            </p>
          </form>
        </div>

        <nav aria-label="Footer" className="col-span-12 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3 lg:col-span-7">
          {footerColumns.map((col) => (
            <div key={col.title}>
              <h2 className="type-caption text-paper/70">{col.title}</h2>
              <ul className="mt-4 flex flex-col">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <a href={link.href} className="type-label inline-flex min-h-11 items-center text-18 hover:text-marigold">
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
      </div>

      <div className="relative mt-24 flex flex-col gap-8 border-t border-paper/20 pt-8 lg:flex-row lg:items-center lg:justify-between">
        <div className="type-label flex flex-wrap items-center gap-x-6 gap-y-2 text-14 text-paper/80">
          <span>{company.email}</span>
          <span>{company.hours}</span>
          <span>{company.address}</span>
        </div>
        <ul className="flex flex-wrap items-center gap-x-6">
          {socials.map((s) => (
            <li key={s.label}>
              <a href={s.href} className="type-label inline-flex min-h-11 items-center text-14 hover:text-marigold">
                {s.label}
              </a>
            </li>
          ))}
        </ul>
        <button
          type="button"
          role="switch"
          aria-checked={reduce}
          onClick={toggleReduce}
          className="type-label inline-flex min-h-11 items-center gap-3 text-14"
        >
          Reduce motion
          <span aria-hidden="true" className={cn("relative h-6 w-11 rounded-chip transition-colors", reduce ? "bg-marigold" : "bg-paper/30")}>
            <span className={cn("absolute top-1 size-4 rounded-chip bg-paper transition-transform", reduce ? "translate-x-6" : "translate-x-1")} />
          </span>
        </button>
      </div>

      <p className="type-caption mt-8 text-paper/60">
        © 2026 {brand.name} · <a href="/privacy" className="underline">Privacy</a> · <a href="/terms" className="underline">Terms</a>
      </p>

      {/* S10 reward: three loose stickers to toss around with Draggable */}
      <div aria-hidden="true" className="footer-sticker-zone pointer-events-none relative mt-8 h-32 lg:absolute lg:inset-0 lg:mt-0 lg:h-auto">
        <Sticker art={no1Badge} className="footer-sticker pointer-events-auto absolute left-[5%] top-[5%] lg:left-[31%] w-24 rotate-12 lg:w-32" />
        <Sticker art={flame} className="footer-sticker pointer-events-auto absolute left-[43%] top-[25%] lg:left-[30%] lg:top-[60%] w-14 -rotate-12 lg:w-16" />
        <Sticker art={stripedBall} className="footer-sticker pointer-events-auto absolute right-[7%] top-[15%] lg:top-[54%] w-20 -rotate-6 lg:w-24" />
      </div>
      <FooterMotion />
    </footer>
  );
}
