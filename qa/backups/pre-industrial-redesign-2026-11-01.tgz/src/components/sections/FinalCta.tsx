import { NearViewport } from "@/components/sections/motion/NearViewport";
import { FinalCtaMotion } from "@/components/sections/motion/FinalCtaMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { no1Badge, freshBatch, brosBubble, stripedBall, flame } from "@/components/stickers/art";
import Magnet from "@/components/ui/Magnet";
import { PillLink } from "@/components/ui/Pill";
import { cta, finalCta } from "@/data/copy";

/** The die-cut scalloped bottom edge of the paper, revealing the ink footer below. */
function DieCutEdge() {
  return (
    <svg aria-hidden="true" className="absolute inset-x-0 bottom-0 h-6 w-full" preserveAspectRatio="none">
      <defs>
        <pattern id="scallop" width="48" height="24" patternUnits="userSpaceOnUse">
          <path d="M0 0A24 18 0 0 0 48 0V24H0Z" fill="#0A0A0A" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#scallop)" />
    </svg>
  );
}

/** S9. Rubber-stamp headline and a sticker burst. */
export function FinalCta() {
  return (
    <section id="cta" aria-labelledby="cta-title" className="relative overflow-hidden page-x pt-32 pb-44 text-center">
      <p className="type-caption">Ready when you are</p>
      <h2 id="cta-title" className="type-display mx-auto mt-4 max-w-[12ch] text-[clamp(4.5rem,15vw,15rem)] leading-[0.9]">
        {finalCta.headline}
      </h2>
      <div className="relative mt-12 flex flex-col items-center justify-center gap-3 sm:flex-row">
        <div data-burst-origin className="relative">
          <Magnet padding={60} magnetStrength={4}>
            <PillLink href={cta.primary.href} arrow>
              {cta.primary.label}
            </PillLink>
          </Magnet>
        </div>
        <PillLink href={`mailto:${finalCta.email}`} variant="outline">
          {finalCta.human}
        </PillLink>
      </div>
      <p className="type-label mt-6 text-14">
        {finalCta.email} · {finalCta.hours}
      </p>
      <div data-burst aria-hidden="true" className="pointer-events-none absolute inset-0">
        {Array.from({ length: 14 }, (_, i) => <div key={i} data-burst-sticker className="absolute w-16 opacity-0 lg:w-24"><Sticker art={[no1Badge, freshBatch, brosBubble, stripedBall, flame][i % 5]} className="w-full" /></div>)}
      </div>
      <DieCutEdge />
      <NearViewport><FinalCtaMotion /></NearViewport>
    </section>
  );
}
