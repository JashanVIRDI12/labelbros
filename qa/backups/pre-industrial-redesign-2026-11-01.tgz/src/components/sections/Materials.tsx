"use client";

import ShinyText from "@/components/ui/ShinyText";
import { REDUCE_EVENT, userReducedMotion } from "@/lib/motion";
import { useState, useSyncExternalStore } from "react";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { MaterialsMotion } from "@/components/sections/materials/MaterialsMotion";
import { DurabilityIcons } from "@/components/sections/materials/DurabilityIcons";
import { FinishSticker2D } from "@/components/sections/materials/FinishSticker2D";
import { SectionHead } from "@/components/ui/SectionHead";
import { materialsCopy } from "@/data/copy";
import { materials } from "@/data/materials";
import { cn } from "@/lib/utils";

const subscribeReduce = (cb: () => void) => { window.addEventListener(REDUCE_EVENT, cb); return () => window.removeEventListener(REDUCE_EVENT, cb); };

/**
 * S5. Desktop: pinned; scrolling morphs one 3D sticker through every finish (store.finish).
 * The list doubles as controls: pick a finish directly, which matters for reduced motion,
 * where it's the only way to swap. The 2D sticker is the low-tier / pre-canvas stand-in.
 */
export function Materials() {
  const reduce = useSyncExternalStore(subscribeReduce, userReducedMotion, () => false);
  const [active, setActive] = useState(0);
  const current = materials[active];

  return (
    <section id="materials" aria-labelledby="materials-title" className="materials-stage relative page-x" style={{ paddingBlock: "calc(var(--frame) + 24px)" }}>
      <div data-tint aria-hidden="true" className="absolute inset-0 -z-10 opacity-0" style={{ background: current.tint }} />
      <div className="grid h-full grid-cols-12 items-center gap-x-6 gap-y-10 py-8 stage:py-0">
        <div className="col-span-12 flex flex-col items-center justify-center lg:col-span-6">
          <div data-anchor="finish" className="relative w-[min(48vw,24svh,460px)] calm:w-[min(70vw,460px)] lg:w-[min(32vw,480px)]">
            <FinishSticker2D material={current} className="[:root[data-three~=finish][data-scenes~=materials]_&]:invisible" />
          </div>
          <p className="material-summary mt-5 max-w-xs text-center text-14 lg:hidden calm:hidden">{current.bestFor}<span className="mt-3 flex justify-center"><DurabilityIcons list={current.durability} /></span></p>
        </div>

        <div className="col-span-12 lg:col-span-6">
          <SectionHead id="materials-title" eyebrow={materialsCopy.eyebrow} title={materialsCopy.title} caption={materialsCopy.caption} size="sm" />
          <ol className="material-list mt-8 border-b border-ink/10">
            {materials.map((m, i) => {
              const on = i === active;
              return (
                <li key={m.id}>
                  <button
                    type="button"
                    data-material={i}
                    aria-pressed={on}
                    onClick={() => setActive(i)}
                    className="grid w-full grid-cols-[2.25rem_1fr_auto] items-center gap-x-4 border-t border-ink/10 py-3 text-left"
                  >
                    <span className="type-caption">{String(i + 1).padStart(2, "0")}</span>
                    <span>
                      <span className={cn("type-display block text-[clamp(1.6rem,2.5vw,2.6rem)] transition-colors duration-300", on ? "text-ink" : "text-ink-soft")}>
                        {m.shiny && on ? <ShinyText color="#0A0A0A" shineColor="#6B6A66" trigger="view" disabled={reduce} speed={0.8}>{m.name}</ShinyText> : m.name}
                      </span>
                      <span data-best-for className={cn("mt-1 block text-14 text-ink-soft", !on && "stage:hidden")}>{m.bestFor}</span>
                    </span>
                    <span className="flex items-center gap-3">
                      <span data-durability className={cn(!on && "stage:hidden")}>
                        <DurabilityIcons list={m.durability} />
                      </span>
                      <span aria-hidden="true" className="size-6 rounded-chip border border-ink/15" style={{ background: m.swatch }} />
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
      <NearViewport><MaterialsMotion onActive={setActive} /></NearViewport>
    </section>
  );
}
