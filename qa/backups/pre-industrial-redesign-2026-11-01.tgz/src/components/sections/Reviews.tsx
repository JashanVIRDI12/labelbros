import { NearViewport } from "@/components/sections/motion/NearViewport";
import { MarqueeToggle } from "@/components/sections/reviews/MarqueeToggle";
import { ReviewsMotion } from "@/components/sections/motion/ReviewsMotion";
import { ReviewSticker } from "@/components/sections/reviews/ReviewSticker";
import { Sticker } from "@/components/stickers/Sticker";
import { brosBubble, flame, freshBatch, no1Badge, stripedBall } from "@/components/stickers/art";
import { Arrow } from "@/components/ui/Pill";
import { SectionHead } from "@/components/ui/SectionHead";
import { reviewsCopy } from "@/data/copy";
import { caseStudies, logos, rating, reviews } from "@/data/reviews";
import { cn } from "@/lib/utils";

function LogoRow({ reverse }: { reverse?: boolean }) {
  const items = reverse ? [...logos].reverse() : logos;
  return (
    <div data-marquee className="flex w-max items-center gap-12 pr-12">
      {[...items, ...items].map((logo, i) => (
        <span key={i} className="flex items-center gap-12" aria-hidden={i >= items.length || undefined}>
          <span className="type-display whitespace-nowrap text-48 text-ink-soft">{logo}</span>
          <span className="size-3 rounded-chip bg-orange" aria-hidden="true" />
        </span>
      ))}
    </div>
  );
}

const caseFills = { forest: "bg-forest", periwinkle: "bg-periwinkle" } as const;
const caseArt = [
  [freshBatch, no1Badge],
  [brosBubble, stripedBall],
];

/**
 * S7. Reviews slapped onto a laptop lid as die-cut stickers (ScrollTrigger.batch),
 * velocity-skewed logo rows, and two mini case studies.
 */
export function Reviews() {
  return (
    <section id="reviews" aria-labelledby="reviews-title" className="relative py-24 lg:py-32">
      <div className="flex flex-wrap items-end justify-between gap-8 page-x">
        <SectionHead id="reviews-title" eyebrow={reviewsCopy.eyebrow} title={reviewsCopy.title} />
        <div className="text-right">
          <p className="type-display text-72 leading-none">{rating.value}</p>
          <p className="type-label mt-2 text-14">{rating.count} reviews</p>
        </div>
      </div>

      <div className="page-x mt-12">
        <div data-lid className="relative rounded-[40px] bg-ink px-6 py-12 sm:px-10 lg:px-14 lg:py-16">
          <Sticker art={flame} className="pointer-events-none absolute left-1/2 top-1/2 w-16 -translate-x-1/2 -translate-y-1/2 opacity-20" />
          <div className="relative columns-1 gap-8 sm:columns-2 lg:columns-3 xl:columns-4">
            {reviews.map((r, i) => (
              <ReviewSticker key={i} review={r} index={i} />
            ))}
          </div>
        </div>
      </div>

      <div aria-label="Brands that print with us" role="group" className="mt-20 flex flex-col gap-6 overflow-hidden">
        <LogoRow />
        <LogoRow reverse />
        <MarqueeToggle />
      </div>

      <div className="mt-20 grid gap-6 page-x lg:grid-cols-2">
        {caseStudies.map((c, i) => (
          <article key={c.brand} className="grid overflow-hidden rounded-card bg-white sm:grid-cols-2">
            <div className={cn("relative min-h-56", caseFills[c.color])} aria-hidden="true">
              <Sticker art={caseArt[i][0]} className="absolute left-[14%] top-[14%] w-[40%] -rotate-6" />
              <Sticker art={caseArt[i][1]} className="absolute bottom-[10%] right-[12%] w-[36%] rotate-12" />
            </div>
            <div className="flex flex-col p-6 lg:p-8">
              <p className="type-caption">{c.brand}</p>
              <h3 className="type-display mt-2 text-32">{c.title}</h3>
              <p className="mt-3 flex-1 text-16 leading-[1.45]">{c.body}</p>
              <a href="[[CASE_STUDY_URL]]" className="type-label mt-6 inline-flex h-11 items-center gap-2 text-14 hover:underline">
                Read the story <Arrow />
              </a>
            </div>
          </article>
        ))}
      </div>
      <NearViewport><ReviewsMotion /></NearViewport>
    </section>
  );
}
