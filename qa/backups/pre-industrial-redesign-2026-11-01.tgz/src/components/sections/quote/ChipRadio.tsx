import { cn } from "@/lib/utils";

type Option = { id: string; label: string };

/** Native radios styled as the reference's pill chips: arrow keys and forms work for free. */
export function ChipRadio({
  name,
  legend,
  options,
  value,
  onChange,
}: {
  name: string;
  legend: string;
  options: readonly Option[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <fieldset data-quote-control>
      <legend className="type-caption mb-3">{legend}</legend>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <label key={o.id} className="relative">
            <input
              type="radio"
              name={name}
              value={o.id}
              checked={value === o.id}
              onChange={() => onChange(o.id)}
              className="peer absolute inset-0 cursor-pointer opacity-0"
            />
            <span
              className={cn(
                "type-label pointer-events-none inline-flex h-11 items-center rounded-chip border px-5 text-14 transition-colors duration-200",
                "border-ink/20 bg-white peer-hover:border-ink peer-checked:border-ink peer-checked:bg-ink peer-checked:text-paper",
                "peer-focus-visible:outline-3 peer-focus-visible:outline-offset-3 peer-focus-visible:outline-periwinkle",
              )}
            >
              {o.label}
            </span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}
