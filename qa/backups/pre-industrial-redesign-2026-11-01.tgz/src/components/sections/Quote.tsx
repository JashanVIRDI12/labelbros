"use client";

import { useDeferredValue, useId, useMemo, useRef, useState } from "react";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { QuoteMotion } from "@/components/sections/motion/QuoteMotion";
import { ChipRadio } from "@/components/sections/quote/ChipRadio";
import { PillLink } from "@/components/ui/Pill";
import { SectionHead } from "@/components/ui/SectionHead";
import { quoteCopy, quoteArtwork } from "@/data/copy";
import {
  breaks,
  money,
  productTypes,
  quantities,
  quote,
  quoteMaterials,
  SAMPLE_PRICING,
  SIZE_MAX,
  SIZE_MIN,
  sizeError,
  sizePresets,
  type QuoteInput,
} from "@/data/pricing";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";
import { cn } from "@/lib/utils";

const sizeOptions = [...sizePresets.map((s) => ({ id: s.id, label: s.label })), { id: "custom", label: "Custom" }];
const qtyLabel = (n: number) => n.toLocaleString("en-US");

/** Little stack of sticker sheets beside the price: grows with quantity. */
function SheetStack({ qty }: { qty: number }) {
  const scope = useRef<HTMLDivElement>(null);
  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      if (!motionFlags(ctx.conditions).reduceMotion) gsap.fromTo(scope.current, { scaleY: 0.85 }, { scaleY: 1, duration: 0.35, ease: "slap" });
    });
  }, { scope, dependencies: [qty], revertOnUpdate: true });
  const sheets = Math.max(1, Math.min(8, Math.round(Math.log2(qty / 25))));
  return (
    <div ref={scope} data-sheet-stack aria-hidden="true" className="relative h-24 w-20 shrink-0 origin-bottom">
      {Array.from({ length: sheets }, (_, i) => (
        <span
          key={i}
          className="absolute bottom-0 left-0 h-20 w-16 rounded-[6px] border-2 border-ink bg-white"
          style={{ transform: `translate(${i * 2}px, ${-i * 4}px) rotate(${(i % 2 ? 1 : -1) * (2 + i)}deg)` }}
        >
          {i === sheets - 1 && (
            <>
              <span className="absolute left-2 top-2 size-4 rounded-chip bg-marigold" />
              <span className="absolute right-2 top-3 h-3 w-5 rounded-[3px] bg-bubblegum" />
              <span className="absolute bottom-2 left-2 h-3 w-8 rounded-chip bg-periwinkle" />
            </>
          )}
        </span>
      ))}
    </div>
  );
}

/**
 * S6. Mini configurator. Pricing is [[REAL_PRICING]] (sample numbers, flagged in the UI).
 * States: custom size empty → prompt; out of range → error; typing → "Updating" while the
 * deferred value catches up.
 */
export function Quote() {
  const [product, setProduct] = useState<QuoteInput["product"]>("product");
  const [material, setMaterial] = useState<QuoteInput["material"]>("matte");
  const [sizeId, setSizeId] = useState<string>("3x3");
  const [custom, setCustom] = useState({ w: "", h: "" });
  const [qtyIndex, setQtyIndex] = useState(quantities.indexOf(500));
  const [artworkId, setArtworkId] = useState<(typeof quoteArtwork)[number]["id"]>("upload");
  const artwork = quoteArtwork.find((x) => x.id === artworkId) ?? quoteArtwork[0];
  const ids = { w: useId(), h: useId(), qty: useId(), sizeErr: useId() };

  const qty = quantities[qtyIndex];
  const preset = sizePresets.find((s) => s.id === sizeId);
  const w = preset ? preset.w : parseFloat(custom.w);
  const h = preset ? preset.h : parseFloat(custom.h);
  const error = sizeError(w, h);

  const input = useMemo<QuoteInput>(() => ({ product, material, w, h, qty }), [product, material, w, h, qty]);
  const deferred = useDeferredValue(input);
  const updating = deferred !== input;
  const result = useMemo(() => (sizeError(deferred.w, deferred.h) ? null : quote(deferred)), [deferred]);
  const customEmpty = sizeId === "custom" && (!custom.w || !custom.h);

  return (
    <section id="quote" aria-labelledby="quote-title" className="relative page-x py-24 lg:py-32">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <SectionHead id="quote-title" eyebrow={quoteCopy.eyebrow} title={quoteCopy.title} caption={quoteCopy.caption} />
        {SAMPLE_PRICING && (
          <p className="type-label rounded-chip bg-bubblegum px-4 py-2 text-14">Sample pricing, not final</p>
        )}
      </div>

      <div data-quote className="mt-12 grid grid-cols-12 gap-6 rounded-card bg-white p-5 sm:p-8 lg:p-10">
        <form className="col-span-12 flex flex-col gap-8 lg:col-span-7" onSubmit={(e) => e.preventDefault()}>
          <ChipRadio name="product" legend="Product" options={productTypes} value={product} onChange={(v) => setProduct(v as QuoteInput["product"])} />

          <div data-quote-control>
            <ChipRadio name="size" legend="Size (inches)" options={sizeOptions} value={sizeId} onChange={setSizeId} />
            {sizeId === "custom" && (
              <div className="mt-4 flex flex-wrap items-end gap-3">
                {(["w", "h"] as const).map((k) => (
                  <div key={k}>
                    <label htmlFor={ids[k]} className="type-caption block">
                      {k === "w" ? "Width" : "Height"}
                    </label>
                    <div className="relative mt-1">
                      <input
                        id={ids[k]}
                        name={k === "w" ? "width" : "height"}
                        autoComplete="off"
                        inputMode="decimal"
                        type="number"
                        min={SIZE_MIN}
                        max={SIZE_MAX}
                        step="0.25"
                        value={custom[k]}
                        onChange={(e) => setCustom((c) => ({ ...c, [k]: e.target.value }))}
                        aria-invalid={Boolean(error) && !customEmpty}
                        aria-describedby={ids.sizeErr}
                        className="h-11 w-28 rounded-chip border border-ink/20 bg-white pl-4 pr-9 text-16 aria-[invalid=true]:border-orange-text"
                      />
                      <span className="type-caption pointer-events-none absolute right-4 top-1/2 -translate-y-1/2">in</span>
                    </div>
                  </div>
                ))}
                <p id={ids.sizeErr} className={cn("w-full text-14", customEmpty ? "text-ink-soft" : "text-orange-text")}>
                  {error ?? ""}
                </p>
              </div>
            )}
          </div>

          <div data-quote-control>
            <div className="flex items-baseline justify-between">
              <label htmlFor={ids.qty} className="type-caption">
                Quantity
              </label>
              <span className="type-display text-32">{qtyLabel(qty)}</span>
            </div>
            <input
              id={ids.qty}
              name="quantity"
              type="range"
              min={0}
              max={quantities.length - 1}
              step={1}
              value={qtyIndex}
              onChange={(e) => setQtyIndex(Number(e.target.value))}
              aria-valuetext={`${qtyLabel(qty)} labels`}
              className="qty-range mt-3 w-full"
            />
            <div aria-hidden="true" className="relative mt-1 h-6">
              {breaks.slice(1).map((b) => {
                const i = quantities.indexOf(b.qty);
                return (
                  <span
                    key={b.qty}
                    className="type-caption absolute -translate-x-1/2 before:mx-auto before:mb-1 before:block before:h-2 before:w-0.5 before:bg-ink/30"
                    style={{ left: `calc(11px + (100% - 22px) * ${i / (quantities.length - 1)})` }}
                  >
                    {b.qty >= 1000 ? `${b.qty / 1000}k` : b.qty}
                  </span>
                );
              })}
            </div>
          </div>

          <ChipRadio name="material" legend="Material" options={quoteMaterials} value={material} onChange={(v) => setMaterial(v as QuoteInput["material"])} />

          {/* your art or ours: decides where the CTA goes; the design fee is never folded into the sample price */}
          <ChipRadio name="artwork" legend="Artwork" options={quoteArtwork} value={artworkId} onChange={(v) => setArtworkId(v as typeof artworkId)} />
        </form>

        <div className="col-span-12 flex flex-col rounded-[14px] bg-paper p-6 lg:col-span-5 lg:p-8">
          <p className="type-caption">Your price</p>
          <div aria-live="polite" aria-busy={updating} className="mt-2 min-h-[8.5rem]">
            {result && !error ? (
              <div className={cn("transition-opacity duration-200", updating && "opacity-50")}>
                <div className="flex flex-wrap items-end justify-between gap-4">
                  <p data-price data-total={result.total} className="type-display max-w-full text-[clamp(3rem,6vw,6rem)] leading-[0.9]" style={{ fontSize: money(result.total, 2).length > 8 ? "clamp(2.4rem, 4.3vw, 4.5rem)" : undefined }}>
                    <span data-price-value>{money(result.total, 2)}</span><span data-price-count aria-hidden="true" hidden />
                  </p>
                  <SheetStack qty={qty} />
                </div>
                <p className="type-label mt-3 text-16">
                  {money(result.unit, 2)} / label · {qtyLabel(qty)} labels
                </p>
                {updating && <p className="type-caption mt-2">Updating…</p>}
              </div>
            ) : (
              <p className="type-display text-32 leading-[1.05] text-ink-soft">
                {customEmpty ? "Add a size to see your price." : "Pick a size between 0.5 and 12 inches."}
              </p>
            )}
          </div>

          {result && !error && result.next && (
            <p className="type-label mt-6 self-start rounded-chip bg-marigold px-4 py-2 text-14">
              Add {qtyLabel(result.next.add)} more, save {result.next.savePct}% each
            </p>
          )}

          {artworkId === "design" && (
            <p className="type-label mt-4 text-14">+ Design fee [[DESIGN_FEE]], quoted separately</p>
          )}

          <div className="mt-auto pt-8">
            <PillLink href={artwork.href} arrow className="w-full" aria-disabled={Boolean(error) || undefined} tabIndex={error ? -1 : 0} onClick={(e) => { if (error) e.preventDefault(); }}>
              {artwork.cta}
            </PillLink>
            <p className="type-caption mt-3 text-center">Free proof before anything prints</p>
          </div>
        </div>
      </div>
      <NearViewport><QuoteMotion /></NearViewport>
    </section>
  );
}
