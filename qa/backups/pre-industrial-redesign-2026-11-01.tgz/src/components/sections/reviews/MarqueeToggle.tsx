"use client";
import { useState } from "react";

export function MarqueeToggle() {
  const [paused, setPaused] = useState(false);
  return <button type="button" aria-pressed={paused} className="type-label mx-auto inline-flex min-h-11 items-center rounded-chip border border-ink/20 px-5 text-14 hover:bg-white calm:hidden" onClick={(e) => {
    const root = e.currentTarget.closest("section");
    const next = !paused;
    setPaused(next);
    if (root) { root.setAttribute("data-marquee-paused", String(next)); root.dispatchEvent(new Event("lb:marquee-pause")); }
  }}>{paused ? "Resume brand logos" : "Pause brand logos"}</button>;
}
