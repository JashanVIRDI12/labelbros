import type { Review } from "@/data/reviews";
import { cn } from "@/lib/utils";

const fills: Record<Review["color"], string> = {
  marigold: "bg-marigold text-ink",
  forest: "bg-forest text-white",
  bubblegum: "bg-bubblegum text-ink",
  periwinkle: "bg-periwinkle text-white",
  orange: "bg-orange text-ink",
  white: "bg-white text-ink",
};

const shapes: Record<Review["shape"], string> = {
  round: "aspect-square rounded-chip px-10 text-center justify-center items-center",
  tag: "rounded-tag px-7 py-7",
  oval: "aspect-[5/4] rounded-[50%] px-12 text-center justify-center items-center",
  blob: "aspect-[6/5] px-10 text-center justify-center items-center [border-radius:58%_42%_55%_45%/45%_55%_45%_55%]",
};

const tilt = [-4, 3, -2, 5, -5, 2, -3, 4, -1, 3, -4, 2];

function Stars() {
  return (
    <svg viewBox="0 0 100 18" className="h-3.5 w-20" aria-hidden="true" focusable="false">
      {[0, 1, 2, 3, 4].map((i) => (
        <path key={i} transform={`translate(${i * 20} 0)`} d="m9 1 2.3 4.9 5.3.6-3.9 3.7 1 5.3L9 12.9l-4.7 2.6 1-5.3-3.9-3.7 5.3-.6z" fill="currentColor" />
      ))}
    </svg>
  );
}

/** A review printed as a die-cut sticker: palette fill, white die-cut ring, slight tilt. */
export function ReviewSticker({ review, index }: { review: Review; index: number }) {
  return (
    <figure
      data-review
      className={cn("review-sticker mb-8 flex break-inside-avoid flex-col outline-[7px] outline-white outline-solid", fills[review.color], shapes[review.shape])}
      style={{ rotate: `${tilt[index % tilt.length]}deg` }}
    >
      <Stars />
      <blockquote className="mt-3 text-16 leading-[1.4]">{review.quote}</blockquote>
      <figcaption className="type-label mt-4 text-14">
        {review.name} · {review.brand}
      </figcaption>
    </figure>
  );
}
