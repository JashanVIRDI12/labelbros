"use client";
import { useRef } from "react";
import { Draggable, gsap, useGSAP } from "@/lib/gsap";
import { getLenis } from "@/lib/lenis";
import { MQ, motionFlags } from "@/lib/motion";

export function FooterMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(() => {
    const footer = scope.current;
    const marker = document.querySelector("[data-footer-start]");
    if (!footer || !marker) return;
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      const reduce = motionFlags(ctx.conditions).reduceMotion;
      let drag: Draggable[] = [];
      // A sticky footer's rectangle is always in the viewport, even when hidden by main.
      // Observe its normal-flow marker, and defer drag measurement until it approaches.
      const io = new IntersectionObserver(([entry]) => {
        footer.dataset.footerVisible = String(entry.isIntersecting);
        if (entry.isIntersecting && !reduce && !drag.length) ctx.add(() => {
          drag = Draggable.create(footer.querySelectorAll(".footer-sticker"), { type: "x,y", bounds: footer, inertia: true, edgeResistance: 0.8, cursor: "grab", activeCursor: "grabbing", minimumMovement: 6 });
        });
      }, { rootMargin: "100% 0px" });
      io.observe(marker);
      const focus = () => {
        footer.dataset.footerVisible = "true";
        if (marker.getBoundingClientRect().top > window.innerHeight) {
          const end = document.documentElement.scrollHeight - window.innerHeight;
          const lenis = getLenis();
          if (lenis) lenis.scrollTo(end, { immediate: true });
          else window.scrollTo(0, end);
        }
      };
      footer.addEventListener("focusin", focus);
      return () => { io.disconnect(); footer.removeEventListener("focusin", focus); drag.forEach((d) => d.kill()); };
    });
  }, { scope });
  return <span hidden ref={(el) => { scope.current = el?.closest("footer") ?? null; }} />;
}
