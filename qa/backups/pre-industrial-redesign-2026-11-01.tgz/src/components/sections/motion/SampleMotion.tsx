"use client";

import { useLayoutEffect, useRef } from "react";
import { Draggable, gsap, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";
import { invalidate, setProgress, setSceneActive } from "@/lib/scrollStore";

export function SampleMotion({ onReveal, revealed }: { onReveal: () => void; revealed: boolean }) {
  const revealedRef = useRef(revealed);
  useLayoutEffect(() => { revealedRef.current = revealed; }, [revealed]);
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(() => {
    const root = scope.current;
    if (!root) return;
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      const { reduceMotion } = motionFlags(ctx.conditions);
      const sticker = root.querySelector<HTMLElement>("[data-anchor=peel]")!;
      const proxy = document.createElement("div");
      const progress = { v: revealedRef.current ? 1 : 0 };
      let done = revealedRef.current;
      if (done) { setProgress("peel", 1); gsap.set(sticker, { opacity: 0 }); }
      const update = () => {
        setProgress("peel", progress.v);
        gsap.set(sticker, { rotationX: -progress.v * 65, yPercent: -progress.v * 95, opacity: progress.v > 0.95 ? 0 : 1, transformOrigin: "0% 100%" });
      };
      const finish = () => ctx.add(() => {
        if (done) return;
        done = true;
        onReveal();
        if (reduceMotion) { setProgress("peel", 1); gsap.set(sticker, { opacity: 0 }); return; }
        gsap.to(progress, { v: 1, duration: 0.6, ease: "expo.out", overwrite: true, onUpdate: update });
      });
      root.addEventListener("lb:peel-request", finish);
      let drag: Draggable | undefined;
      if (!reduceMotion && !done) {
        setProgress("peel", 0);
        const drive = () => {
          if (done || !drag) return;
          progress.v = gsap.utils.clamp(0, 1, (drag.x - drag.y) / (sticker.offsetWidth * 1.1));
          update();
          if (progress.v >= 0.55) finish();
        };
        drag = Draggable.create(proxy, {
          trigger: root.querySelector("[data-peel-drag]"), type: "x,y", inertia: true,
          bounds: { minX: 0, maxX: 350, minY: -350, maxY: 0 }, allowNativeTouchScrolling: false,
          onPress: () => gsap.killTweensOf(progress), onDrag: drive, onThrowUpdate: drive,
          onRelease: () => {
            if (done) return;
            gsap.to(progress, { v: 0, duration: 0.35, ease: "expo.out", onUpdate: update });
            gsap.set(proxy, { x: 0, y: 0 });
          },
        })[0];
        ScrollTrigger.create({ trigger: root, start: "top bottom", end: "bottom top", onUpdate: () => invalidate(), onToggle: (self) => setSceneActive("sample", self.isActive) });
        gsap.timeline({ scrollTrigger: { trigger: root, start: "top 70%", once: true } })
          .to(progress, { v: 0.15, duration: 0.35, ease: "slap", onUpdate: update })
          .to(progress, { v: 0, duration: 0.35, ease: "slap", onUpdate: update });
      }
      return () => { root.removeEventListener("lb:peel-request", finish); drag?.kill(); setSceneActive("sample", false); };
    });
  }, { scope, dependencies: [onReveal] });
  return <span hidden ref={(el) => { scope.current = el?.closest("section") ?? null; }} />;
}
