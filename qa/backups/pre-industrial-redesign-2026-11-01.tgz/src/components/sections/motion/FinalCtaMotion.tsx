"use client";

import { useRef } from "react";
import { gsap, SplitText, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";

export function FinalCtaMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(() => {
    const root = scope.current;
    if (!root) return;
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
      if (reduceMotion) return;
      let burst = false;
      const stickers = [...root.querySelectorAll<HTMLElement>("[data-burst-sticker]")].slice(0, isDesktop ? 14 : 8);
      const scatter = () => ctx.add(() => {
        if (burst) return;
        burst = true;
        const r = root.getBoundingClientRect();
        const o = root.querySelector("[data-burst-origin]")!.getBoundingClientRect();
        gsap.set(stickers, { left: o.left + o.width / 2 - r.left, top: o.top + o.height / 2 - r.top, opacity: 1, scale: 0.4 });
        stickers.forEach((sticker, i) => {
          const angle = 200 + i / (stickers.length - 1) * 140;
          const velocity = (isDesktop ? 250 : 140) + (i % 4) * 35;
          const rad = angle * Math.PI / 180;
          const floor = r.height - (o.top + o.height / 2 - r.top) - 75;
          const vy = Math.sin(rad) * velocity;
          const time = (-vy + Math.sqrt(vy * vy + 2 * 900 * floor)) / 900;
          gsap.to(sticker, { physics2D: { velocity, angle, gravity: 900 }, rotation: (i % 2 ? -1 : 1) * (100 + i * 21), scale: 1, duration: time, ease: "none" });
        });
      });
      const split = SplitText.create(root.querySelector("h2"), { type: "words,chars", wordsClass: "stamp-word", autoSplit: true, onSplit: (self) => gsap.from(self.chars, {
        scale: 1.25, yPercent: -30, opacity: 0.35, stagger: 0.03, ease: "none",
        scrollTrigger: { id: "cta-stamp", trigger: root, start: "top 80%", end: "center center", scrub: 1, onScrubComplete: (st) => { if (st.progress > 0.99) scatter(); } },
      }) });
      return () => split.revert();
    });
  }, { scope });
  return <span hidden ref={(el) => { scope.current = el?.closest("section") ?? null; }} />;
}
