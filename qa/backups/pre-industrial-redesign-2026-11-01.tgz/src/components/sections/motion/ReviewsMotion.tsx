"use client";

import { useRef } from "react";
import { gsap, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";

export function ReviewsMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(() => {
    const root = scope.current;
    if (!root) return;
    const q = gsap.utils.selector(root);
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
      if (reduceMotion) return;
      const stickers = q("[data-review]");
      gsap.set(stickers, { opacity: 0, scale: 1.5, rotation: (i) => [-17,22,-12,16][i % 4] });
      ScrollTrigger.batch(stickers, { start: "top 85%", once: true, onEnter: (batch) => ctx.add(() => gsap.to(batch, { opacity: 1, scale: 1, rotation: 0, ease: "slap", duration: 0.8, stagger: 0.07 })) });
      const rows = q("[data-marquee]");
      const loops = rows.map((row, i) => gsap.fromTo(row, { xPercent: i ? -50 : 0 }, { xPercent: i ? 0 : -50, duration: isDesktop ? 28 : 45, ease: "none", repeat: -1, paused: true }));
      loops.forEach((loop) => loop.eventCallback("onReverseComplete", () => { loop.totalTime(loop.rawTime() + loop.duration() * 100); }));
      const skew = rows.map((r) => gsap.quickTo(r, "skewX", { duration: 0.4, ease: "expo.out" }));
      const resetSkew = () => skew.forEach((s) => s(0));
      ScrollTrigger.addEventListener("scrollEnd", resetSkew);
      let visible = false;
      const sync = () => loops.forEach((loop) => visible && !document.hidden && root.dataset.marqueePaused !== "true" ? loop.play() : loop.pause());
      ScrollTrigger.create({ trigger: root, start: "top bottom", end: "bottom top", onToggle: (self) => { visible = self.isActive; sync(); }, onUpdate: (self) => {
        loops.forEach((loop, i) => loop.timeScale(self.direction * (i ? -1 : 1)));
        if (isDesktop) skew.forEach((s, i) => s(gsap.utils.clamp(-8, 8, self.getVelocity() / 300) * (i ? -1 : 1)));
      } });
      document.addEventListener("visibilitychange", sync);
      root.addEventListener("lb:marquee-pause", sync);
      return () => { document.removeEventListener("visibilitychange", sync); root.removeEventListener("lb:marquee-pause", sync); ScrollTrigger.removeEventListener("scrollEnd", resetSkew); };
    });
  }, { scope });
  return <span hidden ref={(el) => { scope.current = el?.closest("section") ?? null; }} />;
}
