"use client";

import { useEffect, useRef, useState } from "react";

/** Defer below-fold animation setup until its section approaches; content stays server rendered. */
export function NearViewport({ children }: { children: React.ReactNode }) {
  const sentinel = useRef<HTMLSpanElement>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const section = sentinel.current?.closest("section, footer");
    if (!section) return;
    const io = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      setReady(true);
      io.disconnect();
    }, { rootMargin: "100% 0px" });
    const prepare = (event: Event) => {
      const target = (event as CustomEvent<Element>).detail;
      if (section === target || section.contains(target) || (section.compareDocumentPosition(target) & Node.DOCUMENT_POSITION_FOLLOWING)) {
        setReady(true);
        io.disconnect();
      }
    };
    document.addEventListener("lb:prepare-anchor", prepare);
    io.observe(section);
    return () => { io.disconnect(); document.removeEventListener("lb:prepare-anchor", prepare); };
  }, []);
  return <><span ref={sentinel} hidden />{ready ? children : null}</>;
}
