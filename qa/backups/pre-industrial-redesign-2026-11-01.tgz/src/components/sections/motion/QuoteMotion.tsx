"use client";

import { useRef } from "react";
import { gsap, Flip, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";

export function QuoteMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(() => {
    const root = scope.current;
    if (!root) return;
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
      if (reduceMotion) return;
      const controls = [...root.querySelectorAll<HTMLElement>("form > [data-quote-control]")];
      gsap.set(controls, { x: (i) => [35,-25,22,-30][i % 4], y: (i) => [-18,20,-12,15][i % 4], rotation: (i) => [-4,3,-2,4][i % 4] });
      const price = root.querySelector<HTMLElement>("[data-price]");
      const count = { value: 0 };
      const enter = () => ctx.add(() => {
        const state = Flip.getState(controls);
        gsap.set(controls, { x: 0, y: 0, rotation: 0 });
        Flip.from(state, { absolute: false, ease: "slap", duration: 0.9, stagger: isDesktop ? 0.05 : 0.025 });
      });
      ScrollTrigger.create({ trigger: root, start: "top 65%", once: true, onEnter: enter });
      gsap.timeline({ scrollTrigger: { trigger: root, start: "top 65%", once: true } })
        .to(count, { value: 1, duration: 0.6, ease: "expo.out", onUpdate: () => {
          // A separate decorative layer keeps the live, accessible price stable.
          const layer = root.querySelector<HTMLElement>("[data-price-count]");
          if (layer && price) { layer.textContent = `$${Math.round(Number(price.dataset.total) * count.value).toLocaleString("en-US")}`; }
        }, onComplete: () => { const layer = root.querySelector<HTMLElement>("[data-price-count]"); if (layer) layer.hidden = true; price?.classList.remove("price-counting"); } });
      price?.classList.add("price-counting");
      const layer = root.querySelector<HTMLElement>("[data-price-count]");
      if (layer) layer.hidden = false;
      return () => { price?.classList.remove("price-counting"); if (layer) layer.hidden = true; };
    });
  }, { scope });
  return <span hidden ref={(el) => { scope.current = el?.closest("section") ?? null; }} />;
}
