"use client";

import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";
import { setProgress, setSceneActive } from "@/lib/scrollStore";

export const HERO_INTRO_EVENT = "lb:herointro";

function markIntroDone() {
  document.documentElement.dataset.heroIntro = "done";
  window.dispatchEvent(new Event(HERO_INTRO_EVENT));
}

/**
 * S1 motion. Load (signature, ~1.4s): stickers slap into the type, the phone rises, the die
 * line traces the label, floating stickers drop in. Desktop scroll (signature, pin +100%):
 * inline stickers peel off (3D, or a 2D fallback), lines slide out through their masks,
 * the phone eases to centre. Touch: load only, plus tap-to-peel on the Nº1 badge.
 */
export function HeroMotion() {
  const scope = useRef<HTMLElement | null>(null);

  useGSAP(
    () => {
      const root = scope.current;
      if (!root) return;
      const q = gsap.utils.selector(root);
      const html = document.documentElement;
      const mm = gsap.matchMedia();

      mm.add(MQ, (ctx) => {
        const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
        if (reduceMotion) {
          markIntroDone();
          return;
        }

        const inline = q("[data-inline-sticker]");
        const floats = q("[data-float]");
        const phone = q("[data-hero-phone]");
        const fades = q("[data-hero-fade]");
        const dieline = q("[data-dieline]");
        const editorBits = q("[data-handle], [data-dimension]");

        // ---------- load ----------
        // stickers fade with opacity only: autoAlpha would pin an inline `visibility` that beats
        // the CSS rule hiding them once their 3D copies take over
        gsap.set([...inline, ...floats], { opacity: 0 });
        gsap.set([...phone, ...fades, ...editorBits], { autoAlpha: 0 });
        gsap.set(dieline, { drawSVG: "0% 0%" });
        html.classList.add("motion-ready");

        const intro = gsap.timeline({ paused: true, defaults: { ease: "expo.out" }, onComplete: markIntroDone });
        intro
          .fromTo(phone, { y: 60, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 1.2 }, 0.1)
          .fromTo(
            inline,
            { scale: 1.6, rotation: (i: number) => (i ? -18 : 18), opacity: 0 },
            { scale: 1, rotation: 0, opacity: 1, duration: 0.9, ease: "slap", stagger: 0.12 },
            0.35,
          )
          // the squash when each sticker lands
          .to(inline, { scaleY: 0.9, duration: 0.05, ease: "none", yoyo: true, repeat: 1, stagger: 0.12 }, 0.72)
          .fromTo(dieline, { drawSVG: "0% 0%" }, { drawSVG: "0% 100%", duration: 0.9, ease: "power2.inOut" }, 0.5)
          .fromTo(editorBits, { scale: 0.4, autoAlpha: 0 }, { scale: 1, autoAlpha: 1, duration: 0.35, ease: "slap", stagger: 0.04 }, 1.25)
          .fromTo(
            floats,
            { y: -50, rotation: () => gsap.utils.random(-25, 25), scale: 1.15, opacity: 0 },
            { y: 0, rotation: 0, scale: 1, opacity: 1, duration: 0.9, ease: "slap", stagger: 0.07 },
            0.55,
          )
          .fromTo(fades, { y: 16, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 0.6, stagger: 0.06 }, 0.6);

        // start with the CSS line rise (first paint); fonts.ready only refreshes positions
        intro.play();

        if (!isDesktop) {
          // touch: tap the Nº1 badge to peel it off; it slaps back on
          const badge = q('[data-inline-sticker="no1"]')[0];
          const peel = () => {
            if (intro.isActive() || gsap.isTweening(badge)) return;
            gsap
              .timeline()
              .to(badge, { rotation: -26, xPercent: 25, yPercent: -55, scale: 1.08, transformOrigin: "0% 100%", duration: 0.3, ease: "power2.out" })
              .to(badge, { yPercent: -170, rotation: -70, opacity: 0, duration: 0.3, ease: "power2.in" })
              .set(badge, { xPercent: 0, yPercent: 0, rotation: 18, scale: 1.6, transformOrigin: "50% 50%" })
              .to(badge, { opacity: 1, rotation: 0, scale: 1, duration: 0.9, ease: "slap" }, "+=0.5");
          };
          badge?.addEventListener("click", peel);
          return () => badge?.removeEventListener("click", peel);
        }

        // ---------- desktop scroll: peel-off ----------
        const slides = q("[data-hero-slide]");
        const stickers2d = [...q("[data-inline-sticker] svg"), ...floats.map((f) => f.querySelector("svg")!)];
        const col = q("[data-phone-col]")[0];
        const slot = q('[data-phone-slot="hero"]')[0];
        const centerX = () => {
          const r = col.getBoundingClientRect();
          return window.innerWidth / 2 - (r.left + r.width / 2);
        };

        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: {
            id: "hero",
            trigger: root,
            start: "top top",
            end: "+=100%",
            refreshPriority: 100,
            pin: true,
            pinSpacing: true,
            anticipatePin: 1,
            scrub: 1,
            invalidateOnRefresh: true,
            onUpdate: (self) => {
              setProgress("hero", self.progress);
              setSceneActive("hero", self.progress < 1);
              root.classList.toggle("is-peeling", self.progress > 0.002);
            },
            onLeave: () => setSceneActive("hero", false),
            onEnterBack: () => setSceneActive("hero", true),
          },
        });

        tl.to(slides[0], { xPercent: -110, duration: 0.5 }, 0)
          .to(slides[1], { xPercent: 110, duration: 0.5 }, 0)
          .to(slides[2], { xPercent: -110, duration: 0.5 }, 0)
          // steps, CTAs and trust line leave with the headline: sideways, out of frame
          .to(fades, { xPercent: -135, duration: 0.5 }, 0)
          // 2D peel for when there is no WebGL (CSS hides these while the 3D copies own them)
          // 2D peel for when there is no WebGL (CSS hides these while their 3D copies own them):
          // every sticker lifts from a corner and leaves by the right edge, fully opaque
          .to(stickers2d, { rotation: -14, y: -24, scale: 1.06, transformOrigin: "100% 100%", duration: 0.12, stagger: 0.05 }, 0.02)
          .to(
            stickers2d,
            { rotation: 32, x: () => window.innerWidth * 1.1, y: () => -window.innerHeight * 0.35, duration: 0.36, stagger: 0.05 },
            0.14,
          )
          .to(slot, { x: centerX, scale: 0.92, duration: 0.5 }, 0.5)
          // the phone is an object, not a card: it banks into the glide and levels out at centre
          .to(slot, { rotationY: -14, rotationX: 4, transformPerspective: 1400, duration: 0.25 }, 0.5)
          .to(slot, { rotationY: 0, rotationX: 0, duration: 0.25 }, 0.75);

        setSceneActive("hero", (tl.scrollTrigger?.progress ?? 0) < 1);

        return () => {
          setSceneActive("hero", false);
          root.classList.remove("is-peeling");
        };
      });
    },
    { scope },
  );

  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("section") ?? null;
      }}
    />
  );
}
