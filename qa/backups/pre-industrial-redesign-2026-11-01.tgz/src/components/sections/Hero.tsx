import { LabelStudioPhone } from "@/components/phone/LabelStudioPhone";
import { HeroMotion } from "@/components/sections/hero/HeroMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { brosBubble, flame, freshBatch, no1Badge, smallBrandTag, stripedBall, type StickerArt } from "@/components/stickers/art";
import Magnet from "@/components/ui/Magnet";
import { PillLink } from "@/components/ui/Pill";
import { cta, hero } from "@/data/copy";

function Star() {
  return (
    <svg viewBox="0 0 20 20" className="size-4 text-orange" aria-hidden="true" focusable="false">
      <path d="m10 1.8 2.5 5.3 5.8.7-4.3 4 1.1 5.7L10 14.7l-5.1 2.8L6 11.8l-4.3-4 5.8-.7z" fill="currentColor" />
    </svg>
  );
}

/**
 * Stickers that break the phone's edges, like the reference. Positions are % of the phone box.
 * The tilt sits on an inner span: GSAP animates the outer one and would otherwise absorb
 * the CSS `rotate` into its own transform and lose it.
 */
const phoneStickers: { art: StickerArt; place: string; tilt: string }[] = [
  { art: freshBatch, place: "left-[-24%] top-[-5%] w-[36%]", tilt: "-rotate-[14deg]" },
  { art: smallBrandTag, place: "right-[-30%] top-[55%] w-[50%]", tilt: "rotate-[9deg]" },
  { art: stripedBall, place: "right-[-16%] top-[75%] w-[36%]", tilt: "-rotate-[8deg]" },
  { art: brosBubble, place: "left-[-30%] top-[66%] w-[40%]", tilt: "-rotate-[7deg]" },
];

/**
 * One headline line: mask (clips) › slide (GSAP moves it sideways on scroll) › text (CSS rise
 * on load, so the H1, our LCP element, paints without waiting for JavaScript).
 */
function Line({ text, i }: { text: string; i: number }) {
  return (
    <span className="hero-mask block overflow-clip">
      <span data-hero-slide className="block">
        <span className="hero-text block" style={{ "--i": i } as React.CSSProperties}>
          {text}
        </span>
      </span>
    </span>
  );
}

/**
 * Inline sticker. Outer span: layout + the intro slap. Inner span ([data-anchor]): the nudge,
 * untouched by GSAP, so 3D can measure it. Svg: the 2D peel fallback.
 */
function InlineSticker({ art, size, nudge }: { art: StickerArt; size: string; nudge: string }) {
  return (
    <span data-inline-sticker={art.id} data-intro className={`relative inline-block shrink-0 ${size}`}>
      <span data-anchor className={`block h-full w-full ${nudge}`}>
        <Sticker art={art} className="block h-full w-full" />
      </span>
    </span>
  );
}

export function Hero() {
  const [l1, l2, l3] = hero.lines;
  return (
    <section id="top" data-hero className="relative page-x" style={{ paddingTop: "calc(var(--frame) + var(--header-h))" }}>
      <div className="grid grid-cols-12 items-center gap-x-6 gap-y-16 pt-6 pb-16 lg:min-h-[calc(100svh-var(--frame)*2-var(--header-h))] lg:pt-0 lg:pb-0">
        <div className="col-span-12 lg:col-span-7">
          <h1 className="type-hero" aria-label={hero.lines.join(" ")}>
            <span className="flex items-center whitespace-nowrap" aria-hidden="true">
              <Line text={l1} i={0} />
              <InlineSticker art={no1Badge} size="ml-[0.08em] h-[0.86em] w-[0.86em]" nudge="-translate-y-[0.03em]" />
            </span>
            <span className="flex items-center whitespace-nowrap" aria-hidden="true">
              <InlineSticker art={flame} size="mr-[0.1em] h-[0.8em] w-[0.63em]" nudge="-translate-y-[0.02em]" />
              <Line text={l2} i={1} />
            </span>
            <span className="flex items-center whitespace-nowrap" aria-hidden="true">
              <Line text={l3} i={2} />
            </span>
          </h1>

          <ol data-intro data-hero-fade className="mt-10 grid max-w-[40rem] grid-cols-3 gap-6 lg:mt-12">
            {hero.steps.map((step) => (
              <li key={step.n}>
                <span className="type-caption block">{step.n}</span>
                <span className="type-display mt-1 block text-24 lg:text-32">{step.title}</span>
                <span className="type-caption mt-1 block">{step.caption}</span>
              </li>
            ))}
          </ol>

          <div data-intro data-hero-fade className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center">
            <Magnet padding={50} magnetStrength={4} wrapperClassName="w-full sm:w-auto" innerClassName="w-full">
              <PillLink href={cta.primary.href} arrow className="w-full">
                {cta.primary.label}
              </PillLink>
            </Magnet>
            <PillLink href={cta.secondary.href} variant="outline">
              {cta.secondary.label}
            </PillLink>
          </div>

          <p data-intro data-hero-fade className="type-label mt-5 flex items-center gap-2 text-14">
            <Star />
            <span>
              {hero.trust.rating} · {hero.trust.reviews} reviews
            </span>
          </p>
        </div>

        <div data-phone-col className="col-span-12 flex justify-center lg:col-span-5">
          {/* two layers, two owners: S1 moves the slot (glide to centre), S2 moves this wrapper
              (travel to the dock), so scrolling back fast can never leave the phone stranded */}
          <div data-phone-travel className="relative">
          <div data-phone-slot="hero" className="relative w-[min(60vw,300px)] lg:w-[min(23vw,340px)]">
            <div data-intro data-hero-phone>
              <LabelStudioPhone />
            </div>
            {phoneStickers.map(({ art, place, tilt }) => (
              <span key={art.id} data-float={art.id} data-intro className={`hero-float-sticker absolute ${place}`}>
                <span data-anchor className={`block ${tilt}`}>
                  <Sticker art={art} className="block h-auto w-full" />
                </span>
              </span>
            ))}
          </div>
          </div>
        </div>
      </div>
      <HeroMotion />
    </section>
  );
}
