import { LayoutTemplate, MousePointer2, Shapes, Type, Upload } from "lucide-react";
import { HoneyPiece, pieceSlotStyle } from "@/components/sections/how/HowVisuals";
import { Sticker } from "@/components/stickers/Sticker";
import { honeyBlank, honeyLabel, honeyPieces } from "@/components/stickers/art";
import { designChoice } from "@/data/copy";
import { C } from "@/lib/palette";

const dotted = { backgroundImage: "radial-gradient(circle, #d9d8d4 0.9px, transparent 1.3px)", backgroundSize: "3.6cqw 3.6cqw" };

/** Front: a mini Label Studio. Each artwork piece sits in its slot; motion slaps them in. */
export function DiyFace() {
  const tools = [LayoutTemplate, Type, Shapes, Upload];
  return (
    <div className="flex size-full overflow-hidden rounded-card bg-white" style={{ containerType: "inline-size" }}>
      <div className="flex w-[13cqw] shrink-0 flex-col items-center gap-[4cqw] border-r border-frame pt-[5cqw]">
        {tools.map((Icon, i) => (
          <span key={i} className={i === 1 ? "text-orange" : "text-ink"}>
            <Icon className="size-[4.4cqw]" strokeWidth={2} />
          </span>
        ))}
      </div>
      <div className="flex flex-1 flex-col">
        <div className="flex h-[11cqw] shrink-0 items-center justify-between bg-orange px-[4cqw] text-white">
          <span className="type-label text-[3.2cqw]">Label Studio</span>
          <span className="type-label text-[2.4cqw] opacity-90">Untitled · custom label</span>
        </div>
        <div className="relative flex-1" style={dotted}>
          <div className="absolute inset-x-[9%] top-1/2 -translate-y-1/2">
            <div className="relative">
              <Sticker art={honeyBlank} className="block w-full" />
              {honeyPieces.map((p) => (
                <span key={p.id} data-diy-piece className="absolute" style={pieceSlotStyle(p.id)}>
                  <HoneyPiece id={p.id} className="block h-full w-full" />
                </span>
              ))}
            </div>
          </div>
          <span data-diy-cursor className="absolute left-[64%] top-[36%] text-ink">
            <MousePointer2 className="size-[5cqw] fill-white" strokeWidth={2} />
          </span>
        </div>
        <div className="flex shrink-0 gap-[1.6cqw] px-[3cqw] pb-[3cqw]">
          {["Color", "Shape", "Finish", "Size"].map((chip, i) => (
            <span key={chip} className="type-label inline-flex h-[6.4cqw] items-center gap-[1.2cqw] rounded-chip border border-frame px-[2.6cqw] text-[2.4cqw]">
              {i === 0 && <span className="size-[2.2cqw] rounded-chip bg-marigold" />}
              {chip}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/** A wobbly hand-drawn line across [x0, x1] at height y, for the sketch's "text" blocks. */
function scribble(x0: number, x1: number, y: number, amp = 5) {
  let d = `M${x0} ${y}`;
  for (let x = x0; x < x1; x += 14) d += ` q7 ${-amp} 14 0`;
  return d;
}

const hexPath = (cx: number, cy: number, r: number) =>
  "M" +
  Array.from({ length: 6 }, (_, i) => {
    const a = (Math.PI / 3) * i + Math.PI / 6;
    return `${(cx + r * Math.cos(a)).toFixed(1)} ${(cy + r * Math.sin(a)).toFixed(1)}`;
  }).join(" L") +
  "Z";

/**
 * Back: the designer's desk. A pencil sketch of the label (DrawSVG strokes) that inks into
 * the finished label, a review note and the pencil that drew it.
 */
export function DfyFace() {
  const sketch = [
    "M12 26 Q12 12 28 12 L452 12 Q468 12 468 28 L468 172 Q468 188 452 188 L28 188 Q12 188 12 172 Z",
    "M16 30 Q15 15 32 15 L449 14 Q466 16 465 31 L466 169 Q464 186 448 185 L31 186 Q16 184 16 169 Z",
    "M26 32 Q26 25 34 25 L446 25 Q454 25 454 33 L454 167 Q454 175 446 175 L34 175 Q26 175 26 167 Z",
    hexPath(84, 84, 19),
    hexPath(119, 84, 19),
    hexPath(101.5, 114, 19),
    scribble(164, 440, 62, 7),
    scribble(164, 440, 84, 7),
    scribble(164, 420, 124, 4),
    scribble(164, 330, 156, 3),
  ];
  return (
    <div className="relative size-full overflow-hidden rounded-card bg-paper" style={{ containerType: "inline-size" }}>
      <div className="absolute inset-0 opacity-70" style={{ backgroundImage: "linear-gradient(rgb(10 10 10 / .05) 1px, transparent 1px)", backgroundSize: "100% 4.4cqw" }} />
      <span className="type-caption absolute left-[6%] top-[6%]">Design brief · draft</span>

      <div className="absolute inset-x-[9%] top-[24%]">
        <div className="relative">
          <svg viewBox="0 0 480 200" className="block w-full overflow-visible" aria-hidden="true">
            <g fill="none" stroke={C.inkSoft} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              {sketch.map((d, i) => (
                <path key={i} data-sketch d={d} />
              ))}
            </g>
          </svg>
          <div data-dfy-ink className="absolute inset-0">
            <Sticker art={honeyLabel} className="block w-full" />
          </div>
          {/* designer's markup */}
          <svg viewBox="0 0 120 60" className="absolute -right-[4%] -top-[30%] w-[26%] overflow-visible" aria-hidden="true">
            <path data-markup d="M100 8 C 70 4, 40 18, 30 46 M30 46 l-2 -12 M30 46 l11 -6" fill="none" stroke={C.orangeText} strokeWidth="3" strokeLinecap="round" />
          </svg>
          <span data-markup-text className="type-display absolute -right-[2%] -top-[38%] text-[3.4cqw] text-orange-text">
            Bigger?
          </span>
        </div>
      </div>

      <div data-dfy-note className="absolute bottom-[9%] left-[8%] w-[34%] -rotate-[5deg] rounded-[6px] bg-bubblegum p-[3cqw] outline-[4px] outline-white outline-solid">
        <span className="type-display block text-[4cqw] leading-[0.95] text-ink">{designChoice.dfy.note}</span>
        <span className="type-caption mt-[1.4cqw] block text-ink">[[DESIGNER_NAME]]</span>
      </div>

      <svg data-dfy-pencil viewBox="0 0 240 36" className="absolute bottom-[14%] right-[6%] w-[44%] -rotate-[24deg]" aria-hidden="true">
        <rect x="40" y="4" width="160" height="28" rx="3" fill={C.marigold} />
        <rect x="40" y="4" width="160" height="9" fill={C.white} opacity=".25" />
        <rect x="200" y="4" width="16" height="28" fill={C.frame} />
        <rect x="216" y="4" width="20" height="28" rx="6" fill={C.bubblegum} />
        <path d="M40 4 L6 18 L40 32 Z" fill={C.frame} stroke={C.inkSoft} strokeWidth="1.2" strokeLinejoin="round" />
        <path d="M16 14 L6 18 L16 22 Z" fill={C.ink} />
      </svg>
    </div>
  );
}
