"use client";

import { useRef, useState } from "react";
import { DfyFace, DiyFace } from "@/components/sections/design/DesignFaces";
import { FinishChips } from "@/components/sections/wrap/FinishChips";
import { PillLink } from "@/components/ui/Pill";
import { SectionHead } from "@/components/ui/SectionHead";
import { designChoice } from "@/data/copy";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags, prefersReducedMotion } from "@/lib/motion";

type Option = (typeof designChoice.options)[number];

/**
 * Your art or ours. Two ways to get a label: design it yourself in Label Studio, or have a
 * Label Bros designer do it. One two-sided card flips between them (signature: it slaps onto
 * the page as the section arrives). The text panel always carries the full information.
 */
export function DesignChoice() {
  const [mode, setMode] = useState(0);
  const root = useRef<HTMLElement>(null);
  const flipped = useRef(false);

  // the little beat each side plays when it comes up
  const diyIn = () => {
    const q = gsap.utils.selector(root);
    return gsap
      .timeline()
      .fromTo(
        q("[data-diy-piece]"),
        { x: (i: number) => [-90, 70, -60, 80][i], y: (i: number) => [-70, -40, 60, 50][i], rotation: (i: number) => [-30, 24, -18, 20][i], scale: 1.3, opacity: 0 },
        { x: 0, y: 0, rotation: 0, scale: 1, opacity: 1, duration: 0.9, ease: "slap", stagger: 0.07 },
      )
      .fromTo(q("[data-diy-cursor]"), { x: -60, y: 50, opacity: 0 }, { x: 0, y: 0, opacity: 1, duration: 0.6, ease: "expo.out" }, 0.2);
  };
  const dfyIn = () => {
    const q = gsap.utils.selector(root);
    return gsap
      .timeline()
      .fromTo(q("[data-dfy-pencil]"), { x: 60, y: 30, opacity: 0 }, { x: 0, y: 0, opacity: 1, duration: 0.6, ease: "expo.out" }, 0)
      .fromTo(q("[data-sketch]"), { drawSVG: "0% 0%" }, { drawSVG: "0% 100%", duration: 0.55, ease: "power2.inOut", stagger: 0.05 }, 0.05)
      .fromTo(q("[data-dfy-ink]"), { opacity: 0, scale: 0.97 }, { opacity: 1, scale: 1, duration: 0.6, ease: "expo.out" }, 0.85)
      .fromTo(q("[data-markup]"), { drawSVG: "0% 0%" }, { drawSVG: "0% 100%", duration: 0.4, ease: "power2.inOut" }, 1.1)
      .fromTo(q("[data-markup-text]"), { opacity: 0, y: 6 }, { opacity: 1, y: 0, duration: 0.35, ease: "expo.out" }, 1.3)
      .fromTo(q("[data-dfy-note]"), { scale: 1.4, rotation: -20, opacity: 0 }, { scale: 1, rotation: -5, opacity: 1, duration: 0.9, ease: "slap" }, 1.15);
  };

  // entrance: the card slaps onto the page, then the editor pieces snap in
  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ, (ctx) => {
        if (motionFlags(ctx.conditions).reduceMotion) return;
        gsap
          .timeline({ scrollTrigger: { trigger: "[data-flip-scene]", start: "top 70%", once: true } })
          .from("[data-flip-scene]", { scale: 1.25, rotation: -10, y: -40, opacity: 0, duration: 0.9, ease: "slap" })
          .add(diyIn(), 0.45);
      });
    },
    { scope: root },
  );

  // the flip
  useGSAP(
    () => {
      const card = root.current?.querySelector("[data-flip-card]");
      if (!card) return;
      if (!flipped.current) {
        flipped.current = true;
        gsap.set(card, { rotationY: mode * 180 });
        return;
      }
      if (prefersReducedMotion()) {
        gsap.set(card, { rotationY: mode * 180 });
        return;
      }
      gsap
        .timeline()
        .to(card, { rotationY: mode * 180, duration: 0.9, ease: "slap", overwrite: true }, 0)
        .to("[data-flip-scene]", { scale: 1.04, duration: 0.3, yoyo: true, repeat: 1, ease: "power2.inOut" }, 0)
        .add(mode === 0 ? diyIn() : dfyIn(), 0.3);
    },
    { dependencies: [mode], scope: root, revertOnUpdate: false },
  );

  const side = mode === 0 ? designChoice.diy : designChoice.dfy;
  return (
    <section ref={root} id="design" aria-labelledby="design-title" className="relative page-x py-24 lg:py-32">
      <div className="grid grid-cols-12 items-center gap-x-6 gap-y-12">
        <div className="col-span-12 lg:col-span-5 lg:row-start-1 lg:self-end">
          <SectionHead id="design-title" eyebrow={designChoice.eyebrow} title={designChoice.title} />
          <div className="mt-8">
            <FinishChips<Option>
              label="Who designs your label"
              options={designChoice.options}
              value={designChoice.options[mode]}
              onChange={(v) => setMode(designChoice.options.indexOf(v))}
            />
          </div>
        </div>

        <div className="col-span-12 flex justify-center lg:col-span-7 lg:col-start-6 lg:row-span-2 lg:row-start-1">
          <div data-flip-scene className="relative aspect-[5/4] w-[min(88vw,560px)]" style={{ perspective: "1600px" }} aria-hidden="true">
            <div data-flip-card className="relative size-full transform-3d">
              <div className="absolute inset-0 rounded-card outline-[7px] outline-white outline-solid backface-hidden">
                <DiyFace />
              </div>
              <div className="absolute inset-0 rotate-y-180 rounded-card outline-[7px] outline-white outline-solid backface-hidden">
                <DfyFace />
              </div>
            </div>
          </div>
        </div>

        <div aria-live="polite" className="col-span-12 lg:col-span-5 lg:row-start-2 lg:self-start">
          <h3 className="type-display text-48">{side.name}</h3>
          <p className="mt-3 max-w-[30rem] text-18 leading-[1.45]">{side.line}</p>
          <ul className="mt-8 grid grid-cols-3 gap-6">
            {side.points.map((p, i) => (
              <li key={p.title}>
                <span className="type-caption block">{String(i + 1).padStart(2, "0")}</span>
                <span className="type-display mt-1 block text-24">{p.title}</span>
                <span className="type-caption mt-1 block">{p.caption}</span>
              </li>
            ))}
          </ul>
          <PillLink href={side.cta.href} arrow className="mt-10">
            {side.cta.label}
          </PillLink>
        </div>
      </div>
    </section>
  );
}
