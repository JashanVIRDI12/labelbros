"use client";

import { useRef } from "react";
import { gsap, ScrollTrigger, SplitText, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags, snapEnabled } from "@/lib/motion";
import { setProgress, setSceneActive } from "@/lib/scrollStore";

const rect = (el: Element) => el.getBoundingClientRect();
const centre = (el: Element) => {
  const r = rect(el);
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
};
const cssWidth = (el: Element) => parseFloat(getComputedStyle(el).width) || rect(el).width;

/**
 * S2 motion.
 * Desktop (signature): the hero phone travels down and docks (scrubbed, power2.inOut), then
 * the section pins (+250%) and one timeline plays DESIGN → PROOF → PRINT → STICK with snapping.
 * Touch: four cards, one mini-animation each. Reduced motion: static cards (nothing here).
 */
export function HowMotion() {
  const scope = useRef<HTMLElement | null>(null);

  useGSAP(
    () => {
      const maybeRoot = scope.current;
      if (!maybeRoot) return;
      const root: HTMLElement = maybeRoot;
      const q = gsap.utils.selector(root);
      const mm = gsap.matchMedia();

      mm.add(MQ, (ctx) => {
        const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
        if (reduceMotion) return;

        if (!isDesktop) {
          playCards();
          return;
        }

        // the step copy is split into lines, so wait for the display font
        let alive = true;
        let teardown = () => {};
        document.fonts.ready.then(() => {
          if (alive) ctx.add(() => (teardown = buildStage()));
        });
        return () => {
          alive = false;
          teardown();
        };
      });

      /** Touch: each card's step plays once as it scrolls in. */
      function playCards() {
        q("[data-step-card]").forEach((card, i) => {
          const $ = (s: string) => card.querySelectorAll(s);
          const tl = gsap.timeline({ scrollTrigger: { trigger: card, start: "top 70%", toggleActions: "play none none reverse" } });
          if (i === 0)
            tl.from($("[data-card-piece]"), {
              x: (j: number) => [-70, 80][j],
              y: (j: number) => [-50, 60][j],
              rotation: (j: number) => [-40, 30][j],
              opacity: 0,
              ease: "slap",
              duration: 0.9,
              stagger: 0.08,
            });
          if (i === 1)
            tl.fromTo($("[data-card-stamp]"), { scale: 1.8, rotation: -24, opacity: 0 }, { scale: 1, rotation: -10, opacity: 1, ease: "slap", duration: 0.7 });
          if (i === 2)
            tl.fromTo($("[data-card-print]"), { clipPath: "inset(0 100% 0 0)" }, { clipPath: "inset(0 0% 0 0)", ease: "power2.inOut", duration: 0.9 });
          if (i === 3)
            tl.fromTo($("[data-card-cut]"), { drawSVG: "0% 0%" }, { drawSVG: "0% 100%", duration: 0.7, ease: "power2.inOut" }).fromTo(
              $("[data-card-label]"),
              { rotation: 0, yPercent: 0 },
              { rotation: -6, yPercent: -10, duration: 0.6, ease: "slap" },
              "-=0.15",
            );
        });
      }

      /** Desktop: travel + pinned four-step timeline. Returns its own cleanup. */
      function buildStage() {
        const heroSection = document.querySelector<HTMLElement>("[data-hero]");
        const heroSlot = document.querySelector<HTMLElement>('[data-phone-slot="hero"]');
        const heroTravel = document.querySelector<HTMLElement>("[data-phone-travel]");
        const heroCol = document.querySelector<HTMLElement>("[data-phone-col]");
        const heroArt = heroSlot ? heroSlot.querySelectorAll("[data-hero-art], [data-dieline], [data-handle], [data-dimension]") : [];
        const heroST = ScrollTrigger.getById("hero");
        const dock = q('[data-phone-slot="how"]')[0];
        const dockPhone = dock.querySelector("[data-phone]")!;

        // ---------- the phone docks (one phone on screen at a time) ----------
        const sheetWrap = q("[data-sheet-wrap]")[0];
        const sheetIn = gsap.fromTo(
          sheetWrap,
          { y: -70, rotation: -16, scale: 1.12, opacity: 0 },
          { y: 0, rotation: 0, scale: 1, opacity: 1, duration: 0.9, ease: "slap", paused: true },
        );
        const docked = (on: boolean) => {
          if (on) sheetIn.play();
          else sheetIn.reverse();
          if (heroSlot) gsap.set(heroSlot, { autoAlpha: on ? 0 : 1 });
          gsap.set(dockPhone, { autoAlpha: on ? 1 : 0 });
        };
        gsap.set(dockPhone, { autoAlpha: 0 });

        if (heroSlot && heroTravel && heroCol && heroSection && heroST) {
          const heroCentreX = () => window.innerWidth / 2 - centre(heroCol).x;
          // where the hero slot must sit (relative to its own layout box) to cover the dock slot when
          // S2's top reaches the top of the viewport. S2 starts right after the hero's pin spacer.
          const toX = () => centre(dock).x - centre(heroCol).x;
          const toY = () => {
            const dockOff = rect(dock).top - rect(root).top + dock.offsetHeight / 2;
            const heroOff = rect(heroCol).top - rect(heroSection).top + heroCol.offsetHeight / 2;
            return dockOff + heroSection.offsetHeight - heroOff;
          };
          // the wrapper scales about its own centre, while the slot inside already sits heroCentreX
          // off-centre at scale .92; solve for the wrapper's own move so the slot lands on the dock
          const HERO_SCALE = 0.92;
          const travelScale = () => dock.offsetWidth / (heroSlot.offsetWidth * HERO_SCALE);
          const travelX = () => toX() - travelScale() * heroCentreX();

          gsap
            .timeline({
              scrollTrigger: {
                id: "how-travel",
                trigger: root,
                start: () => heroST.end,
                end: "top top",
                scrub: 1,
                invalidateOnRefresh: true,
                refreshPriority: 90,
              },
            })
            .fromTo(heroTravel, { x: 0, y: 0, scale: 1 }, { x: travelX, y: toY, scale: travelScale, ease: "power2.inOut", duration: 1, immediateRender: false }, 0)
            // a fresh, blank template arrives: the hero's artwork clears early in the trip, so DESIGN
            // builds something new instead of rebuilding what we just saw
            .to(heroArt, { autoAlpha: 0, duration: 0.3, ease: "none" }, 0);
        }

        // ---------- copy: one SplitText per step, swapped through line masks ----------
        const steps = q("[data-step]");
        const splits = steps.map((step) => SplitText.create(step.querySelectorAll("[data-split]"), { type: "lines", mask: "lines", aria: "none" }));
        steps.forEach((step, i) => {
          gsap.set(step, { opacity: 1 });
          if (i > 0) gsap.set(splits[i].lines, { yPercent: 110 });
        });
        const fills = q("[data-rail-fill]");

        // ---------- DESIGN: pieces fly from the sheet into their slots ----------
        const pieces = q("[data-sheet] [data-piece]");
        const fit = new Map<Element, { x: number; y: number; scale: number }>();
        const measure = () => {
          const s = sheetIn.progress();
          sheetIn.progress(1); // measure with the sheet in its docked pose
          for (const piece of pieces) {
            const slot = q(`[data-slot="${piece.getAttribute("data-piece")}"]`)[0];
            const a = centre(piece);
            const b = centre(slot);
            fit.set(piece, { x: b.x - a.x, y: b.y - a.y, scale: slot.offsetWidth / cssWidth(piece) });
          }
          sheetIn.progress(s);
        };
        measure();

        const stamp = q("[data-stamp]")[0];
        const print = q("[data-print]")[0];
        const cutline = q("[data-cutline]")[0];
        const label = q("[data-label]")[0];
        const labelArt = q("[data-label-art]")[0];
        const cut = { v: 0 };

        const swap = (from: number, to: number, at: number) => {
          tl.to(splits[from].lines, { yPercent: -110, duration: 0.14, stagger: 0.02 }, at - 0.12)
            .fromTo(splits[to].lines, { yPercent: 110 }, { yPercent: 0, duration: 0.18, stagger: 0.03 }, at)
            .to(fills[from], { opacity: 0, duration: 0.1 }, at)
            .to(fills[to], { opacity: 1, duration: 0.1 }, at);
        };

        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: {
            id: "how",
            trigger: root,
            start: "top top",
            end: "+=250%",
            pin: true,
            pinSpacing: true,
            anticipatePin: 1,
            scrub: 1,
            refreshPriority: 80,
            invalidateOnRefresh: true,
            snap: snapEnabled() ? { snapTo: "labels", duration: { min: 0.2, max: 0.6 }, ease: "power1.inOut", delay: 0.08 } : undefined,
            onRefreshInit: () => {
              // measure the pieces at their start positions
              const p = tl.progress();
              tl.progress(0);
              measure();
              tl.progress(p);
            },
            onEnter: () => docked(true),
            onEnterBack: () => docked(true),
            onLeaveBack: () => docked(false),
          },
        });

        tl.addLabel("start", 0);
        pieces.forEach((piece, i) => {
          tl.to(
            piece,
            {
              x: () => fit.get(piece)!.x,
              y: () => fit.get(piece)!.y,
              scale: () => fit.get(piece)!.scale,
              rotation: 0,
              transformOrigin: "50% 50%",
              duration: 0.5,
              ease: "power2.inOut",
            },
            0.1 + i * 0.06,
          );
        });
        // the sheet stays docked; only its empty kiss-cut outlines remain
        tl.set(pieces, { opacity: 0 }, 0.82).set(labelArt, { opacity: 1 }, 0.82).addLabel("design", 0.85);

        // ---------- PROOF: the stamp slaps on (the one non-linear ease in the scrub) ----------
        swap(0, 1, 1);
        tl.fromTo(stamp, { scale: 1.8, rotation: -24, opacity: 0 }, { scale: 1, rotation: -10, opacity: 1, duration: 0.35, ease: "slap" }, 1.15).addLabel(
          "proof",
          1.85,
        );

        // ---------- PRINT: halftone / registration sheet wipes in (clip-path moment 1 of 2) ----------
        swap(1, 2, 2);
        // the artwork splits into ink separations that land off-register and snap together as the
        // printed sheet wipes in
        const ghosts = q("[data-ghost]");
        const offs = [
          [-14, -9],
          [12, 8],
          [5, -12],
        ];
        tl.to(stamp, { opacity: 0, scale: 0.9, duration: 0.2 }, 2.0)
          .fromTo(print, { clipPath: "inset(0 100% 0 0)" }, { clipPath: "inset(0 0% 0 0)", duration: 0.6 }, 2.05)
          .to(labelArt, { opacity: 0, duration: 0.04 }, 2.04)
          .fromTo(ghosts, { opacity: 0, x: (i: number) => offs[i][0], y: (i: number) => offs[i][1] }, { opacity: 0.9, duration: 0.05 }, 2.04)
          .to(ghosts, { x: 0, y: 0, duration: 0.5, stagger: 0.04 }, 2.1)
          .to(labelArt, { opacity: 1, duration: 0.06 }, 2.66)
          .to(ghosts, { opacity: 0, duration: 0.06 }, 2.68)
          .addLabel("print", 2.85);

        // ---------- STICK: die line draws, the kiss-cut label lifts off (3D) and flies toward S3 ----------
        swap(2, 3, 3);
        tl.fromTo(cutline, { drawSVG: "0% 0%" }, { drawSVG: "0% 100%", duration: 0.35 }, 3.02)
          .to(
            cut,
            {
              v: 1,
              duration: 0.55,
              onUpdate: () => {
                setProgress("cut", cut.v);
                setSceneActive("how", cut.v > 0);
                root.classList.toggle("is-cutting", cut.v > 0.002);
              },
            },
            3.4,
          )
          // 2D fallback (CSS hides the DOM label while its 3D copy owns the moment)
          .to(label, { rotation: -8, y: -24, duration: 0.18, transformOrigin: "0% 100%" }, 3.4)
          .to(label, { y: () => window.innerHeight * 0.9, rotation: 16, opacity: 0, duration: 0.37 }, 3.58)
          // snap rests at the peak of the lift (the curl mid-air), not after the label has gone
          .addLabel("stick", 3.62)
          .addLabel("end");

        ScrollTrigger.sort();
        ScrollTrigger.refresh();
        docked((tl.scrollTrigger?.progress ?? 0) > 0 || window.scrollY > (tl.scrollTrigger?.start ?? Infinity));

        return () => {
          setSceneActive("how", false);
          root.classList.remove("is-cutting");
          if (heroSlot) gsap.set(heroSlot, { clearProps: "visibility,opacity" });
        };
      }
    },
    { scope },
  );

  return (
    <span
      hidden
      ref={(el) => {
        scope.current = el?.closest("section") ?? null;
      }}
    />
  );
}
