import { Sticker } from "@/components/stickers/Sticker";
import { approvedStamp, HONEY, honeyArtOnly, honeyBlank, honeyLabel, honeyPieces } from "@/components/stickers/art";
import { cn } from "@/lib/utils";

const pct = (n: number, of: number) => `${(n / of) * 100}%`;

/** One honey-label artwork piece as its own little sticker, cropped to its box. */
export function HoneyPiece({
  id,
  className,
  style,
  ...rest
}: { id: string; className?: string; style?: React.CSSProperties } & { "data-piece"?: string }) {
  const piece = honeyPieces.find((p) => p.id === id)!;
  const { x, y, w, h } = piece.box;
  return (
    <svg
      {...rest}
      data-sticker
      viewBox={`${x} ${y} ${w} ${h}`}
      className={className}
      style={style}
      aria-hidden="true"
      focusable="false"
      dangerouslySetInnerHTML={{ __html: piece.svg }}
    />
  );
}

/** Where each piece sits on the label, as % of the label box (Flip targets in S2). */
export function pieceSlotStyle(id: string): React.CSSProperties {
  const { x, y, w, h } = honeyPieces.find((p) => p.id === id)!.box;
  return { left: pct(x, HONEY.w), top: pct(y, HONEY.h), width: pct(w, HONEY.w), height: pct(h, HONEY.h) };
}

/** CMYK-style registration mark, in our palette. */
function RegMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={cn("absolute size-[5cqw]", className)} aria-hidden="true">
      <circle cx="12" cy="12" r="6" fill="none" stroke="#0A0A0A" strokeWidth="1.2" />
      <path d="M12 0v24M0 12h24" stroke="#0A0A0A" strokeWidth="1.2" />
    </svg>
  );
}

/**
 * The docked phone's canvas in S2. Layers, bottom to top:
 * print sheet (wiped in for PRINT) · blank label + piece slots (DESIGN) · die line (STICK) · stamp (PROOF).
 */
export function HowCanvas() {
  return (
    <>
      {/* solid-colour filters for the ink separations (palette stand-ins for C, M, K) */}
      <svg aria-hidden="true" className="absolute size-0">
        <defs>
          {[
            ["peri", "#565DC5"],
            ["gum", "#F89ABC"],
            ["ink", "#0A0A0A"],
          ].map(([id, color]) => (
            <filter key={id} id={`lb-sep-${id}`} colorInterpolationFilters="sRGB">
              <feFlood floodColor={color} />
              <feComposite in2="SourceAlpha" operator="in" />
            </filter>
          ))}
        </defs>
      </svg>
      <div data-print className="absolute inset-0 bg-white" style={{ clipPath: "inset(0 100% 0 0)" }}>
        <div
          className="absolute inset-0 opacity-60"
          style={{ backgroundImage: "radial-gradient(circle, #F89ABC 0.7px, transparent 1.1px)", backgroundSize: "3.2cqw 3.2cqw" }}
        />
        <RegMark className="left-[5%] top-[5%]" />
        <RegMark className="right-[5%] top-[5%]" />
        <RegMark className="bottom-[5%] left-[5%]" />
        <RegMark className="bottom-[5%] right-[5%]" />
        <div className="absolute bottom-[6%] left-1/2 flex -translate-x-1/2 gap-[1.2cqw]">
          {["bg-periwinkle", "bg-bubblegum", "bg-marigold", "bg-ink"].map((c) => (
            <span key={c} className={cn("size-[4cqw]", c)} />
          ))}
        </div>
      </div>

      {/* data-label-anchor: never animated, so 3D can measure the label's resting place */}
      <div data-label-anchor className="absolute inset-x-[5%] top-[46%] -translate-y-1/2">
        <div data-label className="relative">
          <Sticker art={honeyBlank} className="block w-full" />
          {honeyPieces.map((p) => (
            <div key={p.id} data-slot={p.id} className="absolute" style={pieceSlotStyle(p.id)} />
          ))}
          {/* PRINT: three ink separations land off-register, then snap into register */}
          {(["peri", "gum", "ink"] as const).map((ink) => (
            <span key={ink} data-ghost={ink} className="absolute inset-0 opacity-0 mix-blend-multiply" style={{ filter: `url(#lb-sep-${ink})` }}>
              <Sticker art={honeyArtOnly} className="block h-full w-full" />
            </span>
          ))}
          {/* after DESIGN the flown pieces swap for this identical layer, so the label lifts as one */}
          <span data-label-art className="absolute inset-0 opacity-0">
            <Sticker art={honeyArtOnly} className="block h-full w-full" />
          </span>
        </div>
        <svg viewBox="0 0 480 200" className="pointer-events-none absolute inset-0 h-full w-full overflow-visible">
            <rect
              data-cutline
              x="-12"
              y="-12"
              width="504"
              height="224"
              rx="34"
              fill="none"
              stroke="#0A0A0A"
              strokeWidth="2"
              strokeDasharray="0 1"
              vectorEffect="non-scaling-stroke"
            />
        </svg>
      </div>

      <div className="absolute left-1/2 top-[70%] w-[62%] -translate-x-1/2">
        <div data-stamp className="opacity-0" style={{ transform: "rotate(-10deg)" }}>
          <Sticker art={approvedStamp} className="block w-full" />
        </div>
      </div>
    </>
  );
}

/**
 * Small illustrations for the touch / reduced-motion step cards, drawn in their final state.
 * Touch plays one mini-animation per card (data-card-* hooks): pieces fly in, stamp, wipe, cut.
 */
export function StepIllustration({ step }: { step: number }) {
  const dotted = { backgroundImage: "radial-gradient(circle, #d9d8d4 0.9px, transparent 1.3px)", backgroundSize: "4cqw 4cqw" };
  return (
    <div className="relative aspect-[4/3] overflow-hidden rounded-card bg-white" style={{ containerType: "inline-size", ...dotted }} aria-hidden="true">
      {step === 0 && (
        <>
          <Sticker art={honeyLabel} className="absolute left-[10%] top-[30%] w-[80%]" />
          <span data-card-piece className="absolute left-[6%] top-[8%] w-[16%]">
            <HoneyPiece id="comb" className="block w-full -rotate-12" />
          </span>
          <span data-card-piece className="absolute bottom-[8%] right-[8%] w-[34%]">
            <HoneyPiece id="small" className="block w-full rotate-6" />
          </span>
        </>
      )}
      {step === 1 && (
        <>
          <Sticker art={honeyLabel} className="absolute left-[10%] top-[18%] w-[80%]" />
          <div className="absolute bottom-[10%] left-[22%] w-[56%]">
            <div data-card-stamp style={{ transform: "rotate(-10deg)" }}>
              <Sticker art={approvedStamp} className="block w-full" />
            </div>
          </div>
        </>
      )}
      {step === 2 && (
        <>
          <div data-card-print className="absolute inset-0 bg-white">
            <div
              className="absolute inset-0 opacity-60"
              style={{ backgroundImage: "radial-gradient(circle, #F89ABC 0.7px, transparent 1.1px)", backgroundSize: "2.4cqw 2.4cqw" }}
            />
            <RegMark className="left-[4%] top-[5%]" />
            <RegMark className="right-[4%] top-[5%]" />
            <div className="absolute bottom-[8%] left-1/2 flex -translate-x-1/2 gap-[1.2cqw]">
              {["bg-periwinkle", "bg-bubblegum", "bg-marigold", "bg-ink"].map((c) => (
                <span key={c} className={cn("size-[4cqw]", c)} />
              ))}
            </div>
          </div>
          <Sticker art={honeyLabel} className="absolute left-[10%] top-[24%] w-[80%]" />
        </>
      )}
      {step === 3 && (
        <>
          <svg viewBox="0 0 480 200" className="absolute left-[12%] top-[26%] w-[74%] overflow-visible">
            <rect data-card-cut x="-12" y="-12" width="504" height="224" rx="34" fill="none" stroke="#0A0A0A" strokeWidth="2" vectorEffect="non-scaling-stroke" />
          </svg>
          <div data-card-label className="absolute left-[12%] top-[26%] w-[74%] origin-bottom-left" style={{ transform: "rotate(-6deg)" }}>
            <Sticker art={honeyLabel} className="block w-full" />
          </div>
        </>
      )}
    </div>
  );
}
