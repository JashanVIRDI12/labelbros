"use client";
import { useSyncExternalStore } from "react";
import GlareHover from "@/components/ui/GlareHover";
import { REDUCE_EVENT, userReducedMotion } from "@/lib/motion";

const subscribe = (cb: () => void) => { window.addEventListener(REDUCE_EVENT, cb); return () => window.removeEventListener(REDUCE_EVENT, cb); };
export function ProductGlare({ children }: { children: React.ReactNode }) {
  const reduce = useSyncExternalStore(subscribe, userReducedMotion, () => false);
  if (reduce) return <div className="h-full">{children}</div>;
  return <GlareHover className="h-full w-full" width="100%" height="100%" borderRadius="20px" borderColor="transparent" glareOpacity={0.24} rimGlint={false} transitionDuration={350}>{children}</GlareHover>;
}
