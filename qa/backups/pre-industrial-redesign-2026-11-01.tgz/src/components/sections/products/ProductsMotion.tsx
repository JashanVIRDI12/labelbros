"use client";

import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags } from "@/lib/motion";
import { setProgress, setSceneActive } from "@/lib/scrollStore";

export function ProductsMotion() {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(() => {
    const root = scope.current;
    if (!root) return;
    const q = gsap.utils.selector(root);
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
      if (reduceMotion) return;
      const cards = q("[data-card]");
      const viewport = q("[data-track-viewport]")[0];
      if (!isDesktop) {
        const io = new IntersectionObserver((entries) => ctx.add(() => {
          entries.filter((e) => e.isIntersecting).forEach((e) => {
            gsap.from(e.target, { rotationX: -12, y: 24, duration: 0.9, ease: "slap", transformOrigin: "50% 100%" });
            io.unobserve(e.target);
          });
        }), { root: viewport, threshold: 0.5 });
        cards.forEach((c) => io.observe(c));
        return () => io.disconnect();
      }
      const track = q("[data-track]")[0];
      const travel = () => Math.max(0, track.scrollWidth - window.innerWidth);
      const counter = q("[data-counter]")[0];
      const articles = q("[data-product]");
      let index = -1;
      const move = gsap.to(track, {
        x: () => -travel(), ease: "none",
        scrollTrigger: {
          id: "products", trigger: root, start: "top top", end: () => `+=${track.scrollWidth}`,
          pin: true, pinSpacing: true, anticipatePin: 1, scrub: 1, invalidateOnRefresh: true, refreshPriority: 60,
          onUpdate: (self) => {
            setProgress("roll", self.progress);
            const next = Math.min(cards.length - 1, Math.round(self.progress * (cards.length - 1)));
            if (next !== index) { index = next; counter.textContent = String(next + 1).padStart(2, "0"); }
          },
          onToggle: (self) => setSceneActive("products", self.isActive),
        },
      });
      gsap.to(q("[data-roll]"), { rotation: 1440, ease: "none", scrollTrigger: {
        trigger: root, start: () => move.scrollTrigger!.start, end: () => move.scrollTrigger!.end, scrub: 1, refreshPriority: 59,
      } });
      cards.forEach((card, i) => gsap.from(card, {
        rotationX: -12, y: 24, duration: 0.9, ease: "slap", transformOrigin: "50% 100%",
        scrollTrigger: { trigger: articles[i], containerAnimation: move, start: "left 80%", toggleActions: "play none none reverse" },
      }));
      // Keyboard focus moves the pin to the focused product instead of leaving an off-screen link.
      const focus = (e: FocusEvent) => {
        const card = (e.target as Element).closest("[data-product]") as HTMLElement | null;
        if (!card) return;
        const distance = Math.max(0, Math.min(travel(), card.offsetLeft - window.innerWidth * 0.3));
        const st = move.scrollTrigger!;
        window.scrollTo(0, st.start + distance / Math.max(1, travel()) * (st.end - st.start));
      };
      root.addEventListener("focusin", focus);
      return () => { root.removeEventListener("focusin", focus); setSceneActive("products", false); };
    });
  }, { scope });
  return <span hidden ref={(el) => { scope.current = el?.closest("section") ?? null; }} />;
}
