"use client";

import Image from "next/image";
import { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";
import { getTier, prefersReducedMotion } from "@/lib/motion";
import { finishSticker } from "@/components/stickers/productArt";
import type { Material } from "@/data/materials";
import { cn } from "@/lib/utils";

const maskUrl = `url("data:image/svg+xml;utf8,${encodeURIComponent(
  `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 320'><path d='${finishSticker.shape}'/></svg>`,
)}")`;

/**
 * 2D stand-in for the S5 3D sticker: the finish (CSS swatch) masked to the scalloped die-cut,
 * a white die-cut border behind, and the ink layer on top (ink stays the same on every finish).
 */
export function FinishSticker2D({ material, className }: { material: Material; className?: string }) {
  const scope = useRef<HTMLDivElement>(null);
  useGSAP(() => {
    if (getTier() !== "low" || prefersReducedMotion()) return;
    gsap.fromTo(scope.current, { clipPath: "circle(0% at 50% 50%)" }, { clipPath: "circle(75% at 50% 50%)", duration: 0.6, ease: "expo.out" });
  }, { scope, dependencies: [material.id], revertOnUpdate: true });
  return (
    <div ref={scope} className={cn("relative aspect-square", className)} aria-hidden="true">
      <svg viewBox="0 0 320 320" className="absolute inset-0 h-full w-full overflow-visible">
        <path d={finishSticker.shape} fill="#FFFFFF" stroke="#FFFFFF" strokeWidth="16" strokeLinejoin="round" />
      </svg>
      <div
        data-finish-base
        className="absolute inset-0"
        style={{
          background: material.swatch,
          WebkitMask: `${maskUrl} center / contain no-repeat`,
          mask: `${maskUrl} center / contain no-repeat`,
          opacity: material.id === "clear" ? 0.55 : 1,
        }}
      />
      <svg
        data-sticker
        viewBox="0 0 320 320"
        className="absolute inset-0 h-full w-full"
        dangerouslySetInnerHTML={{ __html: finishSticker.ink }}
      />
      <Image src={`/posters/finish-${material.id}.avif`} alt="" fill sizes="(min-width:1024px) 460px, 240px" className="finish-poster hidden object-contain" />
    </div>
  );
}
