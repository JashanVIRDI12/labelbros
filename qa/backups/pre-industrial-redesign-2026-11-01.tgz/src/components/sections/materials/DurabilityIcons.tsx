import { Droplet, Shield, Sun, Undo2 } from "lucide-react";
import { durabilityLabel, type Durability } from "@/data/materials";

const icons = { waterproof: Droplet, uv: Sun, scratch: Shield, removable: Undo2 } as const;

/** 2px line icons. Phrasing content only, because it sits inside a button. */
export function DurabilityIcons({ list }: { list: Durability[] }) {
  return (
    <span className="flex items-center gap-2">
      <span className="sr-only">{list.map((d) => durabilityLabel[d]).join(", ")}</span>
      {list.map((d) => {
        const Icon = icons[d];
        return (
          <span key={d} title={durabilityLabel[d]} className="flex size-8 items-center justify-center rounded-chip border border-ink/15" aria-hidden="true">
            <Icon className="size-4" strokeWidth={2} />
          </span>
        );
      })}
    </span>
  );
}
