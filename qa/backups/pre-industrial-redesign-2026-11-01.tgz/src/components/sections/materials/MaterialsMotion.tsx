"use client";

import { useRef } from "react";
import { materials } from "@/data/materials";
import { gsap, ScrollTrigger, useGSAP } from "@/lib/gsap";
import { MQ, motionFlags, snapEnabled } from "@/lib/motion";
import { setProgress, setSceneActive } from "@/lib/scrollStore";

export function MaterialsMotion({ onActive }: { onActive: (n: number) => void }) {
  const scope = useRef<HTMLElement | null>(null);
  useGSAP(() => {
    const root = scope.current;
    if (!root) return;
    const mm = gsap.matchMedia();
    mm.add(MQ, (ctx) => {
      const { isDesktop, reduceMotion } = motionFlags(ctx.conditions);
      if (reduceMotion) return;
      let last = -1;
      const position = { n: 0 };
      const tint = root.querySelector("[data-tint]");
      const tl = gsap.to(position, {
        n: materials.length - 1, ease: "none",
        onUpdate: () => {
          setProgress("finish", position.n);
          const next = Math.round(position.n);
          if (last === next) return;
          last = next;
          setProgress("finishIndex", next);
          onActive(next);
        },
        scrollTrigger: {
          id: "materials", trigger: root, start: "top top", end: `+=${materials.length * (isDesktop ? 60 : 35)}%`,
          pin: true, pinSpacing: true, anticipatePin: 1, scrub: 1, refreshPriority: 50,
          snap: snapEnabled() ? { snapTo: 1 / (materials.length - 1), duration: { min: 0.2, max: 0.6 }, ease: "power2.inOut" } : undefined,
          onToggle: (self) => setSceneActive("materials", self.isActive),
        },
      });
      gsap.set(tint, { opacity: 1 });
      const buttons = [...root.querySelectorAll<HTMLButtonElement>("[data-material]")];
      const jump = (e: Event) => {
        const i = Number((e.currentTarget as HTMLElement).dataset.material);
        const st = tl.scrollTrigger!;
        window.scrollTo({ top: st.start + i / (materials.length - 1) * (st.end - st.start), behavior: "instant" });
      };
      buttons.forEach((b) => b.addEventListener("click", jump));
      ScrollTrigger.sort();
      ScrollTrigger.refresh();
      return () => {
        buttons.forEach((b) => b.removeEventListener("click", jump));
        setSceneActive("materials", false);
      };
    });
  }, { scope, dependencies: [onActive] });
  return <span hidden ref={(el) => { scope.current = el?.closest("section") ?? null; }} />;
}
