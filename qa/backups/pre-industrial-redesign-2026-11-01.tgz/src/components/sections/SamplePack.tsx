"use client";

import { useCallback, useId, useState } from "react";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { SampleMotion } from "@/components/sections/motion/SampleMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { peelMe } from "@/components/stickers/art";
import { PillLink } from "@/components/ui/Pill";
import { SectionHead } from "@/components/ui/SectionHead";
import { cta, sample } from "@/data/copy";
import { cn } from "@/lib/utils";

/**
 * S8. A big sticker hides a discount code. A teaser lift and drag-to-peel use
 * the shared 3D peel shader, with a DOM fallback when WebGL is unavailable; the PEEL button is the keyboard path and the
 * reduced-motion path, and it always works.
 */
export function SamplePack() {
  const [peeled, setPeeled] = useState(false);
  const [msg, setMsg] = useState("");
  const codeId = useId();

  const peel = useCallback(async () => {
    setPeeled(true);
    try {
      await navigator.clipboard.writeText(sample.code);
      setMsg(`Code ${sample.code} revealed and copied.`);
    } catch {
      setMsg(`Code ${sample.code} revealed.`);
    }
  }, []);

  return (
    <section id="samples" aria-labelledby="samples-title" className="relative bg-frame page-x py-24 lg:py-32">
      <div className="grid grid-cols-12 items-center gap-x-6 gap-y-16">
        <div className="col-span-12 lg:col-span-6">
          <SectionHead id="samples-title" eyebrow={sample.eyebrow} title={sample.title} />
          <p className="type-display mt-8 text-[clamp(2.5rem,9vw,4.5rem)] leading-none [overflow-wrap:anywhere]">{sample.price}</p>
          <ul className="mt-10 grid gap-6 sm:grid-cols-3">
            {sample.points.map((p, i) => (
              <li key={p.title}>
                <span className="type-caption block">{String(i + 1).padStart(2, "0")}</span>
                <span className="type-display mt-1 block text-24">{p.title}</span>
                <span className="type-caption mt-1 block">{p.caption}</span>
              </li>
            ))}
          </ul>
          <PillLink href={cta.secondary.href} arrow className="mt-10">
            {cta.secondary.label}
          </PillLink>
        </div>

        <div className="col-span-12 flex flex-col items-center lg:col-span-6">
          <div className="relative w-[min(86vw,460px)]">
            <div className="relative flex aspect-[5/3] flex-col items-center justify-center rounded-card bg-white p-6 text-center">
              <span aria-hidden="true" className="absolute inset-3 rounded-[14px] border-2 border-dashed border-ink/20" />
              <p className="type-caption">Your code</p>
              <p id={codeId} className={cn("type-display mt-2 text-[clamp(2.5rem,6vw,4.5rem)] leading-none", !peeled && "invisible calm:visible")}>
                {sample.code}
              </p>
              <p className="type-caption mt-3">{peeled ? "Use it at checkout" : sample.peelHint}</p>
            </div>
            <div data-peel-box className="pointer-events-none absolute calm:hidden left-[19%] top-[5%] aspect-square w-[62%]">
            <div
              data-anchor="peel"
              aria-hidden="true"
              className={cn(
                "absolute inset-0 w-full [rotate:-8deg]",
                peeled && "pointer-events-none -translate-y-[160%] opacity-0",
              )}
            >
              <Sticker art={peelMe} className="block w-full [:root[data-three~=sample][data-scenes~=sample]_&]:invisible" />
            </div>
            </div>
            {!peeled && <button type="button" data-peel-drag tabIndex={-1} aria-hidden="true" className="absolute right-[18%] top-0 size-14 cursor-grab touch-none rounded-chip border-2 border-ink bg-marigold active:cursor-grabbing calm:hidden">↗</button>}
          </div>
          <button
            type="button"
            onClick={(e) => e.currentTarget.closest("section")?.dispatchEvent(new Event("lb:peel-request"))}
            disabled={peeled}
            aria-controls={codeId}
            className="type-label mt-8 inline-flex h-14 items-center gap-3 rounded-chip border-2 border-ink px-7 text-16 hover:bg-ink hover:text-paper disabled:opacity-40"
          >
            {peeled ? "Peeled" : "Peel"}
          </button>
          <p aria-live="polite" className="mt-3 min-h-6 text-14">
            {msg}
          </p>
        </div>
      </div>
      <NearViewport><SampleMotion onReveal={peel} revealed={peeled} /></NearViewport>
    </section>
  );
}
