import { ProductGlare } from "@/components/sections/products/ProductGlare";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { ProductsMotion } from "@/components/sections/products/ProductsMotion";
import { Sticker } from "@/components/stickers/Sticker";
import { productArt } from "@/components/stickers/productArt";
import { Arrow } from "@/components/ui/Pill";
import { SectionHead } from "@/components/ui/SectionHead";
import { productsCopy } from "@/data/copy";
import { products } from "@/data/products";

/** The roll the liner unspools from (rotates with the track on desktop). */
function RollCore() {
  return (
    <svg data-roll viewBox="0 0 200 200" className="size-full" aria-hidden="true" focusable="false">
      <circle cx="100" cy="100" r="98" fill="#FFFFFF" />
      {[90, 81, 72, 63, 54].map((r) => (
        <circle key={r} cx="100" cy="100" r={r} fill="none" stroke="#E2E1DD" strokeWidth="1.5" />
      ))}
      <circle cx="100" cy="100" r="44" fill="#E2E1DD" stroke="#0A0A0A" strokeWidth="4" />
      <circle cx="100" cy="100" r="26" fill="#F5F4F2" stroke="#0A0A0A" strokeWidth="3" />
      <rect x="96" y="2" width="8" height="18" rx="2" fill="#E8641F" />
    </svg>
  );
}

/**
 * S4. Desktop: pinned horizontal track; a label roll unspools a liner and each product card
 * peels up off it. Touch: native scroll-snap carousel. Reduced motion: a plain grid.
 */
export function Products() {
  return (
    <section id="products" aria-labelledby="products-title" className="relative overflow-x-clip stage:flex stage:h-svh stage:flex-col stage:justify-center">
      <div className="flex items-end justify-between gap-6 page-x pt-24 stage:pt-[calc(var(--frame)+var(--header-h))]">
        <SectionHead id="products-title" eyebrow={productsCopy.eyebrow} title={productsCopy.title} caption={productsCopy.caption} />
        <p aria-hidden="true" className="type-display hidden text-72 stage:block">
          <span data-counter>01</span>
          <span className="text-ink-soft"> / {String(products.length).padStart(2, "0")}</span>
        </p>
      </div>

      <div
        data-track-viewport
        className="relative mt-12 snap-x snap-mandatory overflow-x-auto overscroll-x-contain pb-6 [scrollbar-width:none] stage:overflow-visible stage:pb-0 calm:snap-none calm:overflow-visible"
      >
        <div
          data-track
          className="relative flex w-max items-stretch gap-5 page-x stage:gap-8 stage:pr-[calc(var(--frame)+var(--margin)+clamp(140px,13vw,220px)*0.6)] calm:grid calm:w-auto calm:grid-cols-1 calm:sm:grid-cols-2 calm:lg:grid-cols-4"
        >
          {/* liner strip the labels sit on */}
          <div aria-hidden="true" className="absolute inset-x-0 top-[12%] bottom-[12%] -z-10 bg-frame calm:hidden" />
          {products.map((p, i) => (
            <article
              key={p.id}
              data-product
              className="relative w-[min(78vw,320px)] shrink-0 snap-start scroll-ml-[calc(var(--frame)+var(--margin))] stage:w-[clamp(300px,23vw,360px)] calm:w-auto"
            >
              <span aria-hidden="true" className="absolute inset-0 rounded-card border-2 border-dashed border-ink/15" />
              <div data-card className="h-full">
              <ProductGlare>
              <div className="relative flex h-full flex-col rounded-card bg-white p-5">
                <div className="relative aspect-[4/3] overflow-hidden rounded-[14px] bg-paper">
                  <Sticker art={productArt[p.id]} className="absolute inset-[8%] h-[84%] w-[84%]" />
                  <span className="type-caption absolute left-3 top-3">{String(i + 1).padStart(2, "0")}</span>
                </div>
                <h3 className="type-display mt-5 text-32">{p.name}</h3>
                <p className="mt-2 flex-1 text-16 leading-[1.45]">{p.line}</p>
                <div className="mt-5 flex items-end justify-between border-t border-frame pt-4">
                  <p className="type-display text-24">
                    <span className="type-caption mr-2 align-middle">From</span>
                    {p.price}
                  </p>
                  <a href={p.href} className="type-label inline-flex h-11 items-center gap-2 text-14 after:absolute after:inset-0 after:rounded-card">
                    <span className="sr-only">Price {p.name}</span>
                    <Arrow className="size-6" />
                  </a>
                </div>
              </div>
              </ProductGlare>
              </div>
            </article>
          ))}
          <div aria-hidden="true" className="w-px shrink-0 calm:hidden" />
        </div>

        <div aria-hidden="true" data-anchor="roll" className="pointer-events-none absolute [:root[data-three~=roll][data-scenes~=products]_&]:invisible right-[calc(var(--frame)-clamp(140px,13vw,220px)*0.45)] top-1/2 hidden size-[clamp(140px,13vw,220px)] -translate-y-1/2 stage:block">
          <RollCore />
        </div>
      </div>
      <NearViewport><ProductsMotion /></NearViewport>
    </section>
  );
}
