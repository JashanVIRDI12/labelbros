import { LabelStudioPhone } from "@/components/phone/LabelStudioPhone";
import { HoneyPiece, HowCanvas, StepIllustration } from "@/components/sections/how/HowVisuals";
import { SectionHead } from "@/components/ui/SectionHead";
import { how } from "@/data/copy";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { HowMotion } from "@/components/sections/how/HowMotion";

/** Loose artwork on the sticker sheet next to the docked phone (positions are % of the sheet). */
const sheetPieces = [
  { id: "title", className: "left-[8%] top-[10%] w-[78%] -rotate-[4deg]", cut: "left-[4%] top-[7%] h-[19%] w-[86%] -rotate-[4deg]" },
  { id: "comb", className: "left-[12%] top-[40%] w-[30%] rotate-[8deg]", cut: "left-[8%] top-[37%] h-[28%] w-[38%] rotate-[8deg]" },
  { id: "sub", className: "left-[44%] top-[48%] w-[50%] -rotate-[6deg]", cut: "left-[41%] top-[45%] h-[13%] w-[56%] -rotate-[6deg]" },
  { id: "small", className: "left-[10%] top-[76%] w-[56%] rotate-[3deg]", cut: "left-[6%] top-[73%] h-[11%] w-[64%] rotate-[3deg]" },
];

/**
 * S2. Desktop (stage): the hero phone docks here, the section pins and plays
 * DESIGN → PROOF → PRINT → STICK. Touch and reduced motion: four stacked cards.
 */
export function HowItWorks() {
  return (
    <section id="how" aria-label={how.eyebrow} className="relative">
      <div data-how-stage className="hidden h-svh grid-cols-12 items-center gap-x-6 page-x stage:grid" style={{ paddingBlock: "calc(var(--frame) + 24px)" }}>
        <ol data-rail aria-hidden="true" className="col-span-1 flex flex-col gap-4">
          {how.steps.map((s, i) => (
            <li key={s.n} className="type-display relative text-48">
              <span style={{ color: "transparent", WebkitTextStroke: "1.5px #0A0A0A" }}>{s.n}</span>
              {/* the active number fills ink: an opacity layer, not a color tween */}
              <span data-rail-fill className="absolute inset-0" style={i === 0 ? undefined : { opacity: 0 }}>
                {s.n}
              </span>
            </li>
          ))}
        </ol>

        <div className="col-span-5">
          <SectionHead eyebrow={how.eyebrow} title={how.title} size="sm" />
          <div className="relative mt-10 grid">
            {how.steps.map((s, i) => (
              <div key={s.n} data-step={i} className="col-start-1 row-start-1" style={i === 0 ? undefined : { opacity: 0 }}>
                <p data-split className="type-caption">Step {s.n}</p>
                <h3 data-split className="type-display mt-2 text-[clamp(4.5rem,8vw,8rem)] leading-[0.9]">{s.title}</h3>
                <p data-split className="mt-6 max-w-[26rem] text-24 leading-[1.25]">{s.line}</p>
                <p data-split className="type-caption mt-4">{s.caption}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative col-span-6 flex h-full items-center justify-end pr-[4%]">
          <div data-phone-slot="how" className="relative w-[min(23vw,340px)] lg:w-[min(23vw,340px)]">
            {/* the sticker sheet breaks the phone's edge, like the stickers in the reference; the
                kiss-cut outlines stay behind once their pieces have flown onto the label */}
            <div data-sheet-wrap className="absolute right-[78%] top-[14%] z-10 w-[72%]">
              <div data-sheet aria-hidden="true" className="relative aspect-[4/5] w-full -rotate-[7deg] rounded-card bg-frame outline-[6px] outline-white outline-solid">
                {sheetPieces.map((p) => (
                  <span key={p.id} className={`absolute rounded-[10px] border-[1.5px] border-dashed border-ink/25 ${p.cut}`} />
                ))}
                {sheetPieces.map((p) => (
                  <HoneyPiece key={p.id} id={p.id} data-piece={p.id} className={`absolute h-auto ${p.className}`} />
                ))}
              </div>
            </div>
            <LabelStudioPhone>
              <HowCanvas />
            </LabelStudioPhone>
          </div>
        </div>
      </div>

      <div className="page-x py-24 stage:hidden">
        <SectionHead eyebrow={how.eyebrow} title={how.title} />
        <ol className="mt-12 grid gap-x-6 gap-y-12 md:grid-cols-2 lg:grid-cols-4">
          {how.steps.map((s, i) => (
            <li key={s.n} data-step-card={i}>
              <StepIllustration step={i} />
              <p className="type-caption mt-6">{s.n}</p>
              <h3 className="type-display mt-1 text-48">{s.title}</h3>
              <p className="mt-3 text-18 leading-[1.4]">{s.line}</p>
              <p className="type-caption mt-3">{s.caption}</p>
            </li>
          ))}
        </ol>
      </div>
      <NearViewport><HowMotion /></NearViewport>
    </section>
  );
}
