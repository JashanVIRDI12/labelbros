"use client";

import { useState } from "react";
import { FinishChips } from "@/components/sections/wrap/FinishChips";
import { Jar2D, type WrapFinish } from "@/components/sections/wrap/Jar2D";
import { WrapPoster } from "@/components/sections/wrap/WrapPoster";
import { NearViewport } from "@/components/sections/motion/NearViewport";
import { WrapMotion } from "@/components/sections/wrap/WrapMotion";
import { wrap } from "@/data/copy";
import { setProgress } from "@/lib/scrollStore";

function Check() {
  return (
    <svg viewBox="0 0 20 20" className="size-5 shrink-0 text-forest" aria-hidden="true" focusable="false">
      <path d="M4 10.5 8 14.5 16 5.5" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/**
 * S3. Desktop: pinned; the label from S2 bends around a 3D jar (uWrap), the jar turns, the
 * light sweeps. The 2D jar is the stand-in until the canvas takes over, and the final state
 * for reduced motion and the low tier.
 */
export function Wrap() {
  const [finish, setFinish] = useState<WrapFinish>("Matte");

  return (
    <section
      id="wrap"
      aria-labelledby="wrap-title"
      data-wrap-finish={finish} className="relative h-svh page-x calm:h-auto"
      style={{ paddingBlock: "calc(var(--frame) + var(--header-h) * 0.5)" }}
    >
      {/* touch pins this too, so it fits one screen with the jar first; reduced motion flows normally */}
      <div className="grid h-full grid-cols-12 content-center items-center gap-x-6 gap-y-6 calm:gap-y-12 calm:py-16 lg:gap-y-12">
        <div className="col-span-12 lg:col-span-5">
          <p className="type-caption">{wrap.eyebrow}</p>
          <h2 id="wrap-title" data-wrap-title className="type-display mt-3 whitespace-nowrap text-[clamp(3.25rem,6.2vw,6.75rem)] leading-[0.9]" aria-label={wrap.lines.join(" ")}>
            {wrap.lines.map((line) => (
              <span key={line} data-wrap-line className="block">
                {line}
              </span>
            ))}
          </h2>
          <ul data-wrap-after className="mt-10 flex flex-wrap gap-x-8 gap-y-3">
            {wrap.proof.map((p) => (
              <li key={p} className="type-label flex items-center gap-2 text-16">
                <Check />
                {p}
              </li>
            ))}
          </ul>
          <div data-wrap-after className="mt-10">
            <p className="type-caption mb-3">Pick a finish</p>
            <FinishChips
              label="Label finish"
              options={wrap.finishes}
              value={finish}
              onChange={(f) => {
                setFinish(f);
                setProgress("finishWrap", wrap.finishes.indexOf(f));
              }}
            />
          </div>
        </div>

        <div className="order-first col-span-12 flex items-center justify-center lg:order-none lg:col-span-7 lg:h-full">
          <div data-anchor="jar" className="relative w-[min(46vw,26svh,300px)] calm:w-[min(70vw,380px)] lg:w-[min(28vw,420px)] lg:calm:w-[min(28vw,420px)]">
            <div data-wrap-standin><Jar2D finish={finish} className="[:root[data-three~=wrap][data-scenes~=wrap]_&]:invisible" /></div>
            <WrapPoster />
          </div>
        </div>
      </div>
      <NearViewport><WrapMotion /></NearViewport>
    </section>
  );
}
