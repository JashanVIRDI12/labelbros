import { Sticker } from "@/components/stickers/Sticker";
import { honeyLabel } from "@/components/stickers/art";
import { cn } from "@/lib/utils";

export type WrapFinish = "Matte" | "Gloss" | "Holo" | "Chrome" | "Clear";

/**
 * Flat jar with the honey label wrapped on it: the reduced-motion and low-tier stand-in
 * for the 3D wrap, and what shows before the canvas loads. Each finish changes the label overlay.
 */
export function Jar2D({ finish = "Matte", className }: { finish?: WrapFinish; className?: string }) {
  return (
    <div className={cn("relative aspect-[300/380]", className)} aria-hidden="true">
      <svg viewBox="0 0 300 380" className="absolute inset-0 h-full w-full">
        <ellipse cx="150" cy="364" rx="118" ry="10" fill="#0A0A0A" opacity=".08" />
        <rect x="74" y="18" width="152" height="48" rx="10" fill="#0A0A0A" />
        <g stroke="#F5F4F2" strokeOpacity=".25" strokeWidth="3">
          {[92, 112, 132, 152, 172, 192, 208].map((x) => (
            <line key={x} x1={x} y1="26" x2={x} y2="58" />
          ))}
        </g>
        <rect x="84" y="62" width="132" height="22" rx="4" fill="#F5BA18" opacity=".55" />
        <rect x="40" y="80" width="220" height="280" rx="48" fill="#E8641F" />
        <rect x="40" y="80" width="220" height="280" rx="48" fill="#F5BA18" opacity=".35" />
        <rect x="222" y="104" width="18" height="236" rx="9" fill="#0A0A0A" opacity=".08" />
        <rect x="58" y="104" width="12" height="236" rx="6" fill="#FFFFFF" opacity=".45" />
      </svg>
      <div className="absolute left-[15%] top-[46%] w-[70%]">
        <div className={cn("relative", finish === "Clear" && "[&_rect:nth-of-type(-n+2)]:opacity-0")}>
          <Sticker art={honeyLabel} className="block w-full" />
          {finish === "Gloss" && <span className="absolute inset-y-[6%] left-[18%] w-[9%] -skew-x-12 bg-white/55" />}
          {finish === "Holo" && (
            <span
              className="absolute inset-[3%] rounded-[12px] mix-blend-screen"
              style={{ background: "repeating-linear-gradient(115deg, #F89ABC55 0 14px, #565DC555 14px 28px, #F5BA1844 28px 42px)" }}
            />
          )}
          {finish === "Chrome" && <span className="absolute inset-[3%] rounded-[12px] bg-white/40 mix-blend-luminosity" />}
        </div>
      </div>
    </div>
  );
}
