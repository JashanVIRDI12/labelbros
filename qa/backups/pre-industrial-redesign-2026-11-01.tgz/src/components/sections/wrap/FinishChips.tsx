"use client";

import { useRef } from "react";
import { cn } from "@/lib/utils";

type Props<T extends string> = {
  label: string;
  options: readonly T[];
  value: T;
  onChange: (v: T) => void;
  tone?: "ink" | "paper";
};

/** Pill radio group with roving focus and arrow-key navigation (WAI-ARIA radio pattern). */
export function FinishChips<T extends string>({ label, options, value, onChange, tone = "ink" }: Props<T>) {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);

  const onKey = (e: React.KeyboardEvent, i: number) => {
    const delta = e.key === "ArrowRight" || e.key === "ArrowDown" ? 1 : e.key === "ArrowLeft" || e.key === "ArrowUp" ? -1 : 0;
    if (!delta) return;
    e.preventDefault();
    const next = (i + delta + options.length) % options.length;
    onChange(options[next]);
    refs.current[next]?.focus();
  };

  return (
    <div role="radiogroup" aria-label={label} className="flex flex-wrap gap-2">
      {options.map((opt, i) => {
        const on = opt === value;
        return (
          <button
            key={opt}
            ref={(el) => {
              refs.current[i] = el;
            }}
            type="button"
            role="radio"
            aria-checked={on}
            tabIndex={on ? 0 : -1}
            onClick={() => onChange(opt)}
            onKeyDown={(e) => onKey(e, i)}
            className={cn(
              "type-label inline-flex h-11 items-center rounded-chip border px-5 text-14 transition-colors duration-200",
              tone === "ink" && (on ? "border-ink bg-ink text-paper" : "border-ink/20 bg-white hover:border-ink"),
              tone === "paper" && (on ? "border-paper bg-paper text-ink" : "border-paper/30 text-paper hover:border-paper"),
            )}
          >
            {opt}
          </button>
        );
      })}
    </div>
  );
}
