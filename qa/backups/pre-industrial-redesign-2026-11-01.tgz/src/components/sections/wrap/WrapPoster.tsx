import Image from "next/image";

/** Frames rendered from our jar scene; the low tier crossfades them as the wrap progresses. */
export function WrapPoster() {
  return <div data-wrap-posters className="absolute inset-[-12%] hidden" aria-hidden="true">
    {["flat", "half", "wrapped"].map((frame, i) => <Image key={frame} data-wrap-poster={i} src={`/posters/wrap-${frame}.avif`} alt="" fill sizes="(min-width:1024px) 420px, 200px" className="object-contain" style={{ opacity: i === 2 ? 1 : 0 }} />)}
  </div>;
}
