"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { ScrollTrigger } from "@/lib/gsap";
import { C } from "@/lib/palette";
import { scrollStore } from "@/lib/scrollStore";
import { setThreeFlag } from "@/lib/threeFlags";
import { anchorInPinnedSection, worldPerPx, type Anchor } from "./anchors";

/** Labels on their liner, wrapped round the outside of the roll. */
function sideTexture() {
  const c = document.createElement("canvas");
  c.width = 1024;
  c.height = 160;
  const g = c.getContext("2d")!;
  g.fillStyle = C.frame;
  g.fillRect(0, 0, 1024, 160);
  const fills = [C.marigold, C.bubblegum, C.periwinkle, C.orange];
  for (let i = 0; i < 8; i++) {
    const x = i * 128 + 10;
    g.fillStyle = C.white;
    g.beginPath();
    g.roundRect(x - 4, 18, 116, 124, 18);
    g.fill();
    g.fillStyle = fills[i % fills.length];
    g.beginPath();
    g.roundRect(x, 22, 108, 116, 14);
    g.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.repeat.set(2, 1);
  t.anisotropy = 8;
  return t;
}

/** The roll's face: hundreds of wound layers of liner. */
function faceTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 512;
  const g = c.getContext("2d")!;
  g.fillStyle = C.white;
  g.fillRect(0, 0, 512, 512);
  for (let r = 96; r < 256; r += 4) {
    g.strokeStyle = r % 16 === 0 ? "rgba(10,10,10,0.09)" : "rgba(10,10,10,0.04)";
    g.lineWidth = 1.2;
    g.beginPath();
    g.arc(256, 256, r, 0, Math.PI * 2);
    g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/**
 * S4 desktop: the roll the liner unspools from. It sits mostly off the right edge and is turned
 * so its labelled side shows; it spins with the track, so the cards read as labels coming off it.
 */
export function Roll3D() {
  const size = useThree((s) => s.size);
  const [a, setA] = useState<Anchor | null>(null);
  const group = useRef<THREE.Group>(null);
  const spin = useRef<THREE.Group>(null);
  const side = useMemo(() => sideTexture(), []);
  const face = useMemo(() => faceTexture(), []);
  useEffect(
    () => () => {
      side.dispose();
      face.dispose();
    },
    [side, face],
  );

  useEffect(() => {
    const section = document.getElementById("products");
    const el = section?.querySelector<HTMLElement>('[data-anchor="roll"]');
    if (!section || !el) return;
    const measure = () => setA(anchorInPinnedSection(el, section, size));
    measure();
    ScrollTrigger.addEventListener("refresh", measure);
    return () => ScrollTrigger.removeEventListener("refresh", measure);
  }, [size]);
  useEffect(() => {
    if (!a) return;
    setThreeFlag("roll", true);
    return () => setThreeFlag("roll", false);
  }, [a]);

  useFrame(() => {
    if (!group.current || !spin.current) return;
    group.current.visible = scrollStore.scenes.has("products");
    spin.current.rotation.z = -scrollStore.roll * Math.PI * 8;
  });

  if (!a) return null;
  const r = a.w * 0.62;
  const h = a.w * 0.42;
  // the roll sits at the right edge and the cards come off it, travelling left as the liner
  // unspools (the spec had it on the left, where the cards would wind back on); about a quarter shows
  const right = (size.width / 2) * worldPerPx(size.height);
  return (
    <group ref={group} position={[right - r * 0.28, a.y, 0]} rotation={[0.08, -0.95, 0]} visible={false}>
      <group ref={spin}>
        {/* cylinder material groups: side, top cap, bottom cap */}
        <mesh rotation-x={Math.PI / 2}>
          <cylinderGeometry args={[r, r, h, 96, 1]} />
          {/* flat vocabulary: the printed side and the paper face stay true to their colours */}
          <meshBasicMaterial attach="material-0" map={side} toneMapped={false} />
          <meshBasicMaterial attach="material-1" map={face} toneMapped={false} />
          <meshBasicMaterial attach="material-2" map={face} toneMapped={false} />
        </mesh>
        <mesh rotation-x={Math.PI / 2}>
          <cylinderGeometry args={[r * 0.3, r * 0.3, h * 1.04, 48, 1, true]} />
          <meshStandardMaterial color="#C9A47C" roughness={0.9} side={THREE.DoubleSide} />
        </mesh>
        <mesh position-z={h * 0.52}>
          <ringGeometry args={[r * 0.22, r * 0.3, 48]} />
          <meshStandardMaterial color="#B8926A" roughness={0.9} />
        </mesh>
        <mesh position-z={h * 0.521}>
          <circleGeometry args={[r * 0.22, 48]} />
          <meshBasicMaterial color={C.ink} toneMapped={false} />
        </mesh>
      </group>
    </group>
  );
}
