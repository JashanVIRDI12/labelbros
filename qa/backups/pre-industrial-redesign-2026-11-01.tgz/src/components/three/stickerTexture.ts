import * as THREE from "three";
import type { StickerArt } from "@/components/stickers/art";

let fontCss: Promise<string> | null = null;

/** Anton as a data-URI @font-face: SVG drawn as an image can't see the page's fonts. */
function antonFace() {
  fontCss ??= fetch("/fonts/anton-latin.woff2")
    .then((r) => r.arrayBuffer())
    .then((buf) => {
      let bin = "";
      const bytes = new Uint8Array(buf);
      for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      return `@font-face{font-family:'Anton';src:url(data:font/woff2;base64,${btoa(bin)}) format('woff2');}`;
    });
  return fontCss;
}

const cache = new Map<string, Promise<THREE.CanvasTexture>>();

/**
 * Rasterise a sticker's SVG string (the same one the DOM shows) into a texture,
 * up to `maxPx` on its long side. Cached per sticker and size.
 */
export function stickerTexture(art: StickerArt, maxPx = 1024): Promise<THREE.CanvasTexture> {
  const key = `${art.id}@${maxPx}`;
  let hit = cache.get(key);
  if (hit) return hit;
  hit = (async () => {
    const css = await antonFace();
    const scale = maxPx / Math.max(art.w, art.h);
    const w = Math.round(art.w * scale);
    const h = Math.round(art.h * scale);
    const body = art.svg.replace(/ href="(#[^"]+)"/g, ' href="$1" xlink:href="$1"');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${w}" height="${h}" viewBox="0 0 ${art.w} ${art.h}"><style>${css}</style>${body}</svg>`;
    const img = new Image();
    img.decoding = "async";
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
    await img.decode();
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    canvas.getContext("2d")!.drawImage(img, 0, 0, w, h);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    return tex;
  })();
  cache.set(key, hit);
  return hit;
}

let shadowTex: THREE.CanvasTexture | null = null;

/** Soft round blob for contact shadows (the only shadow stickers get). */
export function shadowTexture() {
  if (shadowTex) return shadowTex;
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(64, 64, 4, 64, 64, 64);
  grad.addColorStop(0, "rgba(10,10,10,0.55)");
  grad.addColorStop(1, "rgba(10,10,10,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  shadowTex = new THREE.CanvasTexture(c);
  return shadowTex;
}

let users = 0;
let releaseTimer: ReturnType<typeof setTimeout> | undefined;
/** Keep shared maps through Strict Mode's immediate remount, release them after the canvas leaves. */
export function retainStickerTextures() {
  users++;
  clearTimeout(releaseTimer);
  return () => {
    users--;
    releaseTimer = setTimeout(() => {
      if (users) return;
      const maps = [...cache.values()];
      cache.clear();
      maps.forEach((p) => p.then((texture) => texture.dispose()).catch(() => {}));
      shadowTex?.dispose();
      shadowTex = null;
    }, 0);
  };
}
