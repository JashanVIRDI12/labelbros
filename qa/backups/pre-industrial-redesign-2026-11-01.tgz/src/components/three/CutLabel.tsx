"use client";

import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { honeyLabel } from "@/components/stickers/art";
import { ScrollTrigger } from "@/lib/gsap";
import { scrollStore } from "@/lib/scrollStore";
import { setThreeFlag } from "@/lib/threeFlags";
import { anchorInPinnedSection, smoothstep, worldPerPx, type Anchor } from "./anchors";
import { ContactShadow, damp, placeShadow, useStickerMesh } from "./common";
import { peelFragment, peelVertex } from "./shaders/peel";
import { stickerTexture } from "./stickerTexture";
import { LABEL_APPROACH, WRAP_FRACTION } from "./jar";

const DIR: [number, number] = [-1, 1]; // start at the bottom-right corner

/**
 * S2 STICK in 3D: the kiss-cut label (an exact copy of the docked DOM label) curls up from
 * its corner, lifts off the liner and falls out of frame toward S3. Driven by store.cut.
 */
export function CutLabel() {
  const size = useThree((s) => s.size);
  const invalidate = useThree((s) => s.invalidate);
  const [map, setMap] = useState<THREE.Texture | null>(null);
  const [a, setA] = useState<Anchor | null>(null);

  useEffect(() => {
    let alive = true;
    stickerTexture(honeyLabel, 1024).then((t) => alive && setMap(t));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const section = document.getElementById("how");
    // the wrapper, not [data-label]: the 2D fallback moves the label itself off screen
    const el = section?.querySelector<HTMLElement>("[data-label-anchor]");
    if (!section || !el) return;
    const measure = () => {
      setA(anchorInPinnedSection(el, section, size));
      invalidate();
    };
    measure();
    ScrollTrigger.addEventListener("refresh", measure);
    return () => ScrollTrigger.removeEventListener("refresh", measure);
  }, [size, invalidate]);

  const ready = Boolean(map && a);
  useEffect(() => {
    if (!ready) return;
    setThreeFlag("how", true);
    return () => setThreeFlag("how", false);
  }, [ready]);

  if (!map || !a) return null;
  return <CutLabelMesh map={map} a={a} />;
}

function CutLabelMesh({ map, a }: { map: THREE.Texture; a: Anchor }) {
  const mesh = useRef<THREE.Mesh>(null);
  const shadow = useRef<THREE.Mesh>(null);
  const cur = useRef(0);
  const jar = useRef<HTMLElement | null>(null);
  useEffect(() => { jar.current = document.querySelector('[data-anchor="jar"]'); }, []);
  const size = useThree((s) => s.size);
  const { geo, uniforms } = useStickerMesh(map, a, DIR, 64);

  useFrame((state, dt) => {
    const m = mesh.current;
    const s = shadow.current;
    if (!m || !s) return;
    const raw = scrollStore.cut;
    cur.current = damp(cur.current, raw, 8, dt);
    const c = cur.current;
    if (Math.abs(raw - c) > 1e-4) state.invalidate();

    const bridge = scrollStore.bridge;
    const bridging = raw > 0.995 && bridge > 0 && bridge < 0.98;
    const show = scrollStore.scenes.has("how") && ((raw > 0.002 || c > 0.002) && c < 0.995 || bridging);
    m.visible = s.visible = show;
    if (!show) return;

    const k = worldPerPx(size.height);
    const hh = (size.height / 2) * k;
    const lift = smoothstep(0.08, 0.45, c);
    const fall = smoothstep(0.42, 1, c);

    (m.material as THREE.ShaderMaterial).uniforms.uPeel.value = 0.3 * smoothstep(0, 0.3, c) - 0.14 * smoothstep(0.45, 0.9, c);
    const z = lift * 1.6 - fall * 0.4;
    const x = a.x + lift * 0.25 + fall * 1.2;
    const y = a.y + lift * 0.35 - fall * (hh + a.y + a.h * 1.5);
    m.position.set(x, y, z);
    m.rotation.set(lift * 0.35 + fall * 0.9, -lift * 0.25, lift * 0.12 - fall * 0.7);
    m.scale.set(1, 1, 1);
    if (bridging && jar.current) {
      const r = jar.current.getBoundingClientRect();
      const radius = r.width * k * 110 / 300;
      const targetX = (r.left + r.width / 2 - size.width / 2) * k;
      const targetY = -(r.top + r.height / 2 - size.height / 2) * k - r.width * k * 30 / 300;
      const b = smoothstep(0, 0.98, bridge);
      // One visible label approaches the same flat plane owned by the jar at the hand-off.
      m.position.set(THREE.MathUtils.lerp(x, targetX, b), THREE.MathUtils.lerp(y, targetY, b), THREE.MathUtils.lerp(z, radius * (1.012 + LABEL_APPROACH), b));
      m.rotation.set((1-b) * 1.25, (1-b) * -0.25, (1-b) * -0.58);
      const width = 2 * Math.PI * radius * WRAP_FRACTION;
      m.scale.set(THREE.MathUtils.lerp(1, width / a.w, b), THREE.MathUtils.lerp(1, width * 200 / 480 / a.h, b), 1);
      (m.material as THREE.ShaderMaterial).uniforms.uPeel.value *= 1 - b;
    }
    placeShadow(s, x, y, z, a.w, a.h, 1 - fall);
  });

  return (
    <>
      <ContactShadow shadowRef={shadow} />
      <mesh ref={mesh} geometry={geo} renderOrder={3} visible={false}>
        <shaderMaterial uniforms={uniforms} vertexShader={peelVertex} fragmentShader={peelFragment} transparent side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
    </>
  );
}
