"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { MQ, REDUCE_EVENT, getTier, prefersReducedMotion } from "@/lib/motion";

const Scene = dynamic(() => import("./Scene"), { ssr: false });

type Mode = { touch: boolean } | null;

/**
 * Loads the one shared WebGL canvas after first paint. Desktop: on idle after load.
 * Touch: only when the visitor scrolls near S3, so mobile first load never pays for three.
 * Low tier and reduced motion: never (sections render posters and 2D fallbacks).
 */
export function CanvasRoot() {
  const [mode, setMode] = useState<Mode>(null);
  const [allowed, setAllowed] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia(MQ.reduceMotion);
    const sync = () => { const tier = getTier(); document.documentElement.dataset.tier = tier; setAllowed(tier === "high" && !prefersReducedMotion()); };
    sync();
    mq.addEventListener("change", sync);
    window.addEventListener(REDUCE_EVENT, sync);
    return () => {
      mq.removeEventListener("change", sync);
      window.removeEventListener(REDUCE_EVENT, sync);
    };
  }, []);

  useEffect(() => {
    if (!allowed || mode) return;
    const touch = window.matchMedia(MQ.isTouch).matches;

    if (!touch) {
      let idleId = 0;
      const load = () => {
        const ric = window.requestIdleCallback ?? ((cb: () => void) => window.setTimeout(cb, 200));
        idleId = ric(() => setMode({ touch: false }));
      };
      if (document.readyState === "complete") load();
      else window.addEventListener("load", load, { once: true });
      return () => {
        window.removeEventListener("load", load);
        (window.cancelIdleCallback ?? window.clearTimeout)(idleId);
      };
    }

    const target = document.getElementById("wrap");
    if (!target) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setMode({ touch: true });
          io.disconnect();
        }
      },
      { rootMargin: "150% 0px" },
    );
    io.observe(target);
    return () => io.disconnect();
  }, [allowed, mode]);

  if (!allowed || !mode) return null;
  return <Scene touch={mode.touch} />;
}
