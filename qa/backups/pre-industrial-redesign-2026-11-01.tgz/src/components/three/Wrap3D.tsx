"use client";

import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { honeyLabel } from "@/components/stickers/art";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { C } from "@/lib/palette";
import { scrollStore } from "@/lib/scrollStore";
import { setThreeFlag } from "@/lib/threeFlags";
import { anchorInPinnedSection, smoothstep, worldPerPx, type Anchor } from "./anchors";
import { damp } from "./common";
import { shadowTexture, stickerTexture } from "./stickerTexture";
import { WRAP_FINISHES, wrapFragment, wrapUniforms, wrapVertex } from "./shaders/wrap";
import { LABEL_APPROACH, WRAP_FRACTION } from "./jar";

// A full turn so the label ends facing front, where the finish chips are used (spec: 300°).
const TURN = Math.PI * 2;

/** Paper-grid shelf: grid lines only (no fill, so chips and focus rings stay crisp), fading out at the edges. */
function shelfTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 1024;
  const g = c.getContext("2d")!;
  g.strokeStyle = "rgba(10,10,10,0.09)";
  g.lineWidth = 2;
  for (let i = 0; i <= 1024; i += 48) {
    g.beginPath();
    g.moveTo(i, 0);
    g.lineTo(i, 1024);
    g.moveTo(0, i);
    g.lineTo(1024, i);
    g.stroke();
  }
  g.globalCompositeOperation = "destination-in";
  const grad = g.createRadialGradient(512, 512, 120, 512, 512, 512);
  grad.addColorStop(0, "rgba(0,0,0,1)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 1024, 1024);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 16;
  return t;
}

/** Rounded honey-jar body profile for LatheGeometry. */
function jarProfile(r: number, h: number, neckR: number, neckH: number) {
  const pts: THREE.Vector2[] = [new THREE.Vector2(0, -h / 2)];
  const cr = r * 0.42;
  const arc = (cx: number, cy: number, from: number, to: number) => {
    for (let i = 0; i <= 10; i++) {
      const a = from + ((to - from) * i) / 10;
      pts.push(new THREE.Vector2(cx + cr * Math.cos(a), cy + cr * Math.sin(a)));
    }
  };
  arc(r - cr, -h / 2 + cr, -Math.PI / 2, 0);
  arc(r - cr, h / 2 - cr, 0, Math.PI / 2);
  pts.push(new THREE.Vector2(neckR, h / 2), new THREE.Vector2(neckR, h / 2 + neckH), new THREE.Vector2(0, h / 2 + neckH));
  return pts;
}

/**
 * S3 in 3D. The flat label arrives with the section and bends around the jar over the first half
 * of the pin, landing with a short springy overshoot (the slap). The jar then turns a full turn
 * while the camera pulls back onto a paper-grid shelf, and the key light sweeps across the label
 * as it comes back to the front. Finish chips tween the label's finish uniforms.
 */
export function Wrap3D({ touch }: { touch: boolean }) {
  const size = useThree((s) => s.size);
  const invalidate = useThree((s) => s.invalidate);
  const [map, setMap] = useState<THREE.Texture | null>(null);
  const [a, setA] = useState<Anchor | null>(null);

  useEffect(() => {
    let alive = true;
    stickerTexture(honeyLabel, 1536).then((t) => alive && setMap(t));
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const section = document.getElementById("wrap");
    const el = section?.querySelector<HTMLElement>('[data-anchor="jar"]');
    if (!section || !el) return;
    const measure = () => {
      setA(anchorInPinnedSection(el, section, size));
      invalidate();
    };
    measure();
    ScrollTrigger.addEventListener("refresh", measure);
    return () => ScrollTrigger.removeEventListener("refresh", measure);
  }, [size, invalidate]);

  const ready = Boolean(map && a);
  useEffect(() => {
    if (!ready) return;
    setThreeFlag("wrap", true);
    return () => setThreeFlag("wrap", false);
  }, [ready]);

  if (!map || !a) return null;
  return <JarScene map={map} a={a} touch={touch} />;
}

function JarScene({ map, a, touch }: { map: THREE.Texture; a: Anchor; touch: boolean }) {
  const size = useThree((s) => s.size);
  const invalidate = useThree((s) => s.invalidate);
  const follow = useRef<THREE.Group>(null);
  const turn = useRef<THREE.Group>(null);
  const label = useRef<THREE.Mesh>(null);
  const key = useRef<THREE.DirectionalLight>(null);
  const shelf = useRef<THREE.Mesh>(null);
  const shadow = useRef<THREE.Mesh>(null);
  const cur = useRef(0);
  const settle = useRef<number | null>(null); // clock time the wrap closed (starts the overshoot)
  const finish = useRef({ gloss: 0, metal: 0, holo: 0, clear: 0 });
  const lastFinish = useRef(-1);
  useEffect(() => { const current = finish.current; return () => { gsap.killTweensOf(current); }; }, []);

  // proportions from the 2D jar (300×380 viewBox), so 3D and 2D share a silhouette
  const dims = useMemo(() => {
    const s = a.w / 300;
    const r = 110 * s;
    const h = 280 * s;
    const labelW = 2 * Math.PI * r * WRAP_FRACTION;
    return {
      r,
      h,
      neckR: 66 * s,
      neckH: 22 * s,
      lidR: 76 * s,
      lidH: 48 * s,
      bodyOffset: -30 * s, // body centre sits below the box centre
      labelW,
      labelH: labelW * (200 / 480),
    };
  }, [a.w]);

  const seg = touch ? 48 : 96;
  const bodyGeo = useMemo(() => new THREE.LatheGeometry(jarProfile(dims.r, dims.h, dims.neckR, dims.neckH), seg), [dims, seg]);
  const labelGeo = useMemo(() => new THREE.PlaneGeometry(dims.labelW, dims.labelH, touch ? 80 : 160, 2), [dims, touch]);
  useEffect(
    () => () => {
      bodyGeo.dispose();
      labelGeo.dispose();
    },
    [bodyGeo, labelGeo],
  );
  const uniforms = useMemo(() => wrapUniforms(map, dims.r * 1.012), [map, dims.r]);
  const shelfMap = useMemo(() => shelfTexture(), []);
  useEffect(() => () => shelfMap.dispose(), [shelfMap]);

  useFrame((state, dt) => {
    const f = follow.current;
    const t = turn.current;
    const l = label.current;
    if (!f || !t || !l) return;
    const on = scrollStore.scenes.has("wrap");
    f.visible = on;
    if (!on) return;

    // ride with the section exactly (raw scroll, no damping) while it scrolls in and out
    const k = worldPerPx(size.height);
    const offsetPx = (1 - scrollStore.bridge) * size.height - scrollStore.wrapOut * size.height;
    f.position.set(a.x, a.y - offsetPx * k + dims.bodyOffset, 0);

    l.visible = touch || scrollStore.cut < 0.995 || scrollStore.bridge >= 0.98;
    const raw = scrollStore.wrap;
    cur.current = damp(cur.current, raw, 6, dt);
    const p = cur.current;
    if (Math.abs(raw - p) > 1e-4) state.invalidate();

    // the wrap reads continuously over 0.05→0.5; the moment it closes, a short damped spring
    // (the slap) squeezes it a touch past the jar and lets it settle, in time, not in scroll
    const wrapT = smoothstep(0.05, 0.5, p);
    const now = state.clock.elapsedTime;
    if (wrapT > 0.985 && raw > 0.48) settle.current ??= now;
    else if (wrapT < 0.9) settle.current = null;
    let spring = 0;
    if (settle.current !== null) {
      const s = now - settle.current;
      spring = 0.07 * Math.exp(-s * 5.5) * Math.sin(s * 15);
      if (s < 1.2) state.invalidate();
    }
    const late = smoothstep(0.55, 1, p);
    const u = (l.material as THREE.ShaderMaterial).uniforms;
    u.uWrap.value = wrapT + spring;
    u.uZ.value = dims.r * 1.012 + (1 - wrapT) * dims.r * LABEL_APPROACH;
    u.uLit.value = smoothstep(0.02, 0.35, wrapT);
    t.rotation.y = late * TURN;

    // key light sweeps across the label as it comes back round to the front (not on touch)
    const ang = touch ? -0.5 : THREE.MathUtils.lerp(-1.2, 0.9, smoothstep(0.78, 1, p));
    u.uLight.value.set(Math.sin(ang), 0.35, Math.cos(ang));
    key.current?.position.set(Math.sin(ang) * 6, 3, Math.cos(ang) * 6);

    // finish chips
    const fi = scrollStore.finishWrap;
    if (fi !== lastFinish.current) {
      lastFinish.current = fi;
      const target = WRAP_FINISHES[fi] ?? WRAP_FINISHES[0];
      gsap.to(finish.current, {
        gloss: target.gloss,
        metal: target.metal,
        holo: target.holo,
        clear: target.clear,
        duration: 0.6,
        ease: "expo.out",
        overwrite: true,
        onUpdate: () => invalidate(),
      });
    }
    u.uGloss.value = finish.current.gloss;
    u.uMetal.value = finish.current.metal;
    u.uHolo.value = finish.current.holo;
    u.uClear.value = finish.current.clear;

    // the shelf appears as the camera pulls back
    const pull = touch ? 0 : late * (1 - scrollStore.wrapOut);
    if (shelf.current) (shelf.current.material as THREE.MeshBasicMaterial).opacity = pull;
    if (shadow.current) (shadow.current.material as THREE.MeshBasicMaterial).opacity = 0.35 * pull;
  });

  const shelfY = -dims.h / 2 - 0.002;
  return (
    <group ref={follow} visible={false}>
      <hemisphereLight args={[C.paper, "#8a8780", 1.1]} />
      <directionalLight ref={key} intensity={2.4} position={[-3, 3, 5]} />


      <mesh ref={shelf} rotation-x={-Math.PI / 2} position={[0, shelfY, 0]} renderOrder={0}>
        <planeGeometry args={[dims.r * 14, dims.r * 7]} />
        <meshBasicMaterial map={shelfMap} transparent opacity={0} depthWrite={false} toneMapped={false} />
      </mesh>
      <mesh ref={shadow} rotation-x={-Math.PI / 2} position={[0.1 * dims.r, shelfY + 0.003, 0.1 * dims.r]} renderOrder={1}>
        <planeGeometry args={[dims.r * 3.2, dims.r * 2.2]} />
        <meshBasicMaterial map={shadowTexture()} transparent opacity={0} depthWrite={false} toneMapped={false} />
      </mesh>

      <group ref={turn}>
        <mesh geometry={bodyGeo} renderOrder={2}>
          <meshPhysicalMaterial color="#EC8E1E" roughness={0.16} clearcoat={1} clearcoatRoughness={0.06} specularIntensity={0.9} />
        </mesh>
        <mesh position={[0, dims.h / 2 + dims.neckH + dims.lidH / 2 - dims.lidH * 0.12, 0]} renderOrder={2}>
          <cylinderGeometry args={[dims.lidR, dims.lidR, dims.lidH, seg, 1]} />
          <meshStandardMaterial color={C.ink} roughness={0.45} metalness={0.1} />
        </mesh>
        <mesh ref={label} geometry={labelGeo} renderOrder={3}>
          <shaderMaterial uniforms={uniforms} vertexShader={wrapVertex} fragmentShader={wrapFragment} transparent side={THREE.DoubleSide} toneMapped={false} />
        </mesh>
      </group>
    </group>
  );
}
