import * as THREE from "three";

/**
 * Peel: the sticker curls around a moving hinge line. Points past the hinge (toward the
 * starting corner) wrap around a cylinder of radius uRadius and lift toward the camera;
 * past half a turn they lie flat, folded back. The back face is the white liner.
 * Geometry must be built at its real size (uSize) so the curl stays round.
 * At uPeel = 0 the output is the texture, unlit and untone-mapped, so it matches the DOM sticker exactly.
 */
export const peelVertex = /* glsl */ `
  uniform float uPeel;
  uniform vec2 uDir;
  uniform float uRadius;
  uniform vec2 uSize;
  varying vec2 vUv;
  varying float vShade;
  varying float vCrease;
  varying vec3 vNormalV;

  void main() {
    vUv = uv;
    vec3 p = position;
    vec3 n = vec3(0.0, 0.0, 1.0);
    vec2 toCorner = -uDir;
    float maxProj = 0.5 * (abs(toCorner.x) * uSize.x + abs(toCorner.y) * uSize.y);
    float proj = dot(p.xy, toCorner);
    float travel = 2.0 * maxProj + 3.14159265 * uRadius;
    float hinge = maxProj - uPeel * travel;
    float dist = proj - hinge;
    vShade = 1.0;
    // a thin shadow along the hinge, on the part still stuck down
    vCrease = dist <= 0.0 ? exp(dist / (uRadius * 0.45)) : 0.0;
    if (dist > 0.0) {
      float a = dist / uRadius;
      float newProj;
      float z;
      if (a < 3.14159265) {
        newProj = hinge + uRadius * sin(a);
        z = uRadius * (1.0 - cos(a));
        vShade = 1.0 - 0.28 * sin(a);
        n = vec3(toCorner * -sin(a), cos(a));
      } else {
        newProj = hinge - (dist - 3.14159265 * uRadius);
        z = 2.0 * uRadius;
        vShade = 0.86;
        n = vec3(0.0, 0.0, -1.0);
      }
      p.xy += toCorner * (newProj - proj);
      p.z += z;
    }
    vNormalV = normalize(normalMatrix * n);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`;

export const peelFragment = /* glsl */ `
  uniform sampler2D uMap;
  uniform vec3 uBack;
  uniform float uOpacity;
  uniform float uPeel;
  varying vec2 vUv;
  varying float vShade;
  varying float vCrease;
  varying vec3 vNormalV;

  void main() {
    vec4 tex = texture2D(uMap, vUv);
    if (tex.a < 0.02) discard;
    // vinyl: a soft highlight wherever the lifted surface turns toward the key light, and the
    // hinge crease. Both fade to nothing at uPeel 0, so the DOM → WebGL hand-off stays exact.
    float lifted = smoothstep(0.0, 0.05, uPeel);
    vec3 N = normalize(gl_FrontFacing ? vNormalV : -vNormalV);
    vec3 H = normalize(normalize(vec3(-0.45, 0.55, 0.8)) + vec3(0.0, 0.0, 1.0));
    float spec = pow(max(dot(N, H), 0.0), 38.0) * 0.32 * lifted;
    float crease = 1.0 - 0.22 * vCrease * lifted;
    vec3 col = gl_FrontFacing ? tex.rgb * vShade * crease + spec : uBack * (0.92 + 0.08 * vShade) + spec * 0.5;
    gl_FragColor = vec4(col, tex.a * uOpacity);
    #include <colorspace_fragment>
  }
`;

export function peelUniforms(map: THREE.Texture, size: [number, number], dir: [number, number]) {
  const d = new THREE.Vector2(...dir).normalize();
  return {
    uMap: { value: map },
    uPeel: { value: 0 },
    uDir: { value: d },
    uRadius: { value: Math.min(size[0], size[1]) * 0.14 },
    uSize: { value: new THREE.Vector2(...size) },
    uBack: { value: new THREE.Color("#F2F1EE") },
    uOpacity: { value: 1 },
  };
}
