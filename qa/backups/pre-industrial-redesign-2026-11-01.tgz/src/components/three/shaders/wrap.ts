import * as THREE from "three";
import { C } from "@/lib/palette";

/**
 * Wrap: a flat label plane bends around a cylinder. Bend radius = uR / uWrap, so uWrap 0 is
 * flat (at z = uZ, in front of the jar) and 1 hugs the jar (radius uR, centred on the origin).
 * Equivalent to the spec's angle = (x / width) · uWrap · 2π·f, with f the wrapped fraction.
 * Finishes live in the fragment shader so chips can tween them: gloss highlight, chrome,
 * holo (view-angle hue shift) and clear (the base and white border go see-through).
 * A tiny procedural "studio" (two softboxes + a floor bounce) gives gloss and chrome
 * something to reflect, so the strips glide across the label as the jar turns.
 */
export const wrapVertex = /* glsl */ `
  uniform float uWrap;
  uniform float uR;
  uniform float uZ;
  varying vec2 vUv;
  varying vec3 vN;
  varying vec3 vViewPos;

  void main() {
    vUv = uv;
    float w = max(uWrap, 0.0001);
    float rb = uR / w;
    float th = position.x / rb;
    vec3 q = vec3(rb * sin(th), position.y, rb * cos(th) - rb + uZ);
    vec3 n = vec3(sin(th), 0.0, cos(th));
    vN = normalize(normalMatrix * n);
    vec4 mv = modelViewMatrix * vec4(q, 1.0);
    vViewPos = mv.xyz;
    gl_Position = projectionMatrix * mv;
  }
`;

export const wrapFragment = /* glsl */ `
  uniform sampler2D uMap;
  uniform vec3 uLight;
  uniform vec3 uBaseColor;
  uniform float uLit;
  uniform float uGloss;
  uniform float uMetal;
  uniform float uHolo;
  uniform float uClear;
  varying vec2 vUv;
  varying vec3 vN;
  varying vec3 vViewPos;

  // view-space reflection → softbox strips (key on the left, fill on the right, warm floor)
  vec3 studio(vec3 R) {
    float key = exp(-pow((R.x + 0.35) * 5.0, 2.0)) * smoothstep(-0.2, 0.5, R.y);
    float fill = 0.55 * exp(-pow((R.x - 0.62) * 7.0, 2.0)) * smoothstep(-0.4, 0.3, R.y);
    float top = 0.35 * smoothstep(0.55, 0.95, R.y);
    vec3 floorC = vec3(0.93, 0.78, 0.55) * 0.35 * smoothstep(-0.1, -0.7, R.y);
    return vec3(0.16) + vec3(key + fill + top) + floorC;
  }

  void main() {
    vec4 tex = texture2D(uMap, vUv);
    if (tex.a < 0.02) discard;
    vec3 N = normalize(vN);
    if (!gl_FrontFacing) N = -N;
    vec3 V = normalize(-vViewPos);
    vec3 L = normalize(uLight);
    float ndl = max(dot(N, L), 0.0);

    // the printable areas (label base + white border) take the finish; ink stays ink
    float isBase = 1.0 - smoothstep(0.05, 0.14, distance(tex.rgb, uBaseColor));
    float isWhite = 1.0 - smoothstep(0.03, 0.1, distance(tex.rgb, vec3(1.0)));
    float stock = max(isBase, isWhite);

    vec3 base = tex.rgb;
    float fres = 1.0 - max(dot(N, V), 0.0);
    vec3 R = reflect(-V, N);
    vec3 env = studio(R);
    vec3 rainbow = 0.5 + 0.5 * cos(6.2831 * (fres * 1.4 + vUv.x * 0.8 + R.x * 0.6 + vec3(0.0, 0.33, 0.67)));
    base = mix(base, base * (0.5 + 0.95 * rainbow) + env * 0.12, uHolo * stock);
    // chrome: the stock becomes a mirror of the studio, faintly tinted by the print
    base = mix(base, env * mix(vec3(0.92), base, 0.12), uMetal * stock);

    float diffuse = mix(1.0, 0.62 + 0.5 * ndl, uLit);
    vec3 H = normalize(L + V);
    // matte has no highlight at all; gloss gets a tight one plus a clear coat that mirrors the
    // studio softboxes (strongest at grazing angles), so the two read differently at a glance
    float spec = pow(max(dot(N, H), 0.0), mix(14.0, 160.0, uGloss)) * 1.4 * uGloss * uLit;
    float coat = uGloss * uLit * (0.3 + 0.6 * pow(fres, 2.0));
    diffuse *= mix(1.0, 0.94, (1.0 - uGloss) * uLit); // matte stock soaks up a little light
    vec3 col = base * mix(diffuse, 1.0, uMetal * stock * 0.7) + spec * mix(vec3(1.0), base + 0.3, uMetal) + env * coat;

    float alpha = tex.a * (1.0 - uClear * stock * 0.9);
    gl_FragColor = vec4(col, alpha);
    #include <colorspace_fragment>
  }
`;

export function wrapUniforms(map: THREE.Texture, radius: number) {
  return {
    uMap: { value: map },
    uWrap: { value: 0 },
    uR: { value: radius },
    uZ: { value: radius * 1.01 },
    uLight: { value: new THREE.Vector3(-0.4, 0.3, 1) },
    uBaseColor: { value: new THREE.Color(C.marigold) },
    uLit: { value: 0 },
    uGloss: { value: 0 },
    uMetal: { value: 0 },
    uHolo: { value: 0 },
    uClear: { value: 0 },
  };
}

/** Finish chip → uniform targets (tweened over 0.6s expo.out). */
export const WRAP_FINISHES = [
  { name: "Matte", gloss: 0, metal: 0, holo: 0, clear: 0 },
  { name: "Gloss", gloss: 1, metal: 0, holo: 0, clear: 0 },
  { name: "Holo", gloss: 0.8, metal: 0.15, holo: 1, clear: 0 },
  { name: "Chrome", gloss: 1, metal: 1, holo: 0, clear: 0 },
  { name: "Clear", gloss: 0.9, metal: 0, holo: 0, clear: 1 },
] as const;
