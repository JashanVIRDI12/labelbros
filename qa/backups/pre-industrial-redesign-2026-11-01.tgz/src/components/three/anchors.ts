/** Camera and DOM → world mapping shared by every 3D moment. */
export const CAM_Z = 12;
export const FOV = 30;

/** World units per CSS pixel on the z = 0 plane, for a viewport `height` px tall. */
export function worldPerPx(height: number, camZ = CAM_Z) {
  return (2 * camZ * Math.tan((FOV * Math.PI) / 360)) / height;
}

export type Anchor = { x: number; y: number; w: number; h: number; rot: number };

/**
 * Where an element sits on screen, in world units, when `section` is pinned at the top of the
 * viewport (its own top = viewport top). Uses layout size (offsetWidth/Height) and the CSS
 * `rotate` property so rotated stickers keep their true size and angle.
 */
export function anchorInPinnedSection(el: HTMLElement, section: HTMLElement, view: { width: number; height: number }): Anchor {
  const k = worldPerPx(view.height);
  const r = el.getBoundingClientRect();
  const s = section.getBoundingClientRect();
  const cx = r.left + r.width / 2;
  const cy = r.top - s.top + r.height / 2;
  const deg = parseFloat(getComputedStyle(el).rotate) || 0;
  return {
    x: (cx - view.width / 2) * k,
    y: -(cy - view.height / 2) * k,
    w: el.offsetWidth * k,
    h: el.offsetHeight * k,
    rot: (-deg * Math.PI) / 180,
  };
}

export const smoothstep = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
