"use client";

import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { HERO_INTRO_EVENT } from "@/components/sections/hero/HeroMotion";
import { brosBubble, flame, freshBatch, no1Badge, smallBrandTag, stripedBall, type StickerArt } from "@/components/stickers/art";
import { ScrollTrigger } from "@/lib/gsap";
import { scrollStore } from "@/lib/scrollStore";
import { setThreeFlag } from "@/lib/threeFlags";
import { anchorInPinnedSection, smoothstep, worldPerPx, type Anchor } from "./anchors";
import { ContactShadow, damp, placeShadow, useStickerMesh } from "./common";
import { peelFragment, peelVertex } from "./shaders/peel";
import { stickerTexture } from "./stickerTexture";

/**
 * Every hero sticker plays the same single idea: lift from a corner, then orbit out by the
 * right edge. The two in the headline go first, the four around the phone follow.
 * `selector` finds the DOM twin's untransformed [data-anchor] inside the hero.
 */
const STICKERS: { art: StickerArt; selector: string; dir: [number, number]; spin: number; delay: number }[] = [
  { art: no1Badge, selector: '[data-inline-sticker="no1"] [data-anchor]', dir: [-1, 1], spin: 1, delay: 0 },
  { art: flame, selector: '[data-inline-sticker="flame"] [data-anchor]', dir: [1, 1], spin: -1, delay: 0.03 },
  { art: freshBatch, selector: '[data-float="fresh"] [data-anchor]', dir: [1, 1], spin: -1, delay: 0.08 },
  { art: brosBubble, selector: '[data-float="bros"] [data-anchor]', dir: [1, -1], spin: 1, delay: 0.11 },
  { art: smallBrandTag, selector: '[data-float="tag"] [data-anchor]', dir: [-1, 1], spin: -1, delay: 0.14 },
  { art: stripedBall, selector: '[data-float="ball"] [data-anchor]', dir: [-1, -1], spin: 1, delay: 0.17 },
];

/** Peel over the first ~half of the pin (spec: 0 → 0.5), gone by the right edge before the phone moves. */
function PeelingSticker({ map, a, dir, spin, delay, index }: { map: THREE.Texture; a: Anchor; dir: [number, number]; spin: number; delay: number; index: number }) {
  const mesh = useRef<THREE.Mesh>(null);
  const shadow = useRef<THREE.Mesh>(null);
  const cur = useRef(0);
  const size = useThree((s) => s.size);
  const { geo, uniforms } = useStickerMesh(map, a, dir, 48);

  const curve = useMemo(() => {
    const k = worldPerPx(size.height);
    const hw = (size.width / 2) * k;
    const hh = (size.height / 2) * k;
    return new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(a.x, a.y, 0),
        new THREE.Vector3(a.x + 0.25, a.y + 0.3, 0.9),
        new THREE.Vector3(Math.max(a.x, 0) + hw * 0.35, hh * (0.45 - index * 0.12), 1.5),
        new THREE.Vector3(hw + Math.max(a.w, a.h) + 1, hh * (0.55 - index * 0.1), 1.2),
      ],
      false,
      "centripetal",
    );
  }, [a.x, a.y, a.w, a.h, index, size.width, size.height]);

  useFrame((state, dt) => {
    const m = mesh.current;
    const s = shadow.current;
    if (!m || !s) return;
    const raw = scrollStore.hero;
    cur.current = damp(cur.current, raw, 6, dt);
    const p = cur.current;
    if (Math.abs(raw - p) > 1e-4) state.invalidate();

    const t = smoothstep(0.02 + delay, 0.55 + delay * 0.5, p);
    const show = scrollStore.scenes.has("hero") && (raw > 0.002 || p > 0.002) && t < 0.999;
    m.visible = s.visible = show;
    if (!show) return;

    // a corner curl (not a fold), easing back to a slight curl once airborne
    const curl = smoothstep(0, 0.18, t);
    (m.material as THREE.ShaderMaterial).uniforms.uPeel.value = 0.3 * curl - 0.2 * smoothstep(0.25, 0.6, t);
    const pt = curve.getPointAt(t);
    m.position.copy(pt);
    // paper-light flutter while airborne (zero on the paper and at the edge of frame)
    const flutter = Math.sin(t * 16 + index * 1.9) * 0.14 * Math.sin(Math.PI * t);
    m.rotation.set(t * 0.5 + flutter, t * 0.8 * spin, a.rot + t * 1.3 * spin + flutter * 0.6);
    placeShadow(s, pt.x, pt.y, pt.z, a.w, a.h);
  });

  return (
    <>
      <ContactShadow shadowRef={shadow} />
      <mesh ref={mesh} geometry={geo} renderOrder={3 + index} visible={false}>
        <shaderMaterial uniforms={uniforms} vertexShader={peelVertex} fragmentShader={peelFragment} transparent side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
    </>
  );
}

/**
 * S1 in 3D (desktop, high tier). The DOM stickers stay on screen at rest (crisp, no GPU work);
 * the moment the peel starts, these exact copies take over. Ready only after the load intro.
 */
export function HeroStickers() {
  const size = useThree((s) => s.size);
  const invalidate = useThree((s) => s.invalidate);
  const [maps, setMaps] = useState<Record<string, THREE.Texture> | null>(null);
  const [introDone, setIntroDone] = useState(() => document.documentElement.dataset.heroIntro === "done");
  const [anchors, setAnchors] = useState<Record<string, Anchor> | null>(null);

  useEffect(() => {
    let alive = true;
    Promise.all(STICKERS.map(({ art }) => stickerTexture(art, 768))).then((list) => {
      if (alive) setMaps(Object.fromEntries(STICKERS.map(({ art }, i) => [art.id, list[i]])));
    });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (introDone) return;
    const on = () => setIntroDone(true);
    window.addEventListener(HERO_INTRO_EVENT, on);
    return () => window.removeEventListener(HERO_INTRO_EVENT, on);
  }, [introDone]);

  useEffect(() => {
    if (!introDone) return;
    const section = document.querySelector<HTMLElement>("[data-hero]");
    if (!section) return;
    const measure = () => {
      const items: Record<string, Anchor> = {};
      for (const { art, selector } of STICKERS) {
        const el = section.querySelector<HTMLElement>(selector);
        if (el) items[art.id] = anchorInPinnedSection(el, section, size);
      }
      setAnchors(items);
      invalidate();
    };
    measure();
    ScrollTrigger.addEventListener("refresh", measure);
    return () => ScrollTrigger.removeEventListener("refresh", measure);
  }, [introDone, size, invalidate]);

  const ready = Boolean(maps && anchors);
  useEffect(() => {
    if (!ready) return;
    setThreeFlag("hero", true);
    return () => setThreeFlag("hero", false);
  }, [ready]);

  if (!maps || !anchors) return null;
  return (
    <group>
      {STICKERS.map(({ art, dir, spin, delay }, i) =>
        anchors[art.id] ? <PeelingSticker key={art.id} map={maps[art.id]} a={anchors[art.id]} dir={dir} spin={spin} delay={delay} index={i} /> : null,
      )}
    </group>
  );
}
