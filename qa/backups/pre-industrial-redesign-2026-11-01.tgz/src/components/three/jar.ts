/** Shared by the S3 jar and the S2 label that flies onto it, so the hand-off lines up. */
// 151° of the jar: the whole artwork stays readable on the front once wrapped.
export const WRAP_FRACTION = 0.42;
// how far in front of the jar (× radius) the flat label waits before it wraps
export const LABEL_APPROACH = 0.55;
