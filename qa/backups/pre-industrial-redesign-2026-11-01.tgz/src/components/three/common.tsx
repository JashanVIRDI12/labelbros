"use client";

import { useEffect, useMemo } from "react";
import * as THREE from "three";
import { smoothstep, type Anchor } from "./anchors";
import { peelUniforms } from "./shaders/peel";
import { shadowTexture } from "./stickerTexture";

export const damp = THREE.MathUtils.damp;

/** Contact shadow: appears as soon as a sticker leaves the paper, fades as it climbs. */
export const contactShadow = (z: number) => 0.28 * smoothstep(0, 0.12, z) * (1 - smoothstep(0.18, 0.5, z));

export function ContactShadow({ shadowRef }: { shadowRef: React.RefObject<THREE.Mesh | null> }) {
  return (
    <mesh ref={shadowRef} renderOrder={1} visible={false}>
      <planeGeometry args={[1, 1]} />
      <meshBasicMaterial map={shadowTexture()} transparent depthWrite={false} opacity={0} toneMapped={false} />
    </mesh>
  );
}

/** Plane at the sticker's real size (keeps the curl round) + peel uniforms. */
export function useStickerMesh(map: THREE.Texture, a: Anchor, dir: [number, number], segments: number) {
  const geo = useMemo(() => new THREE.PlaneGeometry(a.w, a.h, segments, segments), [a.w, a.h, segments]);
  useEffect(() => () => geo.dispose(), [geo]);
  const uniforms = useMemo(() => peelUniforms(map, [a.w, a.h], dir), [map, a.w, a.h, dir]);
  return { geo, uniforms };
}

/** Move a contact shadow under a sticker at height z. */
export function placeShadow(s: THREE.Mesh, x: number, y: number, z: number, w: number, h: number, scale = 1) {
  s.position.set(x + z * 0.1, y - z * 0.16, 0);
  s.scale.set(w * (1 + z * 0.25) * scale, h * (1 + z * 0.25) * scale, 1);
  (s.material as THREE.MeshBasicMaterial).opacity = contactShadow(z) * scale;
}
