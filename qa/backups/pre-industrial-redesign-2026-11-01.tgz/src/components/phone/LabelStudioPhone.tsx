import { ArrowLeft, LayoutTemplate, Save, Shapes, Type, Upload } from "lucide-react";
import { Sticker } from "@/components/stickers/Sticker";
import { honeyArtOnly, honeyBlank } from "@/components/stickers/art";
import { phone } from "@/data/copy";
import { cn } from "@/lib/utils";

const tabIcons = [LayoutTemplate, Type, Shapes, Upload];

type Props = {
  className?: string;
  /** canvas content; defaults to the honey label with its die line and selection handles */
  children?: React.ReactNode;
};

/**
 * The reference's sticker-editor phone, rebuilt in DOM so it stays crisp. Sized with
 * container query units, so it scales with its width. Purely illustrative (aria-hidden):
 * the surrounding section describes what it shows.
 */
export function LabelStudioPhone({ className, children }: Props) {
  return (
    <div
      aria-hidden="true"
      data-phone
      className={cn("relative aspect-[300/610] w-full overflow-hidden rounded-phone bg-white", className)}
      style={{ containerType: "inline-size", boxShadow: "0 40px 80px -48px rgb(10 10 10 / 0.35)" }}
    >
      <div className="flex h-full flex-col">
        <div className="flex h-[24cqw] shrink-0 items-center justify-between bg-orange px-[6cqw] pt-[4cqw] text-ink">
          <ArrowLeft className="size-[7cqw]" strokeWidth={2.5} />
          <div className="text-center">
            <p className="type-label text-[5cqw]">{phone.title}</p>
            <p className="type-label mt-[1.2cqw] text-[3cqw] font-medium opacity-90">{phone.subtitle}</p>
          </div>
          <Save className="size-[6.5cqw]" strokeWidth={2.2} />
        </div>

        <div
          data-phone-canvas
          className="relative flex-1"
          style={{
            backgroundImage: "radial-gradient(circle, #d9d8d4 0.9px, transparent 1.3px)",
            backgroundSize: "5.4cqw 5.4cqw",
            backgroundPosition: "center",
          }}
        >
          {children ?? <PhoneLabel />}
        </div>

        <div className="flex shrink-0 gap-[2cqw] overflow-hidden px-[4cqw] pb-[3cqw]">
          {phone.chips.map((chip, i) => (
            <span
              key={chip}
              className="type-label inline-flex h-[8.6cqw] shrink-0 items-center gap-[1.6cqw] rounded-chip border border-frame px-[3.4cqw] text-[3.2cqw]"
            >
              {i === 0 && <span className="size-[3cqw] rounded-chip bg-marigold" />}
              {chip}
            </span>
          ))}
        </div>

        <div className="grid shrink-0 grid-cols-4 border-t border-frame px-[3cqw] pt-[3.5cqw] pb-[8cqw]">
          {phone.tabs.map((tab, i) => {
            const Icon = tabIcons[i];
            const active = i === phone.tabs.length - 1;
            return (
              <span key={tab} className={cn("relative flex flex-col items-center gap-[1.6cqw]", active && "text-orange-text")}>
                <Icon className="size-[5.6cqw]" strokeWidth={2} />
                <span className="type-label text-[2.9cqw]">{tab}</span>
                {active && <span className="absolute -bottom-[3.2cqw] size-[1.4cqw] rounded-chip bg-orange" />}
              </span>
            );
          })}
        </div>
      </div>
      <span className="absolute bottom-[2.4cqw] left-1/2 h-[1.3cqw] w-[34%] -translate-x-1/2 rounded-chip bg-ink" />
    </div>
  );
}

/** Honey label on the canvas, with the kiss-cut die line (DrawSVG target) and editor handles. */
export function PhoneLabel() {
  return (
    <div className="absolute inset-x-[5%] top-[46%] -translate-y-1/2">
      <div className="relative">
        <Sticker art={honeyBlank} className="block w-full" />
        <span data-hero-art className="absolute inset-0">
          <Sticker art={honeyArtOnly} className="block h-full w-full" />
        </span>
        {/* die line 12 units outside the label, in the label's own coordinates */}
        <svg viewBox="0 0 480 200" className="pointer-events-none absolute inset-0 h-full w-full overflow-visible">
          <rect
            data-dieline
            x="-12"
            y="-12"
            width="504"
            height="224"
            rx="34"
            fill="none"
            stroke="#565DC5"
            strokeWidth="2"
            vectorEffect="non-scaling-stroke"
          />
        </svg>
        {[
          { left: "-2.5%", top: "-6%" },
          { left: "102.5%", top: "-6%" },
          { left: "-2.5%", top: "106%" },
          { left: "102.5%", top: "106%" },
        ].map((pos) => (
          <span
            key={`${pos.left}${pos.top}`}
            data-handle
            className="absolute size-[2.6cqw] -translate-x-1/2 -translate-y-1/2 border-[1.5px] border-periwinkle bg-white"
            style={pos}
          />
        ))}
        <span
          data-dimension
          className="type-label absolute left-1/2 top-[calc(100%+9cqw)] -translate-x-1/2 whitespace-nowrap rounded-chip border border-frame bg-white px-[3cqw] py-[1.6cqw] text-[2.9cqw] text-ink-soft"
        >
          3.5 × 1.5 in · Kiss cut
        </span>
      </div>
    </div>
  );
}
