import { cn } from "@/lib/utils";

type Variant = "ink" | "outline" | "paper";
type Size = "md" | "lg";

const variants: Record<Variant, string> = {
  ink: "bg-ink text-paper hover:bg-forest",
  outline: "border-2 border-ink text-ink hover:bg-ink hover:text-paper",
  paper: "bg-paper text-ink hover:bg-marigold",
};

const sizes: Record<Size, string> = {
  md: "h-11 px-5 text-14 gap-2",
  lg: "h-14 px-7 text-16 gap-3",
};

export function pillClass(variant: Variant = "ink", size: Size = "lg", className?: string) {
  return cn(
    "type-label inline-flex items-center justify-center rounded-chip whitespace-nowrap select-none",
    "transition-colors duration-200 ease-out",
    variants[variant],
    sizes[size],
    className,
  );
}

export function Arrow({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={cn("size-[1.1em] shrink-0", className)} aria-hidden="true" focusable="false">
      <path d="M3 10h13M11 4.5 16.5 10 11 15.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

type PillLinkProps = React.AnchorHTMLAttributes<HTMLAnchorElement> & {
  variant?: Variant;
  size?: Size;
  arrow?: boolean;
};

export function PillLink({ variant = "ink", size = "lg", arrow, className, children, ...props }: PillLinkProps) {
  return (
    <a className={pillClass(variant, size, className)} {...props}>
      <span>{children}</span>
      {arrow && <Arrow />}
    </a>
  );
}
