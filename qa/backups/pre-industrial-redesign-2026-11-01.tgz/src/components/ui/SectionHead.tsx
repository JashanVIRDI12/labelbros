import { cn } from "@/lib/utils";

type Props = {
  eyebrow: string;
  title: string;
  caption?: string;
  id?: string;
  className?: string;
  /** big display H2 (default) or a small label-sized one when a stage carries the big type */
  size?: "xl" | "sm";
  tone?: "ink" | "paper";
};

/** Eyebrow caption + Anton H2, in the reference's step-row voice. */
export function SectionHead({ eyebrow, title, caption, id, className, size = "xl", tone = "ink" }: Props) {
  return (
    <div className={className}>
      <p className={cn("type-caption", tone === "paper" && "text-paper/70")}>{eyebrow}</p>
      <h2
        id={id}
        className={cn(
          "type-display mt-3",
          size === "xl" ? "text-[clamp(3rem,7.5vw,7rem)] leading-[0.9]" : "text-32",
        )}
      >
        {title}
      </h2>
      {caption && <p className={cn("type-caption mt-4", tone === "paper" && "text-paper/70")}>{caption}</p>}
    </div>
  );
}
