import { DesignChoice } from "@/components/sections/DesignChoice";
import { FinalCta } from "@/components/sections/FinalCta";
import { Hero } from "@/components/sections/Hero";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { Materials } from "@/components/sections/Materials";
import { Products } from "@/components/sections/Products";
import { Quote } from "@/components/sections/Quote";
import { Reviews } from "@/components/sections/Reviews";
import { SamplePack } from "@/components/sections/SamplePack";
import { Wrap } from "@/components/sections/Wrap";

export default function Home() {
  return (
    <>
      <Hero />
      <HowItWorks />
      <Wrap />
      <DesignChoice />
      <Products />
      <Materials />
      <Quote />
      <Reviews />
      <SamplePack />
      <FinalCta />
    </>
  );
}
