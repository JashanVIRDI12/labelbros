import type { Metadata, Viewport } from "next";
import { Anton, Archivo } from "next/font/google";
import Script from "next/script";
import { Footer } from "@/components/layout/Footer";
import { Header } from "@/components/layout/Header";
import { PageFrame, PaperGrid } from "@/components/layout/PageFrame";
import { SmoothScroll } from "@/components/layout/SmoothScroll";
import { CanvasRoot } from "@/components/three/CanvasRoot";
import { brand } from "@/data/copy";
import { reduceMotionBootScript } from "@/lib/motion";
import "./globals.css";

const anton = Anton({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-anton",
  display: "swap",
  preload: true,
  fallback: ["Arial Narrow", "sans-serif"],
});

const archivo = Archivo({
  subsets: ["latin"],
  variable: "--font-archivo",
  display: "swap",
  axes: ["wdth"],
  fallback: ["Arial Narrow", "sans-serif"],
});

export const metadata: Metadata = {
  // [[DOMAIN]]: add metadataBase + canonical once the domain is known
  title: "Label Bros: custom labels and stickers", // COPY:
  description: brand.description,
  openGraph: {
    title: "Label Bros: custom labels and stickers", // COPY:
    description: brand.description,
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#F5F4F2",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${anton.variable} ${archivo.variable}`} suppressHydrationWarning>
      <head>
        <Script id="reduce-motion-boot" strategy="beforeInteractive">
          {reduceMotionBootScript}
        </Script>
      </head>
      <body>
        <a
          href="#main"
          className="type-label sr-only fixed left-4 top-4 z-[60] rounded-chip bg-ink px-5 py-3 text-paper focus:not-sr-only"
        >
          Skip to content
        </a>
        <PageFrame />
        <Header />
        <main id="main" className="relative z-[1] overflow-x-clip bg-paper" style={{ clipPath: "inset(0)" }}>
          <PaperGrid />
          {children}
        </main>
        <span data-footer-start aria-hidden="true" className="block h-px" />
        <Footer />
        <aside aria-label="Label illustrations"><CanvasRoot /></aside>
        <SmoothScroll />
      </body>
    </html>
  );
}
