/** Footer links. Routes other than in-page anchors are placeholders until those pages exist. [[LINKS]] */
export const footerColumns = [
  {
    title: "Products",
    links: [
      { label: "Roll labels", href: "#products" },
      { label: "Product labels", href: "#products" },
      { label: "Die-cut stickers", href: "#products" },
      { label: "Sticker sheets", href: "#products" },
      { label: "Clear labels", href: "#products" },
      { label: "Holographic", href: "#products" },
    ],
  },
  {
    title: "Materials",
    links: [
      { label: "Matte & gloss", href: "#materials" },
      { label: "Clear", href: "#materials" },
      { label: "Holo & chrome", href: "#materials" },
      { label: "Kraft", href: "#materials" },
      { label: "Sample pack", href: "#samples" },
    ],
  },
  {
    title: "Help",
    links: [
      { label: "Artwork guidelines", href: "/artwork-guidelines" },
      { label: "Shipping", href: "/shipping" },
      { label: "FAQ", href: "/faq" },
      { label: "Contact", href: "mailto:[[EMAIL]]" },
    ],
  },
] as const;

export const socials = [
  { label: "Instagram", href: "[[INSTAGRAM_URL]]" },
  { label: "TikTok", href: "[[TIKTOK_URL]]" },
  { label: "LinkedIn", href: "[[LINKEDIN_URL]]" },
] as const;

export const company = {
  email: "[[EMAIL]]",
  hours: "[[HOURS]]",
  address: "[[COMPANY_ADDRESS]]",
};
