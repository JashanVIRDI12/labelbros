/**
 * Site copy. Anything in [[DOUBLE_BRACKETS]] is a placeholder that must stay visible
 * until the client supplies it. Lines marked COPY: are placeholder voice copy.
 */

export const brand = {
  name: "Label Bros",
  // [[LOGO_SVG]]: Anton wordmark until the logo arrives
  wordmark: "LABEL BROS",
  // [[ONE_LINE_DESCRIPTION]]
  description:
    "Custom product labels, roll labels and die-cut stickers for small brands. Get instant pricing or order a sample pack.", // COPY:
};

export const nav = [
  { label: "Products", href: "#products" },
  { label: "Materials", href: "#materials" },
  { label: "How it works", href: "#how" },
  { label: "Samples", href: "#samples" },
  { label: "Deals", href: "#samples" },
] as const;

export const cta = {
  primary: { label: "Get instant pricing", href: "#quote" },
  secondary: { label: "Order a sample pack", href: "#samples" },
  quote: { label: "Get a quote", href: "#quote" },
};

export const hero = {
  // [[HERO_HEADLINE]] default. Stickers: Nº1 badge after line 1, flame starts line 2.
  lines: ["Label it", "Like you", "Mean it"] as const,
  steps: [
    { n: "01", title: "Design", caption: "Build it, upload it, or we design it" }, // COPY:
    { n: "02", title: "Proof", caption: "Free proof in [[PROOF_TIME]]" },
    { n: "03", title: "Stick", caption: "Ships in [[TURNAROUND]]" },
  ],
  trust: { rating: "[[RATING]]", reviews: "[[REVIEW_COUNT]]" },
};

export const phone = {
  title: "Untitled",
  subtitle: "Custom label",
  chips: ["Color", "Shape", "Finish", "Size"],
  tabs: ["Templates", "Text", "Shapes", "Upload"],
};

// [[STEP_COPY]]: placeholder voice copy for the four steps
export const how = {
  eyebrow: "How it works",
  title: "From file to shelf", // COPY:
  steps: [
    {
      n: "01",
      title: "Design",
      line: "Upload your art or build it in Label Studio.", // COPY:
      caption: "PDF, AI, PNG or start from a template", // COPY:
    },
    {
      n: "02",
      title: "Proof",
      line: "A human checks your file and sends a free proof in [[PROOF_TIME]].", // COPY:
      caption: "Nothing prints till you say go", // COPY:
    },
    {
      n: "03",
      title: "Print",
      line: "Printed on the material you picked, matched to your proof.", // COPY:
      caption: "[[PRINT_SPEC]]",
    },
    {
      n: "04",
      title: "Stick",
      line: "Kiss-cut, packed and shipped in [[TURNAROUND]].", // COPY:
      caption: "Peel. Stick. Sell out.", // COPY:
    },
  ],
};

export const wrap = {
  eyebrow: "The wrap",
  // [[WRAP_HEADLINE]] default
  lines: ["Flat art.", "Full wrap.", "Zero bubbles."] as const,
  proof: ["Waterproof", "Scuff-proof", "[[CLAIM]]"],
  finishes: ["Matte", "Gloss", "Holo", "Chrome", "Clear"] as const,
};

export const productsCopy = {
  eyebrow: "Products",
  title: "Pick your stick.", // COPY:
  caption: "Eight ways to label a thing", // COPY:
};

export const materialsCopy = {
  eyebrow: "Materials & finishes",
  title: "Same art. Eight finishes.", // COPY:
  caption: "Scroll to swap the finish", // COPY:
};

export const quoteCopy = {
  eyebrow: "Instant quote",
  title: "Price it right now.", // COPY:
  caption: "No email, no call, no waiting", // COPY:
};

export const reviewsCopy = {
  eyebrow: "Reviews",
  title: "Stuck on us.", // COPY:
};

export const sample = {
  eyebrow: "Sample pack",
  title: "Feel it before you order.",
  price: "[[SAMPLE_PRICE]]",
  points: [
    { title: "Every material", caption: "One pack, all eight finishes" }, // COPY:
    { title: "Free proof", caption: "On every single order" }, // COPY:
    { title: "Reprint guarantee", caption: "[[GUARANTEE_TERMS]]" },
  ],
  code: "[[CODE]]",
  peelHint: "Peel for a discount code", // COPY:
};

export const finalCta = {
  // [[CTA_HEADLINE]] default
  headline: "Stick with us.",
  human: "Talk to a human",
  email: "[[EMAIL]]",
  hours: "[[HOURS]]",
};

/** Your art or ours: design it yourself in Label Studio, or have Label Bros design it. */
export const designChoice = {
  eyebrow: "Your art or ours",
  title: "Design it yourself. Or don't.", // COPY:
  options: ["I'll design it", "Design it for me"] as const, // COPY:
  diy: {
    name: "Label Studio",
    line: "Build your label right in the browser: start from a template, drop in your logo, see the die cut as you go.", // COPY:
    points: [
      { title: "Templates", caption: "[[TEMPLATE_COUNT]] to start from" },
      { title: "Your files", caption: "AI, PDF, PNG or SVG" }, // COPY:
      { title: "Live preview", caption: "Die line and finish as you edit" }, // COPY:
    ],
    cta: { label: "Open Label Studio", href: "[[LABEL_STUDIO_URL]]" },
  },
  dfy: {
    name: "Our designers",
    line: "Tell us about your product. A real designer drafts your label, and nothing prints until you love the proof.", // COPY:
    points: [
      { title: "Design fee", caption: "[[DESIGN_FEE]]" },
      { title: "First draft", caption: "In [[DESIGN_TURNAROUND]]" },
      { title: "Revisions", caption: "[[DESIGN_REVISIONS]] rounds included" },
    ],
    cta: { label: "Start a design brief", href: "[[DESIGN_BRIEF_URL]]" },
    note: "v1 for your review", // COPY:
  },
};

/** Quote widget: who makes the artwork decides where the CTA goes. */
export const quoteArtwork = [
  { id: "upload", label: "I have artwork", cta: "Continue to upload", href: "/upload" }, // COPY:
  { id: "studio", label: "Design it myself", cta: "Open Label Studio", href: "[[LABEL_STUDIO_URL]]" }, // COPY:
  { id: "design", label: "Design it for me", cta: "Start a design brief", href: "[[DESIGN_BRIEF_URL]]" }, // COPY:
] as const;
