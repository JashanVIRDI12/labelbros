/** S7 social proof. Every quote, name, brand and logo is a visible placeholder until [[REVIEWS]] / [[LOGOS]] arrive. */
export type Review = { quote: string; name: string; brand: string; color: "marigold" | "forest" | "bubblegum" | "periwinkle" | "orange" | "white"; shape: "round" | "tag" | "oval" | "blob" };

const short = "Placeholder: a short customer quote.";
const mid = "Placeholder: a customer quote about the print quality and the free proof.";
const long = "Placeholder: a longer customer quote about the proof, the print quality, the turnaround and how the labels look on the shelf.";

export const reviews: Review[] = [
  { quote: mid, name: "[[NAME]]", brand: "[[BRAND]]", color: "marigold", shape: "tag" },
  { quote: short, name: "[[NAME]]", brand: "[[BRAND]]", color: "forest", shape: "round" },
  { quote: long, name: "[[NAME]]", brand: "[[BRAND]]", color: "white", shape: "tag" },
  { quote: mid, name: "[[NAME]]", brand: "[[BRAND]]", color: "bubblegum", shape: "oval" },
  { quote: short, name: "[[NAME]]", brand: "[[BRAND]]", color: "periwinkle", shape: "blob" },
  { quote: long, name: "[[NAME]]", brand: "[[BRAND]]", color: "orange", shape: "tag" },
  { quote: mid, name: "[[NAME]]", brand: "[[BRAND]]", color: "white", shape: "oval" },
  { quote: short, name: "[[NAME]]", brand: "[[BRAND]]", color: "marigold", shape: "round" },
  { quote: long, name: "[[NAME]]", brand: "[[BRAND]]", color: "forest", shape: "tag" },
  { quote: mid, name: "[[NAME]]", brand: "[[BRAND]]", color: "bubblegum", shape: "blob" },
  { quote: short, name: "[[NAME]]", brand: "[[BRAND]]", color: "periwinkle", shape: "round" },
  { quote: mid, name: "[[NAME]]", brand: "[[BRAND]]", color: "white", shape: "oval" },
];

export const rating = { value: "[[RATING]]", count: "[[REVIEW_COUNT]]" };

export const logos = Array.from({ length: 8 }, (_, i) => `[[LOGO_${String(i + 1).padStart(2, "0")}]]`);

export const caseStudies = [
  {
    brand: "[[CASE_STUDY_1]]",
    title: "Placeholder: what they make and what we printed", // COPY:
    body: "Placeholder: two lines on the problem, the label we made and what changed on the shelf. Real numbers only.",
    color: "forest" as const,
  },
  {
    brand: "[[CASE_STUDY_2]]",
    title: "Placeholder: a second brand story", // COPY:
    body: "Placeholder: two lines on the problem, the label we made and what changed on the shelf. Real numbers only.",
    color: "periwinkle" as const,
  },
];
