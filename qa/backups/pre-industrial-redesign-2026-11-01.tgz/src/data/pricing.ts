/**
 * S6 quote pricing. [[REAL_PRICING]]: every number below is SAMPLE data so the widget works.
 * While SAMPLE_PRICING is true the UI says "Sample pricing, not final".
 */
export const SAMPLE_PRICING = true;

export const productTypes = [
  { id: "roll", label: "Roll labels", perSqIn: 0.05 },
  { id: "product", label: "Product labels", perSqIn: 0.06 },
  { id: "diecut", label: "Die-cut", perSqIn: 0.08 },
  { id: "sheet", label: "Sheets", perSqIn: 0.07 },
  { id: "clear", label: "Clear", perSqIn: 0.07 },
  { id: "holo", label: "Holo", perSqIn: 0.1 },
] as const;

export const quoteMaterials = [
  { id: "matte", label: "Matte", mult: 1 },
  { id: "gloss", label: "Gloss", mult: 1 },
  { id: "clear", label: "Clear", mult: 1.15 },
  { id: "holo", label: "Holo", mult: 1.4 },
  { id: "chrome", label: "Chrome", mult: 1.5 },
  { id: "kraft", label: "Kraft", mult: 1.1 },
] as const;

export const sizePresets = [
  { id: "2x2", label: '2 × 2"', w: 2, h: 2 },
  { id: "3x3", label: '3 × 3"', w: 3, h: 3 },
  { id: "4x4", label: '4 × 4"', w: 4, h: 4 },
  { id: "35x15", label: '3.5 × 1.5"', w: 3.5, h: 1.5 },
] as const;

export const SIZE_MIN = 0.5;
export const SIZE_MAX = 12;

/** Quantities the slider steps through (log-ish, so small and big runs both get room). */
export const quantities = [50, 100, 150, 200, 250, 300, 400, 500, 750, 1000, 1500, 2000, 2500, 3000, 4000, 5000, 7500, 10000];

/** Price breaks: at or above `qty`, unit price is multiplied by `mult`. */
export const breaks = [
  { qty: 50, mult: 1 },
  { qty: 100, mult: 0.82 },
  { qty: 250, mult: 0.66 },
  { qty: 500, mult: 0.54 },
  { qty: 1000, mult: 0.44 },
  { qty: 2500, mult: 0.36 },
  { qty: 5000, mult: 0.3 },
];

const MIN_ORDER = 25;
const MIN_UNIT = 0.04;

export type QuoteInput = {
  product: (typeof productTypes)[number]["id"];
  material: (typeof quoteMaterials)[number]["id"];
  w: number;
  h: number;
  qty: number;
};

export type QuoteResult = {
  total: number;
  unit: number;
  /** next price break, if any: how many more to add and the per-unit saving */
  next: { add: number; savePct: number } | null;
};

const breakFor = (qty: number) => [...breaks].reverse().find((b) => qty >= b.qty) ?? breaks[0];

function unitPrice(input: QuoteInput, qty: number) {
  const product = productTypes.find((p) => p.id === input.product) ?? productTypes[0];
  const material = quoteMaterials.find((m) => m.id === input.material) ?? quoteMaterials[0];
  const area = input.w * input.h;
  return Math.max(MIN_UNIT, area * product.perSqIn * material.mult * breakFor(qty).mult);
}

export function sizeError(w: number, h: number): string | null {
  if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return "Enter a width and height to see your price.";
  if (w < SIZE_MIN || h < SIZE_MIN || w > SIZE_MAX || h > SIZE_MAX) return `Sizes run from ${SIZE_MIN} to ${SIZE_MAX} inches.`;
  return null;
}

export function quote(input: QuoteInput): QuoteResult {
  if (sizeError(input.w, input.h)) throw new RangeError("Enter a valid label size.");
  if (!quantities.includes(input.qty)) throw new RangeError("Choose an available quantity.");
  const total = Math.max(MIN_ORDER, Math.round(unitPrice(input, input.qty) * input.qty * 100) / 100);
  const unit = total / input.qty;
  const nextBreak = breaks.find((b) => b.qty > input.qty);
  const nextUnit = nextBreak ? Math.max(MIN_ORDER / nextBreak.qty, unitPrice(input, nextBreak.qty)) : unit;
  const savePct = Math.max(0, Math.round((1 - nextUnit / unit) * 100));
  const next = nextBreak && savePct > 0 ? { add: nextBreak.qty - input.qty, savePct } : null;
  return { total, unit, next };
}

export const money = (n: number, digits = 0) =>
  n.toLocaleString("en-US", { style: "currency", currency: "USD", minimumFractionDigits: digits, maximumFractionDigits: digits });
