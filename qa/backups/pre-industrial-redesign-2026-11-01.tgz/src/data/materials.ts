/**
 * S5 materials. [[MATERIALS]]: names, best-for lines and durability flags are placeholders
 * to confirm with the client ([[MATERIAL_SPECS]]). `pbr` drives the 3D finish morph;
 * `swatch` is the 2D fallback (gradients are allowed here because they depict the finish).
 */
export type Durability = "waterproof" | "uv" | "scratch" | "removable";

export type Material = {
  id: string;
  name: string;
  bestFor: string;
  durability: Durability[];
  /** page tint while this finish is on stage */
  tint: string;
  pbr: {
    color: string;
    roughness: number;
    metalness: number;
    clearcoat: number;
    iridescence: number;
    /** 0 = opaque film, 1 = clear film (ink stays opaque) */
    clear: number;
    glitter: number;
    kraft: number;
  };
  swatch: string;
  /** shiny finishes get the ShinyText treatment */
  shiny?: boolean;
};

const KRAFT = "#C9A47C"; // material depiction only, not a UI token

export const materials: Material[] = [
  {
    id: "matte",
    name: "Matte white",
    bestFor: "Coffee bags, candles, anything that wants calm", // COPY:
    durability: ["waterproof", "scratch"],
    tint: "#F5F4F2",
    pbr: { color: "#FFFFFF", roughness: 0.85, metalness: 0, clearcoat: 0, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "#FFFFFF",
  },
  {
    id: "gloss",
    name: "Gloss white",
    bestFor: "Bright colors that need to pop", // COPY:
    durability: ["waterproof", "uv", "scratch"],
    tint: "#FFF6DC",
    pbr: { color: "#FFFFFF", roughness: 0.25, metalness: 0, clearcoat: 1, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "linear-gradient(135deg, #ffffff 0%, #ffffff 42%, #ecebe8 50%, #ffffff 58%, #ffffff 100%)",
  },
  {
    id: "clear",
    name: "Clear",
    bestFor: "Glass bottles and jars: just the ink shows", // COPY:
    durability: ["waterproof", "uv"],
    tint: "#E8EAF8",
    pbr: { color: "#FFFFFF", roughness: 0.15, metalness: 0, clearcoat: 1, iridescence: 0, clear: 1, glitter: 0, kraft: 0 },
    swatch:
      "repeating-conic-gradient(#e2e1dd 0% 25%, #f5f4f2 0% 50%) 50% / 16px 16px",
  },
  {
    id: "holo",
    name: "Holographic",
    bestFor: "Merch, drops, limited runs", // COPY:
    durability: ["waterproof", "scratch"],
    tint: "#FCE3EE",
    pbr: { color: "#E9E9F2", roughness: 0.2, metalness: 0.9, clearcoat: 1, iridescence: 1, clear: 0, glitter: 0, kraft: 0 },
    swatch: "conic-gradient(from 210deg, #f89abc, #f5ba18, #ffffff, #565dc5, #f89abc, #ffffff, #f89abc)",
    shiny: true,
  },
  {
    id: "chrome",
    name: "Chrome",
    bestFor: "Premium spirits, cosmetics, anything shiny", // COPY:
    durability: ["waterproof", "scratch"],
    tint: "#ECEBE8",
    pbr: { color: "#DADADA", roughness: 0.12, metalness: 1, clearcoat: 1, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "linear-gradient(160deg, #6b6a66 0%, #ffffff 30%, #a1a09e 52%, #ffffff 70%, #6b6a66 100%)",
    shiny: true,
  },
  {
    id: "kraft",
    name: "Kraft",
    bestFor: "Natural, handmade, small batch", // COPY:
    durability: ["scratch"],
    tint: "#F1E6D6",
    pbr: { color: KRAFT, roughness: 0.95, metalness: 0, clearcoat: 0, iridescence: 0, clear: 0, glitter: 0, kraft: 1 },
    swatch: `radial-gradient(circle at 20% 30%, rgb(0 0 0 / 0.06) 0 1px, transparent 2px) 0 0 / 7px 7px, ${KRAFT}`,
  },
  {
    id: "glitter",
    name: "Glitter",
    bestFor: "Party goods, kids' stuff, pure joy", // COPY:
    durability: ["waterproof"],
    tint: "#EEEFFB",
    pbr: { color: "#F2F2F7", roughness: 0.4, metalness: 0.6, clearcoat: 0.6, iridescence: 0.3, clear: 0, glitter: 1, kraft: 0 },
    swatch:
      "radial-gradient(circle, #565dc5 0 1px, transparent 1.5px) 0 0 / 9px 9px, radial-gradient(circle, #f89abc 0 1px, transparent 1.5px) 4px 5px / 11px 11px, radial-gradient(circle, #f5ba18 0 1px, transparent 1.5px) 2px 1px / 7px 7px, #f5f4f2",
  },
  {
    id: "removable",
    name: "Removable",
    bestFor: "Laptops, windows, promos: no residue", // COPY:
    durability: ["removable", "waterproof"],
    tint: "#E3F0EA",
    pbr: { color: "#FFFFFF", roughness: 0.7, metalness: 0, clearcoat: 0.2, iridescence: 0, clear: 0, glitter: 0, kraft: 0 },
    swatch: "#FFFFFF",
  },
];

export const durabilityLabel: Record<Durability, string> = {
  waterproof: "Waterproof",
  uv: "UV resistant",
  scratch: "Scratch resistant",
  removable: "Removable",
};
