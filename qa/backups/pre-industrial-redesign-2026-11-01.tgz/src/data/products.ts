/** S4 products. [[PRODUCTS]] and [[PRICE]] are placeholders until the client confirms the range. */
export type Product = {
  id: string;
  name: string;
  line: string;
  price: string;
  href: string;
};

export const products: Product[] = [
  { id: "roll", name: "Roll labels", line: "For hand or machine application, on cores that fit your applicator.", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "product", name: "Product labels", line: "Bottles, jars, tins, tubs. The label that sells the thing.", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "diecut", name: "Die-cut stickers", line: "Cut to the exact shape of your art, white border included.", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "sheet", name: "Sticker sheets", line: "A whole set on one sheet. Kiss-cut, easy peel.", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "clear", name: "Clear labels", line: "No-label look: just your ink on the bottle.", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "holo", name: "Holographic", line: "Catches every light on the shelf.", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "emboss", name: "Embossed", line: "Raised ink you can feel with your thumb.", price: "[[PRICE]]", href: "#quote" }, // COPY:
  { id: "pack", name: "Custom packaging", line: "Boxes and mailers, labeled to match.", price: "[[PRICE]]", href: "#quote" }, // COPY:
];
