/** Hex mirrors of the @theme tokens, for SVG strings and three.js (CSS vars don't reach either). */
export const C = {
  paper: "#F5F4F2",
  frame: "#E2E1DD",
  ink: "#0A0A0A",
  inkSoft: "#6B6A66",
  orange: "#E8641F",
  orangeText: "#C2470F",
  marigold: "#F5BA18",
  forest: "#0A5E46",
  bubblegum: "#F89ABC",
  periwinkle: "#565DC5",
  white: "#FFFFFF",
} as const;
