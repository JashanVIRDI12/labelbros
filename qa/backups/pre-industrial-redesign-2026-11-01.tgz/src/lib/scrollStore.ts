/**
 * Plain mutable store shared by ScrollTriggers (writers) and the R3F scene (reader).
 * ScrollTriggers write progress in onUpdate and call invalidate(); useFrame damps toward
 * these targets. Nothing here triggers React renders, which keeps React out of the hot path.
 */
export type SceneId = "hero" | "how" | "wrap" | "products" | "materials" | "sample";

export const scrollStore = {
  /** S1 pin progress 0..1 */
  hero: 0,
  /** S2 STICK step: kiss-cut label lifts and flies out, 0..1 */
  cut: 0,
  /** S3 approaching: its top travels from the viewport bottom to the top, 0..1 */
  bridge: 0,
  /** S3 pin progress 0..1 */
  wrap: 0,
  /** S3 leaving after its pin: one viewport of scroll, 0..1 */
  wrapOut: 0,
  /** S3 finish chip index */
  finishWrap: 0,
  /** S4 horizontal track progress 0..1 */
  roll: 0,
  /** S5 continuous material position 0..n-1 */
  finish: 0,
  finishIndex: 0,
  /** S8 drag peel 0..1 */
  peel: 0,
  /** normalized pointer -1..1, for the S5 tilt */
  pointer: { x: 0, y: 0 },
  /** which 3D moments are on screen; the canvas hides and stops when empty */
  scenes: new Set<SceneId>(),
};

// dev only: lets the QA scripts read the store
if (typeof window !== "undefined" && process.env.NODE_ENV !== "production") Object.assign(window, { __store: scrollStore });

let invalidateFn: (() => void) | null = null;

export function setInvalidate(fn: (() => void) | null) {
  invalidateFn = fn;
}

/** Ask R3F for a frame (frameloop="demand"). Safe to call before the canvas exists. */
export function invalidate() {
  invalidateFn?.();
}

type NumericKey = {
  [K in keyof typeof scrollStore]: (typeof scrollStore)[K] extends number ? K : never;
}[keyof typeof scrollStore];

export function setProgress(key: NumericKey, value: number) {
  scrollStore[key] = value;
  invalidate();
}

const sceneListeners = new Set<() => void>();

export function setSceneActive(id: SceneId, active: boolean) {
  const had = scrollStore.scenes.has(id);
  if (active === had) return;
  if (active) scrollStore.scenes.add(id);
  else scrollStore.scenes.delete(id);
  document.documentElement.dataset.scenes = [...scrollStore.scenes].join(" ");
  sceneListeners.forEach((fn) => fn());
  invalidate();
}

export function onScenesChange(fn: () => void) {
  sceneListeners.add(fn);
  return () => {
    sceneListeners.delete(fn);
  };
}
