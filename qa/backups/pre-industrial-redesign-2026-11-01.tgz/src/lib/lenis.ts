"use client";

import Lenis from "lenis";
import { flushSync } from "react-dom";
import { gsap, ScrollTrigger } from "@/lib/gsap";

let lenis: Lenis | null = null;

const tick = (time: number) => lenis?.raf(time * 1000);

/** Lenis driven by the GSAP ticker so ScrollTrigger and smooth scroll share one clock. */
export function startLenis() {
  if (lenis) return lenis;
  lenis = new Lenis({ autoRaf: false, anchors: false });
  lenis.on("scroll", ScrollTrigger.update);
  gsap.ticker.add(tick);
  gsap.ticker.lagSmoothing(0);
  return lenis;
}

export function stopLenis() {
  if (!lenis) return;
  gsap.ticker.remove(tick);
  lenis.destroy();
  lenis = null;
}

export function getLenis() {
  return lenis;
}

let navigation = 0;
const nextFrame = () => new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));

/** Resolve anchors after preceding lazy pin layouts exist, so CTAs land at the actual destination. */
export async function scrollToTarget(target: string | HTMLElement | number) {
  if (typeof target === "number") {
    if (lenis) lenis.scrollTo(target);
    else window.scrollTo({ top: target });
    return;
  }
  const el = typeof target === "string" ? document.getElementById(target.replace(/^#/, "")) : target;
  if (!el) return;
  const request = ++navigation;
  flushSync(() => document.dispatchEvent(new CustomEvent("lb:prepare-anchor", { detail: el })));
  await document.fonts.ready;
  await nextFrame();
  await nextFrame();
  if (request !== navigation) return;
  ScrollTrigger.sort();
  ScrollTrigger.refresh();
  lenis?.resize();
  const pin = ScrollTrigger.getById(el.id);
  const y = pin?.pin ? pin.start + 1 : Math.max(0, el.getBoundingClientRect().top + window.scrollY - 104);
  const focus = () => {
    if (!el.hasAttribute("tabindex")) el.setAttribute("tabindex", "-1");
    el.focus({ preventScroll: true });
  };
  if (typeof target === "string" && window.location.hash !== target) history.pushState(null, "", target);
  if (lenis) lenis.scrollTo(y, { onComplete: focus });
  else { window.scrollTo({ top: y }); focus(); }
}
