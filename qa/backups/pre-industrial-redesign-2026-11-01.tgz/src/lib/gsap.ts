"use client";

import gsap from "gsap";
import { CustomEase } from "gsap/CustomEase";
import { Draggable } from "gsap/Draggable";
import { DrawSVGPlugin } from "gsap/DrawSVGPlugin";
import { Flip } from "gsap/Flip";
import { InertiaPlugin } from "gsap/InertiaPlugin";
import { Observer } from "gsap/Observer";
import { Physics2DPlugin } from "gsap/Physics2DPlugin";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import { useGSAP } from "@gsap/react";

if (typeof window !== "undefined") {
  gsap.registerPlugin(
    useGSAP,
    ScrollTrigger,
    SplitText,
    Flip,
    DrawSVGPlugin,
    CustomEase,
    Draggable,
    InertiaPlugin,
    Physics2DPlugin,
    Observer,
  );

  // The one overshoot ease: anything that sticks, lands or snaps. (The brief's path was
  // missing a control point; this keeps its shape: overshoot to 1.04 at half time, settle.)
  CustomEase.create("slap", "M0,0 C0.2,0 0.1,1.12 0.5,1.04 C0.7,1 0.85,1 1,1");

  // dev only: lets the QA scripts read pin ranges
  if (process.env.NODE_ENV !== "production") Object.assign(window, { ScrollTrigger });
}

/** Durations and staggers from the motion spec. */
export const DUR = { ui: 0.35, reveal: 0.6, slap: 0.9, load: 1.2 } as const;
export const STAGGER = { chars: 0.04, lines: 0.08, cards: 0.06 } as const;

export {
  gsap,
  CustomEase,
  Draggable,
  DrawSVGPlugin,
  Flip,
  InertiaPlugin,
  Observer,
  Physics2DPlugin,
  ScrollTrigger,
  SplitText,
  useGSAP,
};
