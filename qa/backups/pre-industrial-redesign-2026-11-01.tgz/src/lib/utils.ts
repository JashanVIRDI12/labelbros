/** Join class names. No merge step on purpose: our token classes (text-16, text-paper)
 *  share prefixes that merge libraries mistake for conflicts. */
export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}
