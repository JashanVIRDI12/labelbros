/**
 * `data-three` on <html> lists the 3D moments that have taken over from their 2D stand-ins
 * (hero, wrap, finish, sample). CSS hides the 2D version with `:root[data-three~=id]`.
 */
export function setThreeFlag(id: string, on: boolean) {
  const el = document.documentElement;
  const set = new Set((el.dataset.three ?? "").split(" ").filter(Boolean));
  if (on) set.add(id);
  else set.delete(id);
  el.dataset.three = [...set].join(" ");
}
